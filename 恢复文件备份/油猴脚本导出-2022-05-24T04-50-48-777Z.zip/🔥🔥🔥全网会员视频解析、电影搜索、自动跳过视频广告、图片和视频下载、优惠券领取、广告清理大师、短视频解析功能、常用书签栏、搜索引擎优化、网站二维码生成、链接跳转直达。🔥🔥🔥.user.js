// ==UserScript==
// @name        🔥🔥🔥全网会员视频解析、电影搜索、自动跳过视频广告、图片和视频下载、优惠券领取、广告清理大师、短视频解析功能、常用书签栏、搜索引擎优化、网站二维码生成、链接跳转直达。🔥🔥🔥
// @description 全网会员视频解析、电影搜索、自动跳过视频广告、图片和视频下载、优惠券领取、广告清理大师、短视频解析功能、常用书签栏、搜索引擎优化、网站二维码生成、链接跳转直达。
// @namespace   http://payback.bwaq.cn
// @icon        http://payback.bwaq.cn/logo.png
// @author      星星龙♪(･ω･)ﾉ
// @version     2.0.3
// @include     *
// @license     MIT License
// @require     https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.8/FileSaver.min.js
// @require     https://cdn.staticfile.org/mustache.js/3.1.0/mustache.min.js
// @require     https://cdn.bootcdn.net/ajax/libs/jquery/3.5.1/jquery.min.js
// @require     https://cdn.bootcdn.net/ajax/libs/toastr.js/2.1.3/toastr.min.js
// @require     https://cdn.bootcdn.net/ajax/libs/jszip/3.1.5/jszip.min.js
// @resource    toastr_css https://cdn.bootcdn.net/ajax/libs/toastr.js/2.1.3/toastr.min.css
// @resource    iconInfo http://payback.bwaq.cn/logo.png
// @connect     *
// @grant       GM_log
// @grant       GM.info
// @grant       GM_info
// @grant       GM_addStyle
// @grant       GM.setValue
// @grant       GM_setValue
// @grant       GM.getValue
// @grant       GM_getValue
// @grant       GM_download
// @grant       unsafeWindow
// @grant       GM.openInTab
// @grant       GM_openInTab
// @grant       GM.listValues
// @grant       GM_listValues
// @grant       GM.deleteValue
// @grant       GM_deleteValue
// @grant       GM.setClipboard
// @grant       GM_setClipboard
// @grant       GM.notification
// @grant       GM.xmlHttpRequest
// @grant       GM_xmlhttpRequest
// @grant       GM.getResourceUrl
// @grant       GM_getResourceURL
// @grant       GM_getResourceText
// @grant       GM_registerMenuCommand
// @grant       GM_unregisterMenuCommand
// ==/UserScript==
(function () {
    'use strict';

    let removeDataSet = new Array();

    var Utils$2 = {
        /**
         * @param exeTag - Execute Type: 'id' => Use document.getElementById() to remove
         * @param exeTag - Execute Type: 'path' => Use document.querySelector() to remove
         * @param exeTag - Execute Type: 'class' => Use document.getElementsByClassName() to remove
         * @param exeTag - Execute Type: 'cssClick' => css click event
         * @param exeTag - Execute Type: 'tag' => Use document.getElementsByTagName() to remove
         * @param exeTag - Execute Type: 'exe' => Use eval to execute the code
         *
         * @param exeData - Data container of exeTag execute type
         *
         * @param exeType - (>0) => Only x Times execute the data
         * @param exeType - (-1) => Interval execute the data for interval 500ms
         */
        addData: function (exeTag, exeData, exeType) {
            let len = this.appendArray(removeDataSet);
            removeDataSet[len][0] = exeTag;
            removeDataSet[len][1] = exeData;
            removeDataSet[len][2] = exeType;
        },
        appendArray: function (ary) {
            ary.splice(ary.length, 0, []);
            return ary.length - 1;
        },
        execute: function (timeout) {
            if (typeof timeout == 'undefined') {
                timeout = 500;
            }
            removeDataSet.forEach(removeItem => {
                let excuteTimes = removeItem[2];
                if (excuteTimes == -1) {
                    //循环执行
                    setInterval(() => {
                        this.nomalExecute(removeItem);
                    }, timeout);
                } else if (excuteTimes > 0) {
                    //执行指定的次数
                    let times = 0;
                    let timer = setInterval(() => {
                        times++;
                        if (times > excuteTimes) {
                            clearInterval(timer);
                        }
                        this.nomalExecute(removeItem);
                    }, timeout);
                } else ;
            });
        },
        nomalExecute: function (removeItem) {
            // GM_log('checking...')
            let exeTag = removeItem[0];  //Execute Type
            let exeData = removeItem[1]; //Data container of Execute type

            switch (exeTag) {
                case 'auto'://通过前面的前缀判断
                    exeData.forEach(item => {
                        if (item.startsWith("#")) {
                            this.removeId(item.substring(1));
                        } else if (item.startsWith(".")) {
                            this.removeClass(item.substring(1));
                        }
                    });
                    break;
                case 'id':
                    exeData.forEach(item => {
                        this.removeId(item);
                    });
                    break;
                case 'class':
                    exeData.forEach(item => {
                        this.removeClass(item);
                    });
                    break;
                case 'path':
                    exeData.forEach(item => {
                        this.removePath(item);
                    });
                    break;
                case 'tag':
                    exeData.forEach(item => {
                        this.removeTag(item);
                    });
                    break;
                case 'click':
                    exeData.forEach(item => {
                        this.performClick(item);
                    });
                    break;
                case 'invoke':
                    exeData.forEach(item => {
                        this.invokeMethod(item);
                    });
                    break;
            }
        },
        removeId: function (id) {
            if (document.getElementById(id) == null) {
                return;
            }
            document.getElementById(id).remove();
            // GM_log('removing...');
        },
        removeClass: function (className) {
            let times = 0;
            while (document.getElementsByClassName(className).length > 0) {
                times++;
                //限制执行次数
                if (times > 100) {
                    break;
                }
                document.getElementsByClassName(className)[0].remove();
                // GM_log('removing...');
            }
        },
        removeTag: function (tag) {
            let times = 0;
            while (document.getElementsByTagName(tag).length > 0) {
                times++;
                //限制执行次数
                if (times > 100) {
                    break;
                }
                document.getElementsByTagName(tag)[0].remove();
                // GM_log('removing...');
            }
        },
        removePath: function (path) {
            if (document.querySelector(path) == null) {
                return;
            }
            document.querySelector(path).remove();
            // GM_log('removing...');
        },
        performClick: function (item) {
            let elements = document.getElementsByClassName(item[0]);
            if (elements.length > item[1]) {
                elements[item[1]].click();
            }
        },
        invokeMethod: function (methodName) {
            eval(methodName);
        }
    };

    var GUtils = {
        inIframe: function () {
            return self.frameElement && 'IFRAME' == self.frameElement.tagName
                || !(window.frames.length == parent.frames.length && self == top)
        },
        getUrlParam: function (name) {
            let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
            let regRewrite = new RegExp('(^|/)' + name + '/([^/]*)(/|$)', 'i');
            let r = window.location.search.substr(1).match(reg);
            let q = window.location.pathname.substr(1).match(regRewrite);

            if (r && r.length > 0) {
                return unescape(r[2])
            } else if (q && q.length > 0) {
                return unescape(q[2])
            } else {
                return ''
            }
        },
        intercepter: function (regexStr) {
            if (regexStr && regexStr.length !== 0) {
                for (let i = 0; i < regexStr.length; i++) {
                    let item = regexStr[i];
                    if (location.href.indexOf(item) !== -1) {
                        return false;
                    }
                }
                return true
            }
            return false
        },
    };

    let regexStr$p = ['so.com', '360kan.com'];

    const website$q = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$p)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            let cycle = 500;// 检测广告的刷新时间

            // 360搜索
            if (location.href.indexOf('www.so.com') !== -1) {
                Utils$2.addData('auto',
                    [
                        '.sad',
                        '.lawnfooter-image__panel',
                        '#side',
                        '#m-spread-left',
                        '.m-spread-middle',
                        '#m-spread-bottom',
                        '.res-mediav',
                        '#news-sdk-sad',
                        '.mh-ad',
                        '#e_idea_pp',
                    ], -1);
                Utils$2.addData('path',
                    [
                        '[data-i=\'tmall\']',
                        'div[id*=\'--strong\']',
                        'div[id*=\'--normal\']',
                    ], -1);
                Utils$2.execute(cycle);
            }

            // 360资讯
            if (location.href.indexOf('news.so.com') !== -1) {
                Utils$2.addData('auto', [
                    '#side',
                    '.js-multi-i-item',
                    '.info-flow',
                ], -1);
                Utils$2.execute(cycle);
            }

            // 360问答
            if (location.href.indexOf('wenda.so.com') !== -1) {
                Utils$2.addData('auto', [
                    '.aside',
                    '#js-mod-fixed-float',
                    '.js-left-flow-busi',
                    '#attention',
                    '#guess-see',
                    '#e_idea_wenda_leftBox',
                    '.js-busi-item',
                    '.js-ajax-busi-item',
                    '#detail-guess-wrap',
                    '.js-mod-flow',
                ], -1);
                Utils$2.execute(cycle);
            }

            // 360视频
            if (location.href.indexOf('360kan.com') !== -1) {
                Utils$2.addData('auto', ['.rt-btm-popup_ad',
                    '.info-flow__ad',
                    '.p-searchad-wrap',
                    '#soRightAd',
                    '.adbig',
                ], -1);
                Utils$2.addData('path', [
                    '[data-adclicklog]',
                    '[data-so-mod=\'list-ad\']',
                ], -1);

                Utils$2.execute(cycle);
            }

            // 360图片
            if (location.href.indexOf('image.so.com') !== -1) {
                Utils$2.addData('path', [
                    '[data-id*=\'cm_extended_init\']',
                ], -1);
                Utils$2.execute(cycle);
                setInterval(function () {
                    $j('.related_query').parent().remove();
                }, cycle);
            }

            // 360良医
            if (location.href.indexOf('ly.so.com') !== -1) {
                Utils$2.addData('auto', [
                    '#so_ob',
                    '#news-card',
                    '#m-spread-left',
                ], -1);
                Utils$2.execute(cycle);
            }

            // 360地图
            if (location.href.indexOf('ditu.so.com') !== -1) {
                Utils$2.addData('path', [
                    '[data-e_href]',
                ], -1);
                Utils$2.execute(cycle);
            }

            // 360百科
            if (location.href.indexOf('baike.so.com/search') !== -1) {
                Utils$2.addData('auto', [
                    '.aside',
                    '#e_idea_wenda_leftBox',
                ], -1);
                Utils$2.addData('path', [
                    'div[id*=\'mvdiv\']',
                ], -1);
                Utils$2.execute(cycle);

            }
            if (location.href.indexOf('baike.so.com/doc') !== -1) {
                Utils$2.addData('auto', [
                    '#js-mod-fixed-float',
                    '.js-newsfeed-popup',
                    '#J-mod-right-recommend',
                    '#J-mod-hot-rank',
                    '#rightbanner',
                    '#J-mod-interested-possible',
                    '.entry-plus',
                    '#js-doc-recommand',
                ], -1);

                Utils$2.addData('path', [
                    'div[id*=\'J-mod-right-ad\']',
                ], -1);
                Utils$2.execute(cycle);
            }

            // 360国学
            if (location.href.indexOf('guoxue.baike.so.com') !== -1) {
                Utils$2.addData('auto', [
                    '.right',
                    '.js-newsfeed-popup',
                    '#js-doc-recommand',
                    '.lm-bottom-container',
                    '#J-entry-newsfeed-bottom',
                    '#interest-wrap',
                ], -1);

                Utils$2.execute(cycle);
            }

            // 360文库
            if (location.href.indexOf('wenku.so.com/s') !== -1) {
                Utils$2.addData('auto', [
                    '.rt-side',
                    '#e_idea_wenda_leftBox',
                ], -1);
                Utils$2.execute(cycle);
            }
            if (location.href.indexOf('wenku.so.com/d') !== -1) {
                Utils$2.addData('auto', [
                    '.js-page-busi',
                    '#interest',
                    '.infoFlow',
                    '.fixed-rtbot',
                    '#js-fixed-rt',
                ], -1);
                Utils$2.addData('path', [
                    '[data-so-mod=\'right_flow\']',
                ], -1);
                Utils$2.execute(cycle);
            }

            // 360翻译
            if (location.href.indexOf('fanyi.so.com') !== -1) {
                Utils$2.addData('auto', [
                    '#card_container',
                ], -1);
                Utils$2.execute(cycle);
            }
        },
    };

    let regexStr$o = ['baidu'];

    const website$p = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$o)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            let cycle = 500;// 检测广告的刷新时间

            // 百度搜索
            if (location.href.indexOf('www.baidu.com') !== -1) {
                Utils$2.addData('auto', [
                    "#content_right",
                    "#top-ad",
                    ".ec-pl-container",
                ], 1);
                Utils$2.execute(200);

                setInterval(function () {
                    $j("#content_left > div").each(function () {
                        if ($j(this).attr('id') === 'undefined'
                            && $j('> style', this).attr('id') !== 'undefined') {
                            $j(this).remove();
                        }
                    });
                    if ($j(".s-tab-item").css("color") === "rgb(255, 255, 255)") {
                        // 防止导航栏出现白色
                        $j(".cur-tab").css("color", "black");
                        $j(".s-tab-item").css("color", "gray");
                    }

                    $j("#content_left > div").each(function () {
                        if ($j(this).attr('id') === 'undefined' && $j('> div', this).attr('data-placeid') !== 'undefined') {
                            $j(this).remove();
                        }
                    });
                    $j("a").each(function () {
                        if ($j(this)[0].innerHTML === '广告') {
                            $j(this).parents(".result").remove();
                        }
                    });
                    $j(".san-card").each(function () {
                        if ($j(this).attr("tpl") === 'feed-ad') {
                            $j(this).remove();
                        }
                    });
                }, 200);
            }

            // 百度知道
            if (location.href.indexOf('zhidao.baidu.com') !== -1) {
                Utils$2.addData('auto', [
                    ".shop-entrance",
                    ".activity-entry",
                    ".task-list-button",
                ], -1);
                Utils$2.execute(cycle);
            }
            if (location.href.indexOf('zhidao.baidu.com/search') !== -1) {
                Utils$2.addData('auto', [
                    ".leftup",
                    ".wgt-iknow-special-business",
                    ".aside.fixheight",
                ], 1);

                Utils$2.addData('auto', [
                    ".bannerdown",
                    ".wgt-bottom-ask",
                ], -1);
                Utils$2.execute(cycle);
            }
            if (location.href.indexOf('zhidao.baidu.com/question') !== -1) {
                Utils$2.addData('auto', [
                    ".adTopImg",
                    ".exp-topwld-tip",
                    "#wgt-ecom-banner",
                    "#wgt-ecom-right",
                    ".question-number-text-chain",
                    ".grid-r.qb-side",
                    ".wgt-ads",
                    ".wgt-bottom-union",
                    ".ec-pc_mat_coeus__related_link_text-content",
                    ".businessvip-wrapper",
                    ".new-icon",
                    ".phone-icon",
                ], -1);
                Utils$2.execute(cycle);
                setInterval(function () {
                    $j("#answer-bar").removeClass("exp-answerbtn-yh");
                }, cycle);
            }

            // 百度百科
            if (location.href.indexOf('baike.baidu.com') !== -1) {
                Utils$2.addData('auto', [
                    "#navbarAdNew",
                    ".userbar_mall",
                ], -1);
                Utils$2.execute(cycle);
            }
            if (location.href.indexOf('baike.baidu.com/item') !== -1) {
                Utils$2.addData('auto', [
                    ".pinzhuanWrap",
                    ".configModuleBanner",
                    ".topA",
                    ".right-ad",
                    ".lemmaWgt-promotion-vbaike",
                    ".lemmaWgt-promotion-slide",
                    "#side_box_unionAd",
                    ".after-content",
                ], -1);
                Utils$2.execute(cycle);
            }

            // 百度文库
            if (location.href.indexOf('wenku.baidu.com') !== -1) {
                Utils$2.addData('auto', [
                    ".tiger-lossUser-dialog-vip",
                    ".banner-ad",
                    ".ad-box",
                    "#banurl",
                    ".vip-card",
                    ".zsj-topbar",
                    ".lastcell-dialog",
                    ".zsj-toppos",
                ], -1);
                Utils$2.execute(cycle);
                setInterval(function () {
                    $j("#my-wkHome-vip-tips").parent().remove();
                }, cycle);
            }
            if (location.href.indexOf('wenku.baidu.com/search') !== -1) {
                Utils$2.addData('auto', [
                    ".fc-product-result-wrap",
                    ".fc-first-result-wrap",
                    ".bottom-right-dsp-ad-wrap",
                ], -1);
                Utils$2.addData('auto', [
                    ".user-vip",
                    ".base-layout-content-right",
                    ".vip-guide-test",
                ], 1);
                Utils$2.execute(cycle);
            }
            if (location.href.indexOf('wenku.baidu.com/view') !== -1) {
                Utils$2.addData('auto', [
                    ".pager-container",
                    ".add-has-money-pay",
                    ".experience-card-wrap",
                    ".experience-card-bar-wrap",
                    ".join-vip",
                    ".vip-card-wrap",
                    ".vip-pop-wrap",
                    ".vip-activity-wrap",
                    ".fold-page-tip",
                    ".hx-warp",
                    ".convert-tip",
                    ".new-user-discount-tip",
                    ".top-ads-banner-wrap",
                    ".banner-core-wrap.super-vip",
                    ".vip-layer-inner",
                    ".vip-activity-wrap-new",
                    ".vip-pay-pop-v2-wrap",
                    ".zhenxuan-guide",
                    ".fufei-activity-bar",
                    ".qua-box",
                    ".service-entry",
                    ".relative-doc-ad-wrapper",
                    ".ad-onff",
                    ".second-ad",
                    ".relative-course-wrapper",
                    ".hx-right-wrapper",
                    ".extension",
                    ".reader-extensin",
                    ".pc-common-sidebar",
                    ".vip-privilege-card-wrap",
                    ".woniu-guide-card",
                    ".hx-recom-wrapper",
                    ".hx-bottom-wrapper",
                    "#relative-videos-wrap",
                    ".bottom-pop-wrap",
                    ".inner-vip",
                ], -1);
                Utils$2.execute(cycle);
                setInterval(function () {
                    $j("#ggbtm").parent().remove();
                    $j("#ggbtm-ads").parent().remove();
                    $j(".union-ad-bottom").parent().remove();
                }, cycle);
            }

            // 百度图片
            if (location.href.indexOf('image.baidu.com/search/index') !== -1) {
                Utils$2.addData('auto', [
                    ".newfcImgli"
                ], -1);
                Utils$2.addData('auto', [
                    "#pnlBeforeContent",
                    ".adMask",
                ], 1);
                Utils$2.execute(cycle);
            }
            if (location.href.indexOf('image.baidu.com/search/detail') !== -1) {
                Utils$2.addData('auto', [
                    ".text-link-ads",
                    ".rsresult-card",
                    "#adCard",
                ], -1);
                Utils$2.execute(cycle);
            }

            // 百度视频
            if (location.href.indexOf('video.baidu.com') !== -1 || location.href.indexOf('v.baidu.com') !== -1) {
                Utils$2.addData('auto', [
                    "#pallcommoncolumnad",
                    "#index_right_top",
                    "#qzfcadid",
                    "#PCallpagesidebar1",
                    "#PCallpagesidebar2",
                    "#sidebarADRightWrap",
                    "#detail_adm_right",
                    "#pcshortchannelTopRight",
                    "#topic-wrap-v2",
                    ".ctt-adver1-banner",
                    ".section-ad",
                    ".full-collunm-ad",
                ], -1);
                Utils$2.addData('path', [
                    "div[id*='channelBannerAdver']",
                    "div[id*='PCDetailPageTopRightList']",
                    "div[id*='adone']",
                    "div[id*='adtwo']",
                    "div[id*='pc']",
                    "div[id*='PC']",
                    "[id*='FeedAdSys']",
                    "div[id*='TabAd']",
                ], -1);
                Utils$2.execute(cycle);
                setInterval(function () {
                    $j(".bdvideo-adver-carousel").parent().remove();
                    $j("#__lawnImageContainer").parent().parent().remove();
                    $j("div[id*='channelColumn']").parent().remove();
                    $j("div[id*='ChannelColumn']").parent().remove();
                    $j("div[id*='adv-carousel-item']").parent().remove();
                }, cycle);
            }
            if (location.href.indexOf('video.baidu.com/v') !== -1
                || location.href.indexOf('v.baidu.com/v') !== -1) {

                Utils$2.addData('auto', [
                    ".side-content",
                    "#searchPagefeedBanner",
                    "#searchResultAdOne",
                    "#searchHotShortSeven",
                    "#searchHotShortSevenTwo",
                ], -1);
                Utils$2.addData('path', [
                    "div[id*='searchMoreLong']",
                ], -1);
                Utils$2.execute(cycle);
                $j(".top-ad-cont").remove();
                setInterval(function () {
                    $j("#psBottomColumn").parent().remove();
                }, cycle);
            }
            if (location.href.indexOf('www.baidu.com/sf/vsearch') !== -1) {
                $j("#s_tab").next().next().each(function () {
                    let id = String($j(this).attr("id"));
                    if (typeof id === 'undefined') {
                        $j(this).remove();
                    }
                });
            }

            // 百度贴吧
            if (location.href.indexOf('tieba.baidu.com/f/search') !== -1) {
                Utils$2.addData('auto', [
                    ".s_aside",], 1);
                Utils$2.execute(cycle);
            }
            if (location.href.indexOf('tieba.baidu.com/f?') !== -1) {
                Utils$2.addData('auto', [
                    ".fengchao-wrap-feed",
                    ".tb_poster_placeholder",
                    "#lu-frs-aside",
                    "#lu-frs-aside-seat",
                ], -1);
                Utils$2.addData('path', [
                    "div[id$='_ad']",], -1);
                Utils$2.execute(cycle);
            }
            if (location.href.indexOf('tieba.baidu.com/p') !== -1) {
                Utils$2.addData('auto', [
                    ".tb_poster_placeholder",
                ], -1);
                Utils$2.execute(cycle);
                $j("#j_p_postlist").find("div").each(function () {
                    let isAd = String($j(this).attr("ad-dom-img"));
                    if (isAd === "true") {
                        $j(this).remove();
                    }
                });
            }

            // 百度地图
            if (location.href.indexOf('map.baidu.com') !== -1) {
                Utils$2.addData('auto', [
                    "#activity-banner-panel",
                    ".damoce-search-item",
                ], -1);
                Utils$2.execute(cycle);
            }

            // 百度经验
            if (location.href.indexOf('jingyan.baidu.com/search') !== -1) {
                $j(".ec_ad").parent().remove();
            }
            if (location.href.indexOf('jingyan.baidu.com/article') !== -1) {
                Utils$2.addData('auto', [
                    "#fresh-share-exp-e",
                    ".wgt-income-money",
                    ".aside-pro-container",
                    "#bottom-ads-container",
                    ".magzine-list",
                    "#wgt-left-promo",
                    ".right-fixed-related-wrap",
                    "#task-panel-wrap",
                    "#aside-ads-container",
                    ".wgt-cms-banner",
                    ".bottom-pic-ads",
                ], 1);
                Utils$2.execute(cycle);
            }

            // 百度翻译
            if (location.href.indexOf('fanyi.baidu.com') !== -1) {
                Utils$2.addData('auto', [
                    "#sideAdContainer",
                    ".spread-wrap",
                    "#sideBannerContainer",
                ], 1);
                Utils$2.execute(cycle);
            }

            // 百度网盘
            if (location.href.indexOf('pan.baidu.com') !== -1) {
                Utils$2.addData('path', [
                    "[node-type=header-union]",
                ], -1);
                Utils$2.execute(cycle);
            }
            if (location.href.indexOf('pan.baidu.com/share/') !== -1) {
                Utils$2.addData('auto', [
                    ".phone-banner",
                ], -1);
                Utils$2.execute(cycle);
            }
            if (location.href.indexOf('pan.baidu.com/s/') !== -1) {
                Utils$2.addData('auto', [
                    "#web-right-view",
                    ".ad-platform-tips",
                    ".btn-img-tips",
                ], 1);
                Utils$2.addData('auto', [
                    ".rights-section",
                    ".bottom-tip-bar",
                ], -1);
                Utils$2.execute(cycle);
            }
        }
    };

    let regexStr$n = [];

    const website$o = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$n)
        },
        setRunType: function (val) {
        },

        init: function ($j) {
            let cycle = 500;// 检测广告的刷新时间

            // hao123
            if (location.href.indexOf('hao123.com') !== -1) {
                Utils$2.addData('auto', [
                    "#topbeWrapper",
                    "#lefttip",
                    ".rightTip",
                    "#box-famous-resource",
                    ".bottom-banner-link-wrapper",
                    ".wm",
                ], -1);
                Utils$2.execute(cycle);
            }

            // 2345网址导航
            if (location.href.indexOf('2345.com') !== -1) {
                Utils$2.addData('auto', [
                    ".tip_stopXP",
                    "#corner_a",
                    "#mzBrowserWrap",
                    "#J_s11_logowall_left",
                    "#J_s11_logowall_right",
                    "#J_gul_yg",
                    "#map_shop",
                    ".ad-wrap",
                    "#J_hot_event",
                    "#rightXieCheng",
                    "#J_right_bottom_ad",
                ], -1);
                Utils$2.execute(cycle);
                setInterval(function () {
                    $j("h3:contains('发现你喜欢')").parent().parent().parent().remove();
                    $j(".adTag").parents(".slide-item").remove();
                }, cycle);
            }

            // 360导航
            if (location.href.indexOf('hao.360') !== -1) {
                Utils$2.addData('auto', [
                    "#corner-flash",
                    "#daily-hotwords",
                    "#hotsite-view-front",
                    "#activity",
                    ".pubble-shape-wrap",
                    "#large2small",
                    ".js-mv-infoflow-item",
                ], -1);
                Utils$2.addData('path', [
                    "a[class*='mediav-ads']",
                    "li[notice-ad = 'true']",
                ], -1);
                Utils$2.execute(cycle);
                setInterval(function () {
                    $j(".notice-panel-count").text("(2)");
                    $j("h3:contains('发现你喜欢')").parent().parent().remove();
                    $j(".ad").parent().remove();
                    $j(".textlink_ad_icon").parent().remove();
                    $j(".adMark").parents(".cube-mod").remove();
                    $j(".ads-img").parents(".right-content").remove();
                }, cycle);

            }

            // 搜狗网址导航、QQ导航（上网导航）
            if (location.href.indexOf('123.sogou.com') !== -1 ||
                location.href.indexOf('hao.qq.com') !== -1 ||
                location.href.indexOf('daohang.qq.com') !== -1) {
                Utils$2.addData('auto', [
                    ".hd-slider",
                    ".cs_right_hw",
                    ".ads",
                    ".banner-ad",
                    ".adword",
                    ".tmallskin",
                    "#wrap",
                ], -1);
                Utils$2.addData('path', [
                    "div[id*='AD']",
                    "ul[pbflag='top3ad'] li:eq(0)",
                    "div[pbflag='guess']",
                    "div[pbflag='rec_shop']",
                    "div[pbflag='coolsitefeed_ad']",
                    "div[pbflag='bt_newsb_ad']",
                ], -1);
                Utils$2.execute(cycle);
                setInterval(function () {
                    $j("#sdtom").parent().remove();
                    $j("div[pbflag='bt_baike']").parent().remove();
                    $j("div[pbflag='bt_mai']").parent().remove();
                }, cycle);
            }

            // UC导航
            if (location.href.indexOf('uc123.com') !== -1) {
                Utils$2.addData('auto', [
                    ".header-push-container",
                    ".s-push-box",
                    ".m-links",
                    ".side-hot",
                    ".cool",
                    "#J_shopping",
                    "#J_shopping",
                ], -1);
                Utils$2.execute(cycle);
            }

            // 毒霸网址大全
            if (location.href.indexOf('duba.com') !== -1 ||
                location.href.indexOf('newduba.cn') !== -1) {
                Utils$2.addData('auto', [
                    "#__lawnImageContainer",
                    ".skin_bg",
                    ".m_site_ad_wrap",
                    ".m_elevator.elevator_hidden",
                    ".m_rec_game",
                    "#js-ysjpp",
                    "#J_sideFooter",
                    ".rtcenter_game.jq_rtcenter_game",
                    ".fav_box_wrap",
                    ".side_game",
                    ".side_taobao",
                    ".left_ad_collection",
                    ".jqrp_infoflow_ad",
                    ".top_func_ad",
                    ".fav_box",
                    ".taobao_search",
                    ".sort_wm",
                    ".sort_line",
                    ".box_shopping",
                    ".box_happy",
                    ".tj_ul",
                    ".newslist > div",
                    ".mediavAd",
                ], -1);
                Utils$2.addData('path', [
                    "div[opname='w_search_right_ad']",
                ], -1);
                Utils$2.execute(cycle);
                setInterval(function () {
                    $j("#top_ad_tmall_ul").parent().remove();
                    $j(".ads-tag").parent().parent().parent().remove();
                    $j(".adTag").parents(".swiper-slide").remove();
                }, cycle);
            }
        }
    };

    let regexStr$m = ['www.zhihu.com'];

    const website$n = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$m)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            let cycle = 500;// 检测广告的刷新时间

            // 知乎去广告
            setInterval(function () {
                //==============屏蔽知乎广告==============
                $j(".Pc-feedAd-container").each(function () {
                    if ($j(this).find(".Pc-feedAd").length > 0) {
                        $j(this).remove();
                    }
                });
                //==============屏蔽知乎广告==============

                //==============屏蔽知乎营销号==============
                Utils$2.addData('path', [
                    "[data-zop*='\"authorName\":\"故事档案局\"']",
                    "[data-zop*='\"authorName\":\"盐选科普\"']",
                    "[data-zop*='\"authorName\":\"盐选推荐\"']",
                    "[href*='www.zhihu.com/market']",
                    "[href*='www.zhihu.com/pub/reader']",
                ], 1);
                Utils$2.execute(cycle);
                var story = $j(".KfeCollection-PaidAnswerFooter");
                if (story.length > 0) {
                    story.parent().parent().parent()[0].innerText = "付费答案";
                }
                //==============屏蔽知乎营销号==============
            }, cycle);
        }
    };

    const modules$7 = [website$q, website$p, website$o, website$n];

    const prepare$7 = {
        init: function ($j, runType) {
            if (GUtils.inIframe()) {
                return
            }
            for (let i = 0; i < modules$7.length; i++) {
                let module = modules$7[i];
                if (module.intercepter()) {
                    continue;
                }
                module.setRunType((typeof runType === 'undefined') ? 'alone' : runType);
                module.init($j);
            }
        }
    };

    let regexStr$l = ['iqiyi.com'];

    const website$m = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$l)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            if (location.href.indexOf('www.iqiyi.com') !== -1) {
                setInterval(() => {
                    var skipView = $j(".skippable-after")[0];
                    if (skipView) {
                        // 防止无限弹窗
                        if (skipView.href === 'javascript:;' && skipView.style.display === 'none') {
                            skipView.click();
                        }
                    }
                }, 1000);
            } else if (location.href.indexOf('sports.iqiyi.com') !== -1) {
                // 爱奇艺体育
                setInterval(() => {
                    let container = $j('#engine-container');
                    let videos = $j('video');
                    if (videos && container
                        && container.style['pointer-events'] === 'auto'
                        && container.style['cursor'] === 'pointer') {
                        for (let video of videos) {
                            video.currentTime = 1000;
                        }
                    }
                }, 1000);
            }
        }
    };

    const common$1 = {
        generic: function ($j) {
            setInterval(() => {
                let skip = $j('body').find('video');
                if (skip && skip.get()) {
                    for (let video of skip.get()) {
                        let attrSrc = $j(video).attr('src');
                        if (attrSrc && !attrSrc.startsWith('blob:')) {
                            video.currentTime = 1000;
                        }
                    }
                }
            }, 1000);
        }
    };

    let regexStr$k = ['v.youku.com'];

    const website$l = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$k)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            common$1.generic($j);
        },
    };

    let regexStr$j = ['www.mgtv.com'];

    const website$k = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$j)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            common$1.generic($j);
        }
    };

    let regexStr$i = ['tv.sohu.com'];

    const website$j = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$i)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            common$1.generic($j);
        }
    };

    let regexStr$h = ['v.pptv.com'];

    const website$i = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$h)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            common$1.generic($j);
        }
    };

    let regexStr$g = ['tv.cctv.com'];

    const website$h = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$g)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            setInterval(() => {
                if ($j('#ticktack_player')) {
                    let videos = $j('video');
                    if (videos) {
                        // 存在广告
                        for (let video of videos) {
                            video.currentTime = 1000;
                        }
                    }
                }
            }, 1000);
        }
    };

    let regexStr$f = ['youtube.com'];

    const website$g = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$f)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            getStart$1();
        }
    };

    function getStart$1() {
        var closeAd = function () {
            let css = '.video-ads,.video-ads .ad-container .adDisplay,#player-ads,.ytp-ad-module,.ytp-ad-image-overlay{ display: none!important; }';
            let head = document.head || document.getElementsByTagName('head')[0];
            let style = document.createElement('style');

            style.type = 'text/css';
            if (style.styleSheet) {
                style.styleSheet.cssText = css;
            } else {
                style.appendChild(document.createTextNode(css));
            }
            head.appendChild(style);
        };
        var skipInt;
        var skipAd = function () {
            var skipbtn = document.querySelector('.ytp-ad-skip-button.ytp-button') || document.querySelector('.videoAdUiSkipButton ');
            if (skipbtn) {
                skipbtn = document.querySelector('.ytp-ad-skip-button.ytp-button') || document.querySelector('.videoAdUiSkipButton ');
                // GM_log('skip')
                skipbtn.click();
                if (skipInt) {
                    clearTimeout(skipInt);
                }
                skipInt = setTimeout(skipAd, 500);
            } else {
                // GM_log('checking...')
                if (skipInt) {
                    clearTimeout(skipInt);
                }
                skipInt = setTimeout(skipAd, 500);
            }
        };

        closeAd();
        skipAd();

    }

    const modules$6 = [website$m, website$l, /*qq,*/ website$k, website$j, website$i, website$h, website$g];

    const prepare$6 = {
        init: function ($j, runType) {
            for (let i = 0; i < modules$6.length; i++) {
                let module = modules$6[i];
                if (module.intercepter()) {
                    continue;
                }
                module.setRunType((typeof runType === 'undefined') ? 'alone' : runType);
                module.init($j);
            }
        }
    };

    let couponGroupLink = 'https://qm.qq.com/cgi-bin/qm/qr?k=Rt6wP6M_S9xVOgdUtqNypuT2xPixHeIR&jump_from=webapi';
    let couponQrCodeApi = 'https://qun.qq.com/qrcode/index?data=';

    let regexStr$e = ['tmall.com', 'taobao.com', 'liangxinyao.com', 'jd', 'zhihu'];

    const website$f = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$e)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            GM_addStyle(GM_getResourceText('toastr_css'));

            let href = location.href;

            setTimeout(function () {

                if (
                    href.indexOf('item.taobao.com') !== -1 ||
                    href.indexOf('detail.liangxinyao.com') !== -1 ||
                    href.indexOf('detail.tmall.com') !== -1 ||
                    href.indexOf('item.jd.com') !== -1
                ) {

                    let themeColor = 'maga-theme-color-taobao';
                    if (href.indexOf('tmall.com') !== -1 || href.indexOf('liangxinyao.com') !== -1) {
                        themeColor = 'maga-theme-color-tmall';
                    } else if (href.indexOf('jd.com') !== -1) {
                        themeColor = 'maga-theme-color-jd';
                    }
                    let html = `
                        <div id='maga-coupon-wrapper'>
                            <table id='maga-coupon-table'>
                                <thead class="${themeColor}">
                                    <tr>
                                        <th>优&nbsp;惠&nbsp;券</th>
                                        <th>券后价格</th>
                                        <th>操作</th>
                                        <th>扫码入群</th>
                                    </tr>
                                </thead>
                                <tr><td colspan='4'>正在查询优惠信息,请稍候...</td></tr>
                            </table>
                        </div>`;
                    $j('body').append(html);

                    if (href.indexOf('item.taobao.com') !== -1) {
                        $j('#maga-coupon-table').addClass('maga-theme-color-taobao');
                        getCouponAli($j);
                    } else if (href.indexOf('detail.tmall.com') !== -1 || href.indexOf('detail.liangxinyao.com') !== -1) {
                        $j('#maga-coupon-table').addClass('maga-theme-color-tmall');
                        getCouponAli($j);
                    } else if (href.indexOf('item.jd.com') !== -1) {
                        $j('#maga-coupon-table').addClass('maga-theme-color-jd');
                        getCouponJd($j);
                    }
                } else if (
                    href.indexOf('s.taobao.com/search') !== -1 ||
                    href.indexOf('s.taobao.com/list') !== -1 ||

                    href.indexOf('list.tmall.com/search_product.htm') !== -1 ||
                    href.indexOf('list.tmall.com/coudan/search_product.htm') !== -1 ||
                    href.indexOf('list.tmall.hk/search_product.htm') !== -1 ||

                    href.indexOf('search.jd.com/Search') !== -1
                ) {

                    let objs = {};
                    let channel = '';
                    let selectList = [];
                    if (href.indexOf('//s.taobao.com/search') !== -1 ||
                        href.indexOf('//s.taobao.com/list') !== -1) {

                        channel = 'tbk';
                        selectList.push('.grid .items .item');

                    } else if (
                        href.indexOf('//list.tmall.com/search_product.htm') !== -1 ||
                        href.indexOf('//list.tmall.com/coudan/search_product.htm') !== -1
                    ) {

                        channel = 'tbk';
                        selectList.push('.product');
                        selectList.push('.chaoshi-recommend-list .chaoshi-recommend-item');

                    } else if (href.indexOf('//list.tmall.hk/search_product.htm') !== -1) {

                        channel = 'tbk';
                        selectList.push('#J_ItemList .product');

                    } else if (href.indexOf('//search.jd.com/Search') !== -1) {

                        channel = 'jd';
                        selectList.push('.gl-item');

                    }
                    // GM_log(channel)

                    objs.initSearchItem = function (selector) {
                        if ($j(selector).hasClass('maga-coupon-list-already')) {
                            return
                        }
                        let selectView = $j(selector);
                        selectView.addClass('maga-coupon-list-already');

                        let nid;
                        if (href.indexOf('//search.jd.com/Search') !== -1) {
                            // 京东
                            nid = selectView.attr('data-sku') || selectView.attr('data-spu');
                        } else {
                            nid = selectView.attr('data-id');
                        }

                        //TODO 优化下 并添加 阿里大药房的搜索界面
                        if (!nid) {
                            nid = selectView.attr('data-itemid');
                        }
                        if (!nid) {
                            if (selectView.attr('href')) {
                                nid = location.protocol + selectView.attr('href');
                            } else {
                                var selectLink = selectView.find('a');
                                if (selectLink.length == 0) {
                                    return
                                } else {
                                    nid = selectLink.attr('data-nid');
                                    if (!nid) {
                                        if (selectLink.hasClass('j_ReceiveCoupon') && selectLink.length > 1) {
                                            nid = location.protocol + $j(selectLink[1]).attr('href');
                                        } else {
                                            nid = location.protocol + selectLink.attr('href');
                                        }
                                    }
                                }
                            }
                        }
                        if (nid) {
                            selectView.append(`
                                <div class="maga-coupon-list-area maga-coupon-list-wait" data-nid="${nid}">
                                    <a class="maga-coupon-list-info maga-coupon-list-info-default" title="点击查询">待查询</a>
                                </div>
                    `);
                        }
                    };
                    objs.basicQueryItem = function (selector) {
                        let selectView = $j(selector);
                        selectView.removeClass('maga-coupon-list-wait');
                        let nid = selectView.attr('data-nid');

                        var requestUrl = 'https://server.bwaq.cn/tbk/api/goods/getDetails?fromPlugin=true&id=' + nid + '&channel=' + channel;
                        // GM_log('requestUrl================' + requestUrl)

                        GM.xmlHttpRequest({
                            method: 'GET',
                            url: requestUrl,
                            onload: function onload(response) {
                                let data = response.response;
                                if (typeof data === 'string') {
                                    data = JSON.parse(data);
                                }
                                // GM_log('==============>' + JSON.stringify(data))

                                if (data.code == 10) {
                                    let indexUrl = 'https://link.zhihu.com/?target=' + encodeURIComponent('http://payback.bwaq.cn/goods?goodsId=' + nid + '&channel=' + channel);
                                    // GM_log('================获取优惠券成功================')
                                    let couponLinkUrl = data.data.couponmoney;
                                    let linkHtml = `<a href='${indexUrl}' target="_blank" class="maga-coupon-list-info maga-coupon-list-info-find">
                                                    立即领券（${couponLinkUrl}）
                                                </a>`;
                                    selectView.html(linkHtml);
                                } else {
                                    // GM_log('================获取优惠券失败================')
                                    selectView.addClass('maga-coupon-list-info-translucent');
                                    selectView.html('<a href="javascript:void(0);" class="maga-coupon-list-info maga-coupon-list-info-empty" style="color:#0E2679">亲无优惠劵哦</a>');
                                }
                            },
                        });
                    };
                    setInterval(function () {
                        selectList.forEach(function (selector) {
                            $j(selector).each(function () {
                                objs.initSearchItem(this);
                            });
                        });
                    }, 1500);
                    $j(document).on('click', '.maga-coupon-list-area', function () {
                        var selectView = $j(this);
                        if (selectView.hasClass('maga-coupon-list-wait')) {
                            objs.basicQueryItem(this);
                        } else if (selectView.hasClass('maga-coupon-list-info-translucent')) {
                            selectView.removeClass('maga-coupon-list-info-translucent');
                        } else {
                            selectView.addClass('maga-coupon-list-info-translucent');
                        }
                    });
                    setInterval(function () {
                        $j('.maga-coupon-list-wait').each(function () {
                            objs.basicQueryItem(this);
                        });
                    }, 1500);
                } else if (href.indexOf('link.zhihu.com/?target=') !== -1) {
                    //自动跳转，防止被追踪来源
                    location.href = decodeURIComponent(GUtils.getUrlParam('target'));
                }
            }, 200);
        },

    };

    function getCouponAli($j) {
        var bid = GUtils.getUrlParam('id');
        var requestUrl = 'https://server.bwaq.cn/tbk/api/goods/rates?channel=tbk&fromPlugin=true&goodsId=' + bid;

        // GM_log('requestUrl================' + requestUrl)

        function onSuccess(couponmoney) {
            let indexUrl = 'https://link.zhihu.com/?target=' + encodeURIComponent('http://payback.bwaq.cn/goods?channel=tbk&goodsId=' + bid);
            let row = `
                <tr>
                    <td>${couponmoney}元</td>
                    <td><a target="_blank" href='${indexUrl}'>立即领券</a></td>
                    <td><a target="_blank" href='${couponGroupLink}'>更多好券<br/>低价好物</a></td>
                    <td colspan='2'><img class='maga-coupon-qrcode-group' src='${couponQrCodeApi}${encodeURIComponent(couponGroupLink)}'/></td>
                </tr>`;
            $j('#maga-coupon-table tbody').append(row);
        }

        function onFailed() {
            let row = `                            
                <tr>
                    <td>亲无优惠劵哦</td>
                    <td><a target="_blank" href='${couponGroupLink}'>更多好券<br/>低价好物</a></td>
                    <td colspan='2'><img class='maga-coupon-qrcode-group' src='${couponQrCodeApi}${encodeURIComponent(couponGroupLink)}'/></td>
                </tr>`;
            $j('#maga-coupon-table tbody').append(row);
        }

        GM.xmlHttpRequest({
            method: 'GET',
            url: requestUrl,
            onload: function onload(response) {
                let data = response.response;
                if (typeof data === 'string') {
                    data = JSON.parse(data);
                }
                // GM_log('==============>' + JSON.stringify(data))

                $j('#maga-coupon-table tbody tr').remove();

                if (data.code == 10) {
                    // GM_log('getCouponAli================获取优惠券成功================')
                    var item = data.data.tbk;
                    if (item.couponmoney == 0) {
                        onFailed();
                    } else {
                        onSuccess(item.couponmoney);
                    }
                } else {
                    // GM_log('================获取优惠券失败================')
                    onFailed();
                }
            },
        });
    }

    function getCouponJd($j) {
        var bid = location.href.match('\\d+(?=\\.html)');
        var requestUrl = 'https://server.bwaq.cn/tbk/api/goods/getDetails?channel=jd&fromPlugin=true&id=' + bid;

        // GM_log('requestUrl================' + requestUrl)

        function onFailed() {
            let row = `
                <tr>
                    <td>亲无优惠劵哦</td>
                    <td><a target="_blank" href='${couponGroupLink}'>更多好券<br/>低价好物</a></td>
                    <td colspan='2'><img class='maga-coupon-qrcode-group' src='${couponQrCodeApi}${encodeURIComponent(couponGroupLink)}'/></td>
                </tr>`;
            $j('#maga-coupon-table tbody').append(row);
        }

        function onSuccess() {
            let indexUrl = 'https://link.zhihu.com/?target=' + encodeURIComponent('http://payback.bwaq.cn/goods?channel=jd&goodsId=' + bid);
            let row = `
                <tr>
                    <td><a target="_blank" href='${indexUrl}'>立即领券</a></td>
                    <td><a target="_blank" href='${couponGroupLink}'>更多好券<br/>低价好物</a></td>
                    <td colspan='2'><img class='maga-coupon-qrcode-group' src='${couponQrCodeApi}${encodeURIComponent(couponGroupLink)}'/></td>
                </tr>`;
            $j('#maga-coupon-table tbody').append(row);
        }

        GM.xmlHttpRequest({
            method: 'GET',
            url: requestUrl,
            onload: function onload(response) {
                let data = response.response;
                if (typeof data === 'string') {
                    data = JSON.parse(data);
                }
                // GM_log('==============>' + JSON.stringify(data))
                $j('#maga-coupon-table tbody tr').remove();
                if (data.code == 10) {
                    // GM_log('getCouponJd================获取优惠券成功================')
                    if (data.couponmoney == 0) {
                        onFailed();
                    } else {
                        onSuccess();
                    }
                } else {
                    // GM_log('================获取优惠券失败================')
                    onFailed();
                }
            },
        });
    }

    const modules$5 = [website$f];

    const prepare$5 = {
        init: function ($j, runType) {
            if (GUtils.inIframe()) {
                return
            }
            GM_addStyle(CSS_STR$4);
            for (let i = 0; i < modules$5.length; i++) {
                let module = modules$5[i];
                if (module.intercepter()) {
                    continue;
                }
                module.setRunType((typeof runType === 'undefined') ? 'alone' : runType);
                module.init($j);
            }
        }
    };

    let CSS_STR$4 = `
#maga-coupon-wrapper {
    position: fixed;
    top: 180px;
    right: 0;
    font-size: 14px;
    z-index: 99999999;
    font-weight: 500;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    flex-direction: row;
}

#maga-coupon-table {
    border: none;
    text-align: center;
    border-collapse: collapse;
    background-color: #FFFFFF;
}

#maga-coupon-table th {
    border: solid #DDDDDD 1px;
    color: #FFFFFF;
    padding: 8px 20px;
    font-size: 14px;
    font-weight: 500;
}

#maga-coupon-table td {
    border: solid #DDDDDD 1px;
    color: #333333;
    padding: 4px 10px;
    font-size: 13px;
}

.maga-coupon-qrcode-group {
    width: 100px;
    height: 100px;
    cursor: pointer;
    background-color: #FFFFFF;
    background-position: center;
    background-repeat: no-repeat;
    margin: 10px 10px;
    background-size: 75%;
}

.maga-theme-color-taobao {
    background-color: #FF4400;
}

.maga-theme-color-tmall {
    background-color: #FF0036;
}

.maga-theme-color-jd {
    background-color: #E93536;
}

/*搜索页面优惠券查询*/
.maga-coupon-list-area {
    position: absolute;
    top: 10px;
    right: 5px;
    z-index: 9999;
}

.maga-coupon-list-wait {
    cursor: pointer;
}

.maga-coupon-list-already {
    position: relative;
}

.maga-coupon-list-info {
    width: auto !important;
    height: auto !important;
    padding: 6px 8px !important;
    font-size: 12px;
    color: #fff !important;
    border-radius: 15px;
    cursor: pointer;
}

.maga-coupon-list-info, .maga-coupon-list-info:hover, .maga-coupon-list-info:visited {
    text-decoration: none !important;
}

.maga-coupon-list-info-default {
    background: #3186fd !important;
}

.maga-coupon-list-info-find {
    background: #ff0036 !important;
}

.maga-coupon-list-info-empty {
    color: #000 !important;
    background: #ccc !important;
}

.maga-coupon-list-info-translucent {
    opacity: 0.7;
}
`;

    var Utils$1 = {
        packageImages: function (imgUrls) {
            // GM_log(imgUrls)
            GM.notification({
                text: '正在打包中，稍后会下载，请勿重复点击！',
                image: GM_getResourceText('iconInfo'),
                timeout: 5000,
            });

            let imgBase64 = [];
            let zip = new JSZip();
            let img = zip.folder('images');
            for (let i = 0; i < imgUrls.length; i++) {
                let imgUrl = imgUrls[i].imgUrl;
                if (imgUrl && imgUrl.length > 0) {
                    this.getBase64(imgUrl).then(function (base64) {
                        imgBase64.push(base64.substring(22));
                    }, function (err) {
                        // GM_log('打印异常信息' + err)
                    });
                }
            }

            function zipImage() {
                setTimeout(function () {
                    if (imgUrls.length == imgBase64.length) {
                        for (let i = 0; i < imgUrls.length; i++) {
                            img.file(imgUrls[i].imgName, imgBase64[i], { base64: true });
                        }
                        zip.generateAsync({ type: 'blob' }).then(function (content) {
                            // see FileSaver.js
                            saveAs(content, 'images.zip');
                        });
                    } else {
                        zipImage();
                    }
                }, 100);
            }

            zipImage();
        },

        //传入图片路径，返回base64
        getBase64: function (img) {
            function getBase64Image(img, width, height) {
                //width、height调用时传入具体像素值，控制大小 ,不传则默认图像大小
                let canvas = document.createElement('canvas');
                canvas.width = width ? width : img.width;
                canvas.height = height ? height : img.height;
                let ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                return canvas.toDataURL()
            }

            let image = new Image();
            image.crossOrigin = 'Anonymous';
            image.src = img;
            let deferred = jQuery.Deferred();
            if (img) {
                image.onload = function () {
                    deferred.resolve(getBase64Image(image));//将base64传给done上传处理
                };
                return deferred.promise()//问题要让onload完成后再return sessionStorage['imgTest']
            }
        },
    };

    let regexStr$d = ['tuchong.com'];

    const website$e = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$d)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            $j(document).ready(function () {
                if (location.href.indexOf('stock.tuchong.com/topic') !== -1) {
                    createDownloadAllButtonTopic();
                } else if (location.href.indexOf('tuchong.com') !== -1) {
                    createDownloadButton();
                    createDownloadAllButton();
                }
            });
            // 获取套图地址
            // 添加下载套图按钮
            function createDownloadAllButtonTopic() {
                let container = $j('.justified-layout');
                if (container.length > 0) {
                    /*以下是添加HTML节点 和 下载事件 设置*/
                    let downloadAllIcon = '<svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" width="60" height="60"><path d="M512 512m-512 0a512 512 0 1 0 1024 0 512 512 0 1 0-1024 0Z" fill="#E52425" p-id="3019"></path><path d="M802.085 528.066c-19.343-24.572-43.631-40.047-73.004-46.567 4.013-11.965 6.018-24.286 6.018-36.968 0-28.154-9.313-52.083-27.94-71.784-18.627-19.63-41.266-29.517-67.845-29.517-19.272 0-36.896 5.66-52.872 16.907-13.971-25.289-33.24-45.707-57.885-61.182-24.575-15.475-51.368-23.212-80.313-23.212-28.943 0-55.665 7.594-80.31 22.71-24.646 15.188-44.06 35.75-58.388 61.756-14.257 26.078-21.422 54.234-21.422 84.466v8.455c-27.94 10.531-50.865 28.871-68.848 54.877-17.982 26.005-26.938 55.522-26.938 88.62 0 3.319 0.1 6.606 0.291 9.864 17.584-3.49 36.155-5.363 55.358-5.363 110.778 0 200.582 62.212 200.582 138.954 0 2.854-0.139 5.687-0.384 8.499H703.29c23.283 0 44.705-5.947 64.335-17.911 19.63-11.966 35.104-28.299 46.422-49.075 11.32-20.704 16.98-43.415 16.98-68.059 0-32.31-9.673-60.824-28.942-85.47zM596.4 574.489L490.656 686.396c-2.65 2.792-6.305 4.226-10.96 4.226-4.657 0-8.312-1.434-10.962-4.226L362.991 574.489c-4.657-4.871-5.66-10.889-3.009-17.909 2.651-7.021 7.665-10.53 14.972-10.53h64.837V427.84c0-4.873 1.503-8.955 4.513-12.107 3.008-3.152 6.805-4.729 11.462-4.729h47.928c4.658 0 8.454 1.576 11.462 4.729 3.01 3.152 4.516 7.163 4.516 12.107v118.21h64.834c7.308 0 12.323 3.51 14.975 10.53s1.648 13.038-3.081 17.909z" fill="#FFFFFF" p-id="3020"></path><path d="M247.988 601.128c-19.203 0-37.774 1.873-55.358 5.363 1.385 23.679 7.797 45.744 19.196 66.148 12.967 23.212 30.448 41.623 52.371 55.38 21.994 13.684 45.922 20.562 71.857 20.562h112.132c0.245-2.813 0.384-5.645 0.384-8.499 0-76.742-89.803-138.954-200.582-138.954z" fill="#FFFFFF" opacity=".4" p-id="3021"></path></svg>';
                    let downloadAllContainer = '<div id="maga-image-download-all" class="toolbar-icon">' + downloadAllIcon + '</div>';

                    let imgHrefs = container.find('.justified-layout__item');

                    $j('.toolbar-wrapper').append(downloadAllContainer);
                    $j('#maga-image-download-all').on('click', function () {
                        let imagePaires = [];
                        for (let i = 0; i < imgHrefs.length; i++) {
                            let imgUrl = $j(imgHrefs[i]).find('div').attr('data-lazy-url');
                            let imgName = imgUrl.split('/smh/')[1];

                            if (!/http/.test(imgUrl)) {
                                imgUrl = 'http:' + imgUrl;
                            }
                            imagePaires.push({imgUrl: imgUrl, imgName: imgName});
                        }
                        console.log(imagePaires, 'imagePaires');
                        Utils$1.packageImages(imagePaires);
                    });
                }
            }


            /*以下是添加HTML节点 和 下载事件 设置*/
            // 获取单页地址
            // 下载单页按钮
            function createDownloadButton() {
                let container = $j('.scene-container-next');
                if (container.length > 0) {
                    let nodeElement = '<span id="maga-image-download" class="maga-image-download">图片下载</span>';
                    $j('.theater-handler').append(nodeElement);
                    $j('#maga-image-download').on('click', function () {

                        let imgUrl = container
                            .find('.scene-item').not('.prev-scene').not('.next-scene')
                            .find('img').attr('src');

                        let imgName = $j('.aside-post-title').text() + imgUrl.split('/f/')[1];
                        let re = /http/;
                        if (!re.test(imgUrl)) {
                            imgUrl = 'http:' + imgUrl;
                        }
                        console.log('下载单页按钮-点击:imgUrl>>>' + imgUrl + '\t\timgName>>>' + imgName);

                        GM_download(imgUrl, imgName);
                    });
                }
            }

            // 获取套图地址
            // 下载套图按钮
            function createDownloadAllButton() {
                let container = $j('.scene-container-next');
                if (container.length > 0) {
                    let nodeElement = '<span id="maga-image-download-all" class="maga-image-download">套图下载</span>';
                    $j('.theater-handler').append(nodeElement);
                    $j('#maga-image-download-all').on('click', function () {

                        let imgItem = container.find('.scene-item');
                        let imagePaires = [];
                        for (let i = 0; i < imgItem.length; i++) {
                            let imgUrl = $j(imgItem[i]).find('img').attr('src');
                            let re = /http/;
                            if (!re.test(imgUrl)) {
                                imgUrl = 'http:' + imgUrl;
                            }
                            let ext = imgUrl.substring(imgUrl.lastIndexOf('.')) || 'jpg';
                            let imgName = new Date().getTime() + '_' + i.toString() + ext;
                            imagePaires.push({imgUrl: imgUrl, imgName: imgName});
                        }

                        console.log('下载套图按钮-点击:imagePaires>>>>>' + imagePaires);
                        Utils$1.packageImages(imagePaires);
                    });
                }
            }
        }
    };

    let images = {};

    function getWechatFileName(image, index) {
        let ext = '.jpg';
        if (image.indexOf('wx_fmt=gif') !== -1 ||
            image.indexOf('mmbiz_gif') !== -1) {
            ext = '.gif';
        }
        if (image.indexOf('wx_fmt=png') !== -1 ||
            image.indexOf('mmbiz_png') !== -1) {
            ext = '.png';
        }
        if (image.indexOf('wx_fmt=bmp') !== -1 ||
            image.indexOf('mmbiz_bmp') !== -1) {
            ext = '.bmp';
        }
        if (image.indexOf('wx_fmt=jpeg') !== -1 ||
            image.indexOf('mmbiz_jpeg') !== -1) {
            ext = '.jpeg';
        }
        return new Date().getTime() + '_' + index.toString() + ext
    }

    let regexStr$c = ['mp.weixin.qq.com/s'];

    const website$d = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$c)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            $j(document).ready(function () {

                let downloadButton = $j(`
                                <button class="maga-image-weixin-download" id="downloadButton">
                                    <span>一键下载所有图片</span> 
                                    <span id="photoNum"></span>
                                </button>
                                <a style="display:none;" download=""></a>`);

                downloadButton.on('click', function () {
                    if (images.length > 0) {
                        if (images.length == 1) {
                            GM_download(images[0].imgUrl, images[0].imgName);
                        } else {
                            Utils$1.packageImages(images);
                        }
                    }
                });
                $j('#img-content').prepend(downloadButton);

                let imageViews = $j('#js_content')[0].getElementsByTagName('img');
                let imagePaires = Array();
                for (let i = 0; i < imageViews.length; i++) {
                    let temp = imageViews[i].getAttribute('data-src');
                    let imageSrc = '';
                    if (temp && temp.length > 0) {
                        imageSrc = temp;
                    } else {
                        imageSrc = imageViews[i].getAttribute('src');
                    }
                    let imgUrl = imageSrc.replace('//res.wx.qq.com/mmbizwap', 'http://res.wx.qq.com/mmbizwap');
                    let imgName = getWechatFileName(imgUrl, i);
                    imagePaires.push({imgUrl: imgUrl, imgName: imgName});
                }
                images = imagePaires;
                // GM_log(images)
                $j('#photoNum')[0].innerText = '共' + images.length + '张';
            });
        }
    };

    let regexStr$b = ['zhihu.com'];

    const website$c = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$b)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            getStart();
        }
    };

    /**
     * 备注：
     * 此部分代码来自于王超先生的知乎视频下载脚本代码，开源协议为MIT协议，故加入到本插件中，感谢大佬的开源、共享精神！
     *
     * 原作者：王超， 脚本链接：https://greasyfork.org/zh-CN/scripts/39206
     * 版权归原作者所有
     */
    async function getStart(image, index) {

        console.log('知乎视频下载:');
        const playlistBaseUrl = 'https://lens.zhihu.com/api/v4/videos/';
        const videoId = window.location.pathname.split('/').pop(); // 视频id
        const menuStyle = 'transform:none !important; left:auto !important; right:-0.5em !important;';
        const playerId = 'player';
        const svgDownload = '<path d="M9.5,4 H14.5 V10 H17.8 L12,15.8 L6.2,10 H9.5 Z M6.2,18 H17.8 V20 H6.2 Z"></path>';
        const player = document.getElementById(playerId);
        const resolutions = [
            {ename: 'ld', cname: '普清'},
            {ename: 'sd', cname: '标清'},
            {ename: 'hd', cname: '高清'},
            {ename: 'fhd', cname: '超清'}
        ];
        let videos = []; // 存储各分辨率的视频信息

        function fetchRetry(url, options = {}, times = 1, delay = 1000, checkStatus = true) {
            return new Promise((resolve, reject) => {
                // fetch 成功处理函数
                function success(res) {
                    if (checkStatus && !res.ok) {
                        failure(res);
                    } else {
                        resolve(res);
                    }
                }

                // 单次失败处理函数
                function failure(error) {
                    if (--times) {
                        setTimeout(fetchUrl, delay);
                    } else {
                        reject(error);
                    }
                }

                // 总体失败处理函数
                function finalHandler(error) {
                    throw error
                }

                function fetchUrl() {
                    return fetch(url, options)
                        .then(success)
                        .catch(failure)
                        .catch(finalHandler)
                }

                fetchUrl();
            })
        }

        // 下载指定url的资源
        async function downloadUrl(url, name = (new Date()).valueOf() + '.mp4') {
            // Greasemonkey 需要把 url 转为 blobUrl
            if (GM_info.scriptHandler === 'Greasemonkey') {
                const res = await fetchRetry(url);
                const blob = await res.blob();
                url = URL.createObjectURL(blob);
            }

            // Chrome 可以使用 Tampermonkey 的 GM_download 函数绕过 CSP(Content Security Policy) 的限制
            if (window.GM_download) {
                GM_download({url, name});
            } else {
                // firefox 需要禁用 CSP, about:config -> security.csp.enable => false
                let a = document.createElement('a');
                a.href = url;
                a.download = name;
                a.style.display = 'none';
                // a.target = '_blank';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);

                setTimeout(() => URL.revokeObjectURL(url), 100);
            }
        }

        // 格式化文件大小
        function humanSize(size) {
            let n = Math.log(size) / Math.log(1024) | 0;
            return (size / Math.pow(1024, n)).toFixed(0) + ' ' + (n ? 'KMGTPEZY'[--n] + 'B' : 'Bytes')
        }

        if (!player) return

        // 获取视频信息
        const res = await fetchRetry(playlistBaseUrl + videoId, {
            headers: {
                'referer': 'refererBaseUrl + videoId',
                'authorization': 'oauth c3cef7c66a1843f8b3a9e6a1e3160e20' // in zplayer.min.js of zhihu
            }
        }, 3);
        const videoInfo = await res.json();

        // 获取不同分辨率视频的信息
        for (const [key, video] of Object.entries(videoInfo.playlist)) {
            video.name = key.toLowerCase();
            video.cname = resolutions.find(v => v.ename === video.name)?.cname;
            if (!videos.find(v => v.size === video.size)) {
                videos.push(video);
            }
        }

        // 按格式大小排序
        videos = videos.sort(function (v1, v2) {
            const v1Index = resolutions.findIndex(v => v.ename === v1.name);
            const v2Index = resolutions.findIndex(v => v.ename === v2.name);

            return v1Index === v2Index ? 0 : (v1Index > v2Index ? 1 : -1)
            // return v1.size === v2.size ? 0 : (v1.size > v2.size ? 1 : -1);
        }).reverse();

        document.addEventListener('DOMNodeInserted', (evt) => {
            const domControlBar = evt.relatedNode.querySelector(':scope > div:last-child > div:first-child > div:nth-of-type(2)');
            if (!domControlBar || domControlBar.querySelector('.download')) return

            const domButtonsBar = domControlBar.querySelector(':scope > div:last-child');
            const domFullScreenBtn = domButtonsBar.querySelector(':scope > div:nth-last-of-type(2)');
            const domResolutionBtn = Array.from(domButtonsBar.querySelectorAll(':scope > div')).filter(el => el.innerText.substr(1, 1) === '清')[0];
            let domDownloadBtn, buttons;
            if (!domFullScreenBtn || !domFullScreenBtn.querySelector('button')) return

            // 克隆分辨率菜单或全屏按钮为下载按钮
            domDownloadBtn = (domResolutionBtn && (domResolutionBtn.className === domFullScreenBtn.className))
                ? domResolutionBtn.cloneNode(true)
                : domFullScreenBtn.cloneNode(true);

            domDownloadBtn.querySelector('button').innerText;

            // 生成下载按钮图标
            domDownloadBtn.querySelector('button:first-child').outerHTML = domFullScreenBtn.cloneNode(true).querySelector('button').outerHTML;
            domDownloadBtn.querySelector('svg').innerHTML = svgDownload;
            domDownloadBtn.className = domDownloadBtn.className + ' download';

            buttons = domDownloadBtn.querySelectorAll('button');

            // button 元素添加对应的下载地址属性
            buttons.forEach(dom => {
                const video = videos.find(v => v.cname === dom.innerText) || videos[videos.length - 1];

                dom.dataset.video = video.play_url;
                if (dom.innerText) {
                    (dom.innerText = `${dom.innerText} (${humanSize(video.size)})`);
                } else if (buttons.length == 1) {
                    let domText = dom.nextSibling.querySelector('div');
                    if (domText) {
                        domText.innerText = humanSize(video.size);
                    }
                }
            });

            // 鼠标事件 - 显示菜单
            domDownloadBtn.addEventListener('pointerenter', () => {
                const domMenu = domDownloadBtn.querySelector('div:nth-of-type(1)');
                if (domMenu) {
                    domMenu.style.cssText = menuStyle + 'opacity:1 !important; visibility:visible !important';
                }
            });

            // 鼠标事件 - 隐藏菜单
            domDownloadBtn.addEventListener('pointerleave', () => {
                const domMenu = domDownloadBtn.querySelector('div:nth-of-type(1)');
                if (domMenu) {
                    domMenu.style.cssText = menuStyle;
                }
            });

            // 鼠标事件 - 选择菜单项
            domDownloadBtn.addEventListener('pointerup', event => {
                let e = event.srcElement || event.target;

                while (e.tagName !== 'BUTTON') {
                    e = e.parentNode;
                }

                downloadUrl(e.dataset.video);
            });

            // 显示下载按钮
            domButtonsBar.appendChild(domDownloadBtn);
        });
    }

    const filename = 'twitter_{user-name}(@{user-id})_{date-time}_{status-id}_{file-type}';

    const language = {
        zh: {
            download: '下载',
            completed: '下载完成',
            settings: '设置',
            dialog: {
                title: '下载设置',
                save: '保存',
                record: '保存下载记录',
                clear: '(清除)',
                confirm: '确认要清除下载记录？',
                pattern: '文件名格式'
            }
        },
    };

    const svg = `
<g class="download"><path d="M3,14 v5 q0,2 2,2 h14 q2,0 2,-2 v-5 M7,10 l4,4 q1,1 2,0 l4,-4 M12,3 v11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" /></g>
<g class="completed"><path d="M3,14 v5 q0,2 2,2 h14 q2,0 2,-2 v-5 M7,10 l3,4 q1,1 2,0 l8,-11" fill="none" stroke="#1DA1F2" stroke-width="2" stroke-linecap="round" /></g>
<g class="loading"><circle cx="12" cy="12" r="10" fill="none" stroke="#1DA1F2" stroke-width="4" opacity="0.4" /><path d="M12,2 a10,10 0 0 1 10,10" fill="none" stroke="#1DA1F2" stroke-width="4" stroke-linecap="round" /></g>
<g class="failed"><circle cx="12" cy="12" r="11" fill="#f33" stroke="currentColor" stroke-width="2" opacity="0.8" /><path d="M14,5 a1,1 0 0 0 -4,0 l0.5,9.5 a1.5,1.5 0 0 0 3,0 z M12,17 a2,2 0 0 0 0,4 a2,2 0 0 0 0,-4" fill="#fff" stroke="none" /></g>
`;
    let lang, history;

    let regexStr$a = ['twitter'];

    const website$b = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$a)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            GM_registerMenuCommand((language[navigator.language] || language.zh).settings, this.settings);
            lang = language[document.querySelector('html').lang] || language.zh;
            history = this.storage('history');
            new MutationObserver(callback => {
                callback.forEach(m => m.addedNodes.forEach(node => {
                    let article = node.tagName == 'DIV'
                        && (node.querySelector('article') || node.closest('article'));
                    if (article && !article.dataset.injected) {
                        this.inject(article);
                    }
                }));
            }).observe(document.body, {childList: true, subtree: true});
        },
        inject: function (article) {
            let mediaSelector = [
                'a[href*="/photo/1"]', 'div[role="progressbar"]',
                'div[data-testid="playButton"]', 'a[href="/settings/safety"]'
            ];
            let media = article.querySelector(mediaSelector.join(','));
            if (media) {
                let statusId = article.querySelector('a[href*="/status/"]').href.split('/status/').pop().split('/').shift();
                let btnGroup = article.querySelector('div[role="group"]');
                let btnShare = Array.from(btnGroup.querySelectorAll(':scope>div>div')).pop().parentNode;
                let btnDown = btnShare.cloneNode(true);
                btnDown.querySelector('svg').innerHTML = svg;
                let isExist = history.indexOf(statusId) !== -1;
                this.status(btnDown, 'tmd-down');
                this.status(btnDown, isExist ? 'completed' : 'download', isExist ? lang.completed : lang.download);
                btnGroup.insertBefore(btnDown, btnShare.nextSibling);
                btnDown.onclick = () => this.click(btnDown, statusId, isExist);
                article.dataset.injected = 'true';
            }
        },
        click: async function (btn, statusId, isExist) {
            if (btn.classList.contains('loading')) return
            this.status(btn, 'loading');
            let out = (await GM_getValue('filename', filename)).split('\n').join('');
            let record = await GM_getValue('record', true);
            let json = await this.fetchJson(statusId);
            let tweet = json.globalObjects.tweets[statusId];
            let user = json.globalObjects.users[tweet.user_id_str];
            let invalidChars = {
                '\\': '＼', '\/': '／',
                '\|': '｜', '<': '＜',
                '>': '＞', ':': '：',
                '*': '＊', '?': '？',
                '"': '＂', '🔞': ''
            };
            let datetime = out.match(/{date-time(-local)?:[^{}]+}/) ? out.match(/{date-time(?:-local)?:([^{}]+)}/)[1].replace(/[\\\/\|<>\*\?:"]/g, v => invalidChars[v]) : 'YYYYMMDD-hhmmss';
            let info = {};
            info['status-id'] = statusId;
            info['user-name'] = user.name.replace(/([\\\/\|\*\?:"]|🔞)/g, v => invalidChars[v]);
            info['user-id'] = user.screen_name;
            info['date-time'] = this.formatDate(tweet.created_at, datetime);
            info['date-time-local'] = this.formatDate(tweet.created_at, datetime, true);
            info['full-text'] = tweet.full_text.split('\n').join(' ').replace(/\s*https:\/\/t\.co\/\w+/g, '').replace(/[\\\/\|<>\*\?:"]/g, v => invalidChars[v]);
            let medias = tweet.extended_entities && tweet.extended_entities.media;
            if (medias.length > 0) {
                let tasks = medias.length;
                let tasksResult = [];
                medias.forEach((media, i) => {
                    info.url = media.type == 'photo' ? media.media_url + ':orig' : media.video_info.variants.filter(n => n.content_type == 'video/mp4').sort((a, b) => b.bitrate - a.bitrate)[0].url;
                    info.file = info.url.split('/').pop().split(/[:?]/).shift();
                    info['file-name'] = info.file.split('.').shift();
                    info['file-ext'] = info.file.split('.').pop();
                    info['file-type'] = media.type.replace('animated_', '');
                    info.out = (out.replace(/\.?{file-ext}/, '') + (medias.length > 1 && !out.match('{file-name}') ? '-' + i : '') + '.{file-ext}').replace(/{([^{}:]+)(:[^{}]+)?}/g, (match, name) => info[name]);
                    this.downloader().add({
                        url: info.url,
                        name: info.out,
                        onload: () => {
                            tasks -= 1;
                            tasksResult.push((medias.length > 1 ? i + 1 + ': ' : '') + lang.completed);
                            this.status(btn, null, tasksResult.sort().join('\n'));
                            if (tasks === 0) {
                                this.status(btn, 'completed', lang.completed);
                                if (record && !isExist) {
                                    history.push(statusId);
                                    this.storage('history', statusId);
                                }
                            }
                        },
                        onerror: result => {
                            tasks = -1;
                            tasksResult.push((medias.length > 1 ? i + 1 + ': ' : '') + result.details.current);
                            this.status(btn, 'failed', tasksResult.sort().join('\n'));
                        }
                    });
                });
            } else {
                this.status(btn, 'failed', 'MEDIA_NOT_FOUND');
            }
        },
        status: function (btn, css, title, style) {
            if (css) {
                btn.classList.remove('download', 'completed', 'loading', 'failed');
                btn.classList.add(css);
            }
            if (title) btn.title = title;
            if (style) btn.style.cssText = style;
        },
        settings: async function () {
            const $element = (parent, tag, style, content, css) => {
                let el = document.createElement(tag);
                if (style) el.style.cssText = style;
                if (typeof content !== 'undefined') {
                    if (tag == 'input') {
                        if (content == 'checkbox') el.type = content;
                        else el.value = content;
                    } else el.innerHTML = content;
                }
                if (css) css.split(' ').forEach(c => el.classList.add(c));
                parent.appendChild(el);
                return el
            };
            let wapper = $element(document.body, 'div', 'position: fixed; left: 0px; top: 0px; width: 100%; height: 100%; background-color: #0009; z-index: 10;');
            let wapperClose;
            wapper.onmousedown = e => {
                wapperClose = e.target == wapper;
            };
            wapper.onmouseup = e => {
                if (wapperClose && e.target == wapper) wapper.remove();
            };
            let dialog = $element(wapper, 'div', 'position: absolute; left: 50%; top: 50%; transform: translateX(-50%) translateY(-50%); width: fit-content; width: -moz-fit-content; background-color: #f3f3f3; border: 1px solid #ccc; border-radius: 10px;');
            let title = $element(dialog, 'h3', 'margin: 10px 20px;', lang.dialog.title);
            let options = $element(dialog, 'div', 'margin: 10px; border: 1px solid #ccc; border-radius: 5px;');
            let recordLabel = $element(options, 'label', 'display: block; margin: 10px;', lang.dialog.record);
            let recordInput = $element(recordLabel, 'input', 'float: left;', 'checkbox');
            recordInput.checked = await GM_getValue('history', true);
            recordInput.onchange = () => GM_setValue('history', recordInput.checked);
            let recordClear = $element(recordLabel, 'label', 'margin: 10px; color: blue;', lang.dialog.clear);
            recordClear.onclick = () => {
                if (confirm(lang.dialog.confirm)) {
                    history = [];
                    localStorage.removeItem('history');
                }
            };
            let filenameDiv = $element(dialog, 'div', 'margin: 10px; border: 1px solid #ccc; border-radius: 5px;');
            let filenameLabel = $element(filenameDiv, 'label', 'display: block; margin: 10px 15px;', lang.dialog.pattern);
            let filenameInput = $element(filenameLabel, 'textarea', 'display: block; min-width: 500px; max-width: 500px; min-height: 100px; font-size: inherit;', await GM_getValue('filename', filename));
            let filenameTags = $element(filenameDiv, 'label', 'display: table; margin: 10px;',
                `
                    <span class="tmd-tag" title="user name">{user-name}</span>
                    <span class="tmd-tag" title="The user name after @ sign.">{user-id}</span>
                    <span class="tmd-tag" title="example: 1234567890987654321">{status-id}</span>
                    <span class="tmd-tag" title="{date-time} : Posted time in UTC.\n{date-time-local} : Your local time zone.\n\nDefault:\nYYYYMMDD-hhmmss => 20201231-235959\n\nExample of custom:\n{date-time:DD-MMM-YY hh.mm} => 31-DEC-21 23.59">{date-time}</span><br>
                    <span class="tmd-tag" title="Text content in tweet.">{full-text}</span>
                    <span class="tmd-tag" title="Type of &#34;video&#34; or &#34;photo&#34; or &#34;gif&#34;.">{file-type}</span>
                    <span class="tmd-tag" title="Original filename from URL.">{file-name}</span>`
            );
            filenameInput.selectionStart = filenameInput.value.length;
            filenameTags.querySelectorAll('.tmd-tag').forEach(tag => {
                tag.onclick = () => {
                    let ss = filenameInput.selectionStart;
                    let se = filenameInput.selectionEnd;
                    filenameInput.value = filenameInput.value.substring(0, ss) + tag.innerText + filenameInput.value.substring(se);
                    filenameInput.selectionStart = ss + tag.innerText.length;
                    filenameInput.selectionEnd = ss + tag.innerText.length;
                    filenameInput.focus();
                };
            });
            let btnSave = $element(title, 'label', 'float: right;', lang.dialog.save, 'tmd-btn');
            btnSave.onclick = async () => {
                await GM_setValue('filename', filenameInput.value);
                wapper.remove();
            };
        },
        fetchJson: async function (statusId) {
            let url = 'https://twitter.com/i/api/2/timeline/conversation/' + statusId + '.json?tweet_mode=extended&include_entities=false&include_user_entities=false';
            let cookies = this.getCookie();
            let headers = {
                'authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA',
                'x-twitter-active-user': 'yes',
                'x-twitter-client-language': cookies.lang,
                'x-csrf-token': cookies.ct0
            };
            if (cookies.ct0.length == 32) headers['x-guest-token'] = cookies.gt;
            return await fetch(url, {headers: headers}).then(result => result.json())
        },
        getCookie: function (name) {
            let cookies = {};
            document.cookie.split(';').filter(n => n.indexOf('=') !== -1).forEach(n => {
                n.replace(/^([^=]+)=(.+)$/, (match, name, value) => {
                    cookies[name.trim()] = value.trim();
                });
            });
            return name ? cookies[name] : cookies
        },
        storage: function (name, value) {
            let data = JSON.parse(localStorage.getItem(name) || '[]');
            if (value) data.push(value);
            else return data
            localStorage.setItem(name, JSON.stringify(data));
        },
        formatDate: function (i, o, tz) {
            let d = new Date(i);
            if (tz) d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
            let m = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
            let v = {
                YYYY: d.getUTCFullYear().toString(),
                YY: d.getUTCFullYear().toString(),
                MM: d.getUTCMonth() + 1,
                MMM: m[d.getUTCMonth()],
                DD: d.getUTCDate(),
                hh: d.getUTCHours(),
                mm: d.getUTCMinutes(),
                ss: d.getUTCSeconds(),
                h2: d.getUTCHours() % 12,
                ap: d.getUTCHours() < 12 ? 'AM' : 'PM'
            };
            return o.replace(/(YY(YY)?|MMM?|DD|hh|mm|ss|h2|ap)/g, n => ('0' + v[n]).substr(-n.length))
        },
        downloader: function () {
            let tasks = [], thread = 0, maxThread = 2, retry = 0, maxRetry = 2, failed = 0, notifier,
                hasFailed = false;
            return {
                add: function (task) {
                    tasks.push(task);
                    if (thread < maxThread) {
                        thread += 1;
                        this.next();
                    } else {
                        this.update();
                    }
                },
                next: async function () {
                    let task = tasks.shift();
                    await this.start(task);
                    if (tasks.length > 0 && thread <= maxThread) this.next();
                    else thread -= 1;
                    this.update();
                },
                start: function (task) {
                    this.update();
                    return new Promise(resolve => {
                        GM_download({
                            url: task.url,
                            name: task.name,
                            onload: result => {
                                task.onload();
                                resolve();
                            },
                            onerror: result => {
                                this.retry(task, result);
                                resolve();
                            },
                            ontimeout: result => {
                                this.retry(task, result);
                                resolve();
                            }
                        });
                    })
                },
                retry: function (task, result) {
                    retry += 1;
                    if (retry == 3) maxThread = 1;
                    if (task.retry && task.retry >= maxRetry ||
                        result.details && result.details.current == 'USER_CANCELED') {
                        task.onerror(result);
                        failed += 1;
                    } else {
                        if (maxThread == 1) task.retry = (task.retry || 0) + 1;
                        this.add(task);
                    }
                },
                update: function () {
                    if (!notifier) {
                        notifier = document.createElement('div');
                        notifier.title = 'Twitter Media Downloader';
                        notifier.classList.add('tmd-notifier');
                        notifier.innerHTML = '<label>0</label>|<label>0</label>';
                        document.body.appendChild(notifier);
                    }
                    if (failed > 0 && !hasFailed) {
                        hasFailed = true;
                        notifier.innerHTML += '|';
                        let clear = document.createElement('label');
                        notifier.appendChild(clear);
                        clear.onclick = () => {
                            notifier.innerHTML = '<label>0</label>|<label>0</label>';
                            failed = 0;
                            hasFailed = false;
                            this.update();
                        };
                    }
                    notifier.firstChild.innerText = thread;
                    notifier.firstChild.nextElementSibling.innerText = tasks.length;
                    if (failed > 0) notifier.lastChild.innerText = failed;
                    if (thread > 0 || tasks.length > 0 || failed > 0) notifier.classList.add('running');
                    else notifier.classList.remove('running');
                }
            }
        }
    };

    let regexStr$9 = ['facebook.com'];

    const website$a = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$9)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            $j(document).ready(function () {
                let container = $j('body');
                let nodeElement = '<span id="maga-video-download" class="maga-video-download">视频下载</span>';
                container.append(nodeElement);
                $j('#maga-video-download').on('click', function () {
                    GM_openInTab('https://yt1s.com/facebook-downloader/en2');
                });
            });
        }
    };

    let regexStr$8 = ['youtube.com/watch'];

    const website$9 = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$8)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            let container = $j('body');
            let nodeElement = '<span id="maga-video-download" class="maga-video-download">视频下载</span>';
            container.append(nodeElement);
            $j('#maga-video-download').on('click', function () {
                GM_openInTab('https://yt1s.com/en260?q=' + encodeURIComponent(window.location.href));
            });
        }
    };

    const modules$4 = [website$e, website$d, website$c, website$b, website$a, website$9];

    const prepare$4 = {
        init: function ($j, runType) {
            GM_addStyle(CSS_STR$3);
            for (let i = 0; i < modules$4.length; i++) {
                let module = modules$4[i];
                if (module.intercepter()) {
                    continue
                }
                module.setRunType((typeof runType === 'undefined') ? 'alone' : runType);
                module.init($j);
            }
        }
    };
    let CSS_STR$3 = `
/*图虫下载按钮*/
.maga-image-download {
    color: #fff;
    background-color: #5CB85C;
    cursor: pointer;
    display: inline-block;
    font-weight: 400;
    text-align: center;
    vertical-align: middle;
    padding: 6px 12px;
    margin: 0 24px;
    border-radius: 4px;
    border-color: transparent;
    box-sizing: border-box;
    font-size: 14px;
}
/*微信下载按钮*/
.maga-image-weixin-download {
    color: #fff;
    background-color: #5CB85C;
    cursor: pointer;
    display: inline-block;
    font-weight: 400;
    text-align: center;
    vertical-align: middle;
    padding: 6px 12px;
    border-radius: 4px;
    margin: 10px 0;
    border-color: transparent;
    box-sizing: border-box;
    font-size: 14px;
}

/*FaceBook YouTube视频下载按钮*/
.maga-video-download {
    bottom: 180px;
    right: 50px;
    position: fixed;
    width: 48px;
    word-wrap: break-word;
    color: #fff;
    background-color: #5CB85C;
    cursor: pointer;
    display: inline-block;
    font-weight: 400;
    text-align: center;
    vertical-align: middle;
    padding: 6px 6px;
    border-radius: 4px;
    box-sizing: border-box;
    font-size: 14px;
}

/*Twitter视频下载按钮*/
.tmd-down > div > div > div:nth-child(2) {
    display: none
}

.tmd-down:hover > div > div {
    color: rgba(29, 161, 242, 1.0);
}

.tmd-down:hover > div > div > div > div {
    background-color: rgba(29, 161, 242, 0.1);
}

.tmd-down:active > div > div > div > div {
    background-color: rgba(29, 161, 242, 0.2);
}

.tmd-down g {
    display: none;
}

.tmd-down.download g.download, .tmd-down.completed g.completed, .tmd-down.loading g.loading, .tmd-down.failed g.failed {
    display: unset;
}

.tmd-down.loading svg {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
}

.tmd-btn {
    display: inline-block;
    background-color: #1DA1F2;
    color: #FFFFFF;
    padding: 0 20px;
    border-radius: 99px;
}

.tmd-tag {
    display: inline-block;
    background-color: #FFFFFF;
    color: #1DA1F2;
    padding: 0 10px;
    border-radius: 10px;
    border: 1px solid #1DA1F2;
    font-weight: bold;
    margin: 5px;
}

.tmd-btn:hover {
    background-color: rgba(29, 161, 242, 0.9);
}

.tmd-tag:hover {
    background-color: rgba(29, 161, 242, 0.1);
}

.tmd-notifier {
    display: none;
    position: fixed;
    left: 16px;
    bottom: 16px;
    background: #fff;
    border: 1px solid #ccc;
    border-radius: 8px;
    padding: 4px;
}

.tmd-notifier.running {
    display: flex;
    align-items: center;
}

.tmd-notifier label {
    display: inline-flex;
    align-items: center;
    margin: 0 8px;
}

.tmd-notifier label:before {
    content: " ";
    width: 32px;
    height: 16px;
    background-position: center;
    background-repeat: no-repeat;
}

.tmd-notifier label:nth-child(1):before {
    background-image: url("data:image/svg+xml;charset=utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2216%22 height=%2216%22 viewBox=%220 0 24 24%22><path d=%22M3,14 v5 q0,2 2,2 h14 q2,0 2,-2 v-5 M7,10 l4,4 q1,1 2,0 l4,-4 M12,3 v11%22 fill=%22none%22 stroke=%22%23666%22 stroke-width=%222%22 stroke-linecap=%22round%22 /></svg>");
}

.tmd-notifier label:nth-child(2):before {
    background-image: url("data:image/svg+xml;charset=utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2216%22 height=%2216%22 viewBox=%220 0 24 24%22><path d=%22M12,2 a1,1 0 0 1 0,20 a1,1 0 0 1 0,-20 M12,5 v7 h6%22 fill=%22none%22 stroke=%22%23999%22 stroke-width=%222%22 stroke-linejoin=%22round%22 stroke-linecap=%22round%22 /></svg>");
}

.tmd-notifier label:nth-child(3):before {
    background-image: url("data:image/svg+xml;charset=utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2216%22 height=%2216%22 viewBox=%220 0 24 24%22><path d=%22M12,0 a2,2 0 0 0 0,24 a2,2 0 0 0 0,-24%22 fill=%22%23f66%22 stroke=%22none%22 /><path d=%22M14.5,5 a1,1 0 0 0 -5,0 l0.5,9 a1,1 0 0 0 4,0 z M12,17 a2,2 0 0 0 0,5 a2,2 0 0 0 0,-5%22 fill=%22%23fff%22 stroke=%22none%22 /></svg>");
}
`;

    let KEY_BUTTON_TOP = 'maga-tag-navigator-button-top';
    let KEY_BUTTON_LEFT = 'maga-tag-navigator-button-left';

    let regexStr$7 = [];

    const website$8 = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$7)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            setTimeout(function () {
                if (location.href.indexOf('360kan.com') !== -1 ||

                    location.href.indexOf('iqiyi.com') !== -1 ||

                    location.href.indexOf('movie.douban.com/subject') !== -1 ||

                    location.href.indexOf('v.qq.com') !== -1 ||

                    location.href.indexOf('youku.com') !== -1 ||

                    location.href.indexOf('mgtv.com') !== -1 ||

                    location.href.indexOf('tv.sohu.com') !== -1 ||

                    location.href.indexOf('le.com') !== -1 ||

                    location.href.indexOf('pptv.com') !== -1 ||

                    location.href.indexOf('www.wasu.cn') !== -1 ||

                    location.href.indexOf('qidian.com') !== -1 ||

                    location.href.indexOf('douyin.com') !== -1 ||

                    location.href.indexOf('iesdouyin.com') !== -1 ||

                    location.href.indexOf('huoshan.com') !== -1 ||

                    location.href.indexOf('kuaishou.com') !== -1 ||

                    location.href.indexOf('gifshow.com') !== -1 ||

                    location.href.indexOf('chenzhongtech.com') !== -1 ||

                    location.href.indexOf('pipix.com') !== -1 ||

                    location.href.indexOf('weishi.qq.com') !== -1 ||

                    location.href.indexOf('izuiyou.com') !== -1 ||

                    location.href.indexOf('bilibili.com/video') !== -1 ||

                    location.href.indexOf('m.hanyuhl.com') !== -1 ||

                    location.href.indexOf('m.acfun.cn/v/') !== -1) {

                    if ($j('#maga-navigator').length !== 0) return

                    GM_addStyle(GM_getResourceText('toastr_css'));

                    let menus;
                    if (location.href.indexOf('qidian.com') !== -1) {
                        menus = [
                            {title: '电影搜索', show: '电影<br>搜索', type: 'video'},
                            {title: '免费小说', show: '免费<br>小说', type: 'novel'},
                            {title: '淘宝好券', show: '网购<br>优惠', type: 'tb'},
                            {title: '京东好券', show: '京东<br>好券', type: 'jd'},
                        ];
                    } else if (location.href.indexOf('movie.douban.com/subject') !== -1) {
                        menus = [
                            {title: '豆瓣资源', show: '电影<br>搜索', type: 'movie_douban'},
                            {title: '免费小说', show: '免费<br>小说', type: 'novel'},
                            {title: '淘宝好券', show: '网购<br>优惠', type: 'tb'},
                            {title: '京东好券', show: '京东<br>好券', type: 'jd'},
                        ];
                    } else if (
                        location.href.indexOf('douyin.com') !== -1 ||
                        location.href.indexOf('iesdouyin.com') !== -1 ||
                        location.href.indexOf('huoshan.com') !== -1 ||
                        location.href.indexOf('kuaishou.com') !== -1 ||
                        location.href.indexOf('gifshow.com') !== -1 ||
                        location.href.indexOf('chenzhongtech.com') !== -1 ||
                        location.href.indexOf('pipix.com') !== -1 ||
                        location.href.indexOf('weishi.qq.com') !== -1 ||
                        location.href.indexOf('izuiyou.com') !== -1 ||
                        location.href.indexOf('m.hanyuhl.com') !== -1 ||
                        location.href.indexOf('bilibili.com/video') !== -1 ||
                        location.href.indexOf('m.acfun.cn/v/') !== -1) {

                        menus = [
                            {title: '电影搜索', show: '电影<br>搜索', type: 'video'},
                            {title: '视频解析', show: '视频<br>解析', type: 'parse'},
                            {title: '淘宝好券', show: '网购<br>优惠', type: 'tb'},
                            {title: '京东好券', show: '京东<br>好券', type: 'jd'},
                        ];
                    } else {
                        menus = [
                            {title: '电影搜索', show: '电影<br>搜索', type: 'video'},
                            {title: '视频解析', show: '视频<br>解析', type: 'movie'},
                            {title: '淘宝好券', show: '网购<br>优惠', type: 'tb'},
                            {title: '京东好券', show: '京东<br>好券', type: 'jd'},
                        ];
                    }
                    GM_registerMenuCommand('复位工具按钮位置', function () {
                        GM_deleteValue(KEY_BUTTON_TOP);
                        GM_deleteValue(KEY_BUTTON_LEFT);
                        let mainMenu = $j('#maga-navigator')[0];
                        mainMenu.style.top = 350;
                        mainMenu.style.left = 0;
                    });

                    setTimeout(function () {
                        initMenu(menus);
                    }, 400);
                }

                function initMenu(obj) {
                    let menusClass = ['first', 'second', 'third', 'fourth', 'fifth'];
                    let menu = '';
                    $j.each(obj, function (i, item) {
                        menu = menu + `
                                <a href="javascript:void(0)" title="${item.title}" 
                                    data-cat="${item.type}" class="menu-item menu-line menu-${menusClass[i]}">
                                    ${item.show}
                                </a>`;
                    });

                    let sideNavigator = `
                                <div class="maga-side-navigator bounceInUp animated" id="maga-navigator">
                                    <label for="" class="maga-side-menu" title="按住拖动">工具</label>${menu}
                                </div>`;
                    $j('body').append(sideNavigator);

                    let mainMenu = $j('#maga-navigator')[0];
                    mainMenu.style.top = GM_getValue(KEY_BUTTON_TOP, mainMenu.style.top);
                    mainMenu.style.left = GM_getValue(KEY_BUTTON_LEFT, mainMenu.style.left);

                    let drags = {down: false, x: 0, y: 0, clientX: 0, clientY: 0};

                    $j('body').on('mousedown', '#maga-navigator', function (a) {
                        drags.down = true;
                        drags.clientX = a.clientX;
                        drags.clientY = a.clientY;
                        drags.x = getCss(this, 'left');
                        drags.y = getCss(this, 'top');
                        drags.winHeight = $j(window).height();
                        drags.winWidth = $j(window).width();
                        $j(document).on('mousemove', function (a) {
                            let xMove = a.clientX - drags.clientX;
                            let yMove = a.clientY - drags.clientY;
                            mainMenu.style.top = parseInt(drags.y) + yMove + 'px';
                            mainMenu.style.left = parseInt(drags.x) + xMove + 'px';

                            GM_setValue(KEY_BUTTON_TOP, mainMenu.style.top);
                            GM_setValue(KEY_BUTTON_LEFT, mainMenu.style.left);
                        });
                    }).on('mouseup', '#maga-navigator', function () {
                        drags.down = false;
                        $j(document).off('mousemove');
                    });

                    $j('body').on('click', '[data-cat=movie]', function () {//视频解析
                        GM_openInTab('http://video.bwaq.cn/#/player?url=' + encodeURIComponent(window.location.href));
                    });
                    $j('body').on('click', '[data-cat=video]', function () {//电影搜索
                        GM_openInTab('http://video.bwaq.cn');
                    });
                    $j('body').on('click', '[data-cat=movie_douban]', function () {//电影资源：豆瓣
                        let keyword = $j('head').title.replace(' (豆瓣)', '');
                        console.log('var keyword = ' + $j('head').title);
                        let url = 'http://video.bwaq.cn/#/category/360?keyword=' + encodeURIComponent(keyword);
                        GM_openInTab(url);
                    });
                    $j('body').on('click', '[data-cat=tb]', function () {
                        GM_openInTab('https://link.zhihu.com/?target=' + encodeURIComponent('http://payback.bwaq.cn?channel=tbk'));
                    });
                    $j('body').on('click', '[data-cat=jd]', function () {
                        GM_openInTab('http://jd.bwaq.cn');
                    });
                    $j('body').on('click', '[data-cat=novel]', function () {
                        GM_openInTab('http://payback.bwaq.cn/download/novel');
                    });
                    $j('body').on('click', '[data-cat=parse]', function () {
                        GM_openInTab('http://tools.bwaq.cn/#/video/parse?url=' + encodeURIComponent(window.location.href));
                    });
                }

                let getCss = function (element, properties) {
                    return document.defaultView.getComputedStyle(element, null)[properties]
                };
            }, 200);
        },
    };

    const modules$3 = [website$8];

    const prepare$3 = {
        init: function ($j, runType) {
            if (GUtils.inIframe()) {
                return
            }
            GM_addStyle(CSS_STR$2);
            for (let i = 0; i < modules$3.length; i++) {
                let module = modules$3[i];
                if (module.intercepter()) {
                    continue;
                }
                module.setRunType((typeof runType === 'undefined') ? 'alone' : runType);
                module.init($j);
            }
        }
    };


    let CSS_STR$2 = `
html {
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%;
    -webkit-font-smoothing: antialiased;
}

body .maga-side-navigator {
    font-family: "Helvetica Neue", Helvetica, "Microsoft YaHei", Arial, sans-serif;
    margin: 0;
    font-size: 1.6rem;
    /*用于调试时查看控件的面积*/
    /*background-color: #f9f9f9;*/
    color: #4E546B
}

.maga-side-navigator {
    position: fixed;
    /*right: 0;*/
    top: 350px;
    width: 260px;
    height: 260px;
    -webkit-filter: url(#goo);
    filter: url(#goo);
    -ms-user-select: none;
    -moz-user-select: none;
    -webkit-user-select: none;
    user-select: none;
    opacity: .75;
    z-index: 99999999;
}

.maga-side-navigator.no-filter {
    -webkit-filter: none;
    filter: none
}

.maga-side-navigator .maga-side-menu {
    position: absolute;
    width: 70px;
    height: 70px;
    -webkit-border-radius: 50%;
    border-radius: 50%;
    background: #f34444;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    text-align: center;
    line-height: 70px;
    color: #fff;
    font-size: 20px;
    z-index: 1;
    cursor: move
}

.maga-side-navigator .menu-item {
    position: absolute;
    width: 60px;
    height: 60px;
    background-color: #FF7676;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    line-height: 60px;
    text-align: center;
    -webkit-border-radius: 50%;
    border-radius: 50%;
    text-decoration: none;
    color: #fff;
    -webkit-transition: background .5s, -webkit-transform .6s;
    transition: background .5s, -webkit-transform .6s;
    -moz-transition: transform .6s, background .5s, -moz-transform .6s;
    transition: transform .6s, background .5s;
    transition: transform .6s, background .5s, -webkit-transform .6s, -moz-transform .6s;
    font-size: 14px;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box
}

.maga-side-navigator .menu-item:hover {
    background: #A9C734;
}

.maga-side-navigator .menu-line {
    line-height: 20px;
    padding-top: 10px;
}

.maga-side-navigator:hover {
    opacity: 1;
}

.maga-side-navigator:hover .maga-side-menu {
    -webkit-animation: jello 1s;
    -moz-animation: jello 1s;
    animation: jello 1s
}

.maga-side-navigator:hover .menu-first {
    -webkit-transform: translate3d(0, -135%, 0);
    -moz-transform: translate3d(0, -135%, 0);
    transform: translate3d(0, -135%, 0)
}

.maga-side-navigator:hover .menu-second {
    -webkit-transform: translate3d(120%, -70%, 0);
    -moz-transform: translate3d(120%, -70%, 0);
    transform: translate3d(120%, -70%, 0)
}

.maga-side-navigator:hover .menu-third {
    -webkit-transform: translate3d(120%, 70%, 0);
    -moz-transform: translate3d(120%, 70%, 0);
    transform: translate3d(120%, 70%, 0)
}

.maga-side-navigator:hover .menu-fourth {
    -webkit-transform: translate3d(0, 135%, 0);
    -moz-transform: translate3d(0, 135%, 0);
    transform: translate3d(0, 135%, 0)
}

@-webkit-keyframes jello {
    from, 11.1%, to {
        -webkit-transform: none;
        transform: none
    }
    22.2% {
        -webkit-transform: skewX(-12.5deg) skewY(-12.5deg);
        transform: skewX(-12.5deg) skewY(-12.5deg)
    }
    33.3% {
        -webkit-transform: skewX(6.25deg) skewY(6.25deg);
        transform: skewX(6.25deg) skewY(6.25deg)
    }
    44.4% {
        -webkit-transform: skewX(-3.125deg) skewY(-3.125deg);
        transform: skewX(-3.125deg) skewY(-3.125deg)
    }
    55.5% {
        -webkit-transform: skewX(1.5625deg) skewY(1.5625deg);
        transform: skewX(1.5625deg) skewY(1.5625deg)
    }
    66.6% {
        -webkit-transform: skewX(-.78125deg) skewY(-.78125deg);
        transform: skewX(-.78125deg) skewY(-.78125deg)
    }
    77.7% {
        -webkit-transform: skewX(0.390625deg) skewY(0.390625deg);
        transform: skewX(0.390625deg) skewY(0.390625deg)
    }
    88.8% {
        -webkit-transform: skewX(-.1953125deg) skewY(-.1953125deg);
        transform: skewX(-.1953125deg) skewY(-.1953125deg)
    }
}

@-moz-keyframes jello {
    from, 11.1%, to {
        -moz-transform: none;
        transform: none
    }
    22.2% {
        -moz-transform: skewX(-12.5deg) skewY(-12.5deg);
        transform: skewX(-12.5deg) skewY(-12.5deg)
    }
    33.3% {
        -moz-transform: skewX(6.25deg) skewY(6.25deg);
        transform: skewX(6.25deg) skewY(6.25deg)
    }
    44.4% {
        -moz-transform: skewX(-3.125deg) skewY(-3.125deg);
        transform: skewX(-3.125deg) skewY(-3.125deg)
    }
    55.5% {
        -moz-transform: skewX(1.5625deg) skewY(1.5625deg);
        transform: skewX(1.5625deg) skewY(1.5625deg)
    }
    66.6% {
        -moz-transform: skewX(-.78125deg) skewY(-.78125deg);
        transform: skewX(-.78125deg) skewY(-.78125deg)
    }
    77.7% {
        -moz-transform: skewX(0.390625deg) skewY(0.390625deg);
        transform: skewX(0.390625deg) skewY(0.390625deg)
    }
    88.8% {
        -moz-transform: skewX(-.1953125deg) skewY(-.1953125deg);
        transform: skewX(-.1953125deg) skewY(-.1953125deg)
    }
}

@keyframes jello {
    from, 11.1%, to {
        -webkit-transform: none;
        -moz-transform: none;
        transform: none
    }
    22.2% {
        -webkit-transform: skewX(-12.5deg) skewY(-12.5deg);
        -moz-transform: skewX(-12.5deg) skewY(-12.5deg);
        transform: skewX(-12.5deg) skewY(-12.5deg)
    }
    33.3% {
        -webkit-transform: skewX(6.25deg) skewY(6.25deg);
        -moz-transform: skewX(6.25deg) skewY(6.25deg);
        transform: skewX(6.25deg) skewY(6.25deg)
    }
    44.4% {
        -webkit-transform: skewX(-3.125deg) skewY(-3.125deg);
        -moz-transform: skewX(-3.125deg) skewY(-3.125deg);
        transform: skewX(-3.125deg) skewY(-3.125deg)
    }
    55.5% {
        -webkit-transform: skewX(1.5625deg) skewY(1.5625deg);
        -moz-transform: skewX(1.5625deg) skewY(1.5625deg);
        transform: skewX(1.5625deg) skewY(1.5625deg)
    }
    66.6% {
        -webkit-transform: skewX(-.78125deg) skewY(-.78125deg);
        -moz-transform: skewX(-.78125deg) skewY(-.78125deg);
        transform: skewX(-.78125deg) skewY(-.78125deg)
    }
    77.7% {
        -webkit-transform: skewX(0.390625deg) skewY(0.390625deg);
        -moz-transform: skewX(0.390625deg) skewY(0.390625deg);
        transform: skewX(0.390625deg) skewY(0.390625deg)
    }
    88.8% {
        -webkit-transform: skewX(-.1953125deg) skewY(-.1953125deg);
        -moz-transform: skewX(-.1953125deg) skewY(-.1953125deg);
        transform: skewX(-.1953125deg) skewY(-.1953125deg)
    }
}

.animated {
    -webkit-animation-duration: 1s;
    -moz-animation-duration: 1s;
    animation-duration: 1s;
    -webkit-animation-fill-mode: both;
    -moz-animation-fill-mode: both;
    animation-fill-mode: both
}

@-webkit-keyframes bounceInUp {
    from, 60%, 75%, 90%, to {
        -webkit-animation-timing-function: cubic-bezier(0.215, .61, .355, 1);
        animation-timing-function: cubic-bezier(0.215, .61, .355, 1)
    }
    from {
        opacity: 0;
        -webkit-transform: translate3d(0, 800px, 0);
        transform: translate3d(0, 800px, 0)
    }
    60% {
        opacity: 1;
        -webkit-transform: translate3d(0, -20px, 0);
        transform: translate3d(0, -20px, 0)
    }
    75% {
        -webkit-transform: translate3d(0, 10px, 0);
        transform: translate3d(0, 10px, 0)
    }
    90% {
        -webkit-transform: translate3d(0, -5px, 0);
        transform: translate3d(0, -5px, 0)
    }
    to {
        -webkit-transform: translate3d(0, 0, 0);
        transform: translate3d(0, 0, 0)
    }
}

@-moz-keyframes bounceInUp {
    from, 60%, 75%, 90%, to {
        -moz-animation-timing-function: cubic-bezier(0.215, .61, .355, 1);
        animation-timing-function: cubic-bezier(0.215, .61, .355, 1)
    }
    from {
        opacity: 0;
        -moz-transform: translate3d(0, 800px, 0);
        transform: translate3d(0, 800px, 0)
    }
    60% {
        opacity: 1;
        -moz-transform: translate3d(0, -20px, 0);
        transform: translate3d(0, -20px, 0)
    }
    75% {
        -moz-transform: translate3d(0, 10px, 0);
        transform: translate3d(0, 10px, 0)
    }
    90% {
        -moz-transform: translate3d(0, -5px, 0);
        transform: translate3d(0, -5px, 0)
    }
    to {
        -moz-transform: translate3d(0, 0, 0);
        transform: translate3d(0, 0, 0)
    }
}

@keyframes bounceInUp {
    from, 60%, 75%, 90%, to {
        -webkit-animation-timing-function: cubic-bezier(0.215, .61, .355, 1);
        -moz-animation-timing-function: cubic-bezier(0.215, .61, .355, 1);
        animation-timing-function: cubic-bezier(0.215, .61, .355, 1)
    }
    from {
        opacity: 0;
        -webkit-transform: translate3d(0, 800px, 0);
        -moz-transform: translate3d(0, 800px, 0);
        transform: translate3d(0, 800px, 0)
    }
    60% {
        opacity: 1;
        -webkit-transform: translate3d(0, -20px, 0);
        -moz-transform: translate3d(0, -20px, 0);
        transform: translate3d(0, -20px, 0)
    }
    75% {
        -webkit-transform: translate3d(0, 10px, 0);
        -moz-transform: translate3d(0, 10px, 0);
        transform: translate3d(0, 10px, 0)
    }
    90% {
        -webkit-transform: translate3d(0, -5px, 0);
        -moz-transform: translate3d(0, -5px, 0);
        transform: translate3d(0, -5px, 0)
    }
    to {
        -webkit-transform: translate3d(0, 0, 0);
        -moz-transform: translate3d(0, 0, 0);
        transform: translate3d(0, 0, 0)
    }
}

.bounceInUp {
    -webkit-animation-name: bounceInUp;
    -moz-animation-name: bounceInUp;
    animation-name: bounceInUp;
    -webkit-animation-delay: 1s;
    -moz-animation-delay: 1s;
    animation-delay: 1s
}

@media screen and (max-width: 640px) {
    .maga-side-navigator { /* display: none!important */
    }
}

@media screen and (min-width: 641px) and (max-width: 1367px) {
    .maga-side-navigator {
        top: 50px
    }
}
`;

    var Constant = {
        getLinkStr: function () {
            return linkStr;
        },


        getSelectMode: function () {
            return keySelectMode;//记录上次点击的是书签还是搜索模块
        },
        StrSearch: function () {
            return modeSearch;//常量
        },
        StrBookMark: function () {
            return modeBookMark;//常量
        },

        getBookMarkIds: function () {
            return bookMarkIds;//书签类型ID缓存
        },
        getListBookMark: function () {
            return bookMarkList;//书签缓存
        },

        getKeyButtonTop: function () {
            return keyButtonTop;//工具按钮的y坐标的记录点常量
        },
        getKeyButtonLeft: function () {
            return keyButtonLeft;//工具按钮的x坐标的记录点常量
        },
        getKeyQrcodeSwitch: function () {
            return keyQrcodeSwitch;//二维码的开关记录常量
        },

        getKeySwitch: function () {
            return keySwitch;//总开关：处于关闭状态则其他的按钮全部是收起状态
        },
        getKeySearch: function () {
            return keySearch;//搜索功能上次是否开启
        },
        getKeyBookMark: function () {
            return keyBookMark;//搜索功能上次是否开启
        },
    };


    let keyButtonTop = 'maga-tag-navigator-button-top';
    let keyButtonLeft = 'maga-tag-navigator-button-left';
    let keyQrcodeSwitch = 'maga-qrcode-url-key-switch';


    let keySelectMode = 'maga-key-optimize-select-mode';
    let modeSearch = 'maga-optimize-select-mode-search';
    let modeBookMark = 'maga-optimize-select-mode-book-mark';

    let keySwitch = 'maga-key-optimize-search-switch';
    let keySearch = 'maga-key-optimize-search-search';
    let keyBookMark = 'maga-key-optimize-search-book-mark';

    let bookMarkIds = 'maga-optimize-select-book-mark-id-1001';
    let bookMarkList = 'maga-optimize-select-book-mark-list';

    let linkStr = `
[百度搜索] [https://www.baidu.com/s?wd=#keyword#]
[360搜索] [https://www.so.com/s?q=#keyword#]
[搜狗搜索] [https://www.sogou.com/web?query=#keyword#]
[谷歌搜索] [https://www.google.com/search?q=#keyword#]
[Bing搜索] [https://cn.bing.com/search?q=#keyword#]
[雅虎] [https://search.yahoo.com/search?p=#keyword#] (input[name=p])
[Yandex] [https://yandex.com/search/?text=#keyword#] (input[name=text])


[百度翻译] [https://fanyi.baidu.com/#en/zh/#keyword#] [新窗口]
[谷歌翻译] [https://translate.google.com/?hl=zh-CN&tab=wT0#view=home&op=translate&sl=auto&tl=zh-CN&text=#keyword#] [新窗口]
[搜狗翻译] [https://fanyi.sogou.com/?keyword=#keyword#] [新窗口]


[Quora] [https://www.quora.com/search?q=#keyword#] [新窗口]
[维基百科] [https://zh.wikipedia.org/wiki/#keyword#] [新窗口]
[知乎搜索] [https://www.zhihu.com/search?type=content&q=#keyword#]
[豆瓣搜索] [https://www.douban.com/search?source=suggest&q=#keyword#]
[简书] [https://www.jianshu.com/search?q=#keyword#] (#q)


[GitHub] [https://github.com/search?utf8=✓&q=#keyword#]
[Stackoverflow] [https://stackoverflow.com/search?q=#keyword#] [新窗口]
[Segmentfault] [https://segmentfault.com/search?q=#keyword#]
[博客园] [https://zzk.cnblogs.com/s?w=#keyword#] (input[name=Keywords]) [右侧]
[CSDN] [https://so.csdn.net/so/search/s.do?q=#keyword#] (#toolbar-search-input)
[掘金] [https://juejin.im/search?query=#keyword#] (.search-input)
[MSDN] [https://docs.microsoft.com/zh-cn/search/?terms=#keyword#] [新窗口]

[百度图片] [https://image.baidu.com/search/index?tn=baiduimage&word=#keyword#] [新窗口]
[Google图片] [https://www.google.com/search?q=#keyword#&tbm=isch] [新窗口]
[Bing图片] [https://cn.bing.com/images/search?q=#keyword#&scenario=ImageBasicHover] [新窗口]


[有道词典] [https://dict.youdao.com/w/#keyword#] [新窗口]
[必应词典] [https://cn.bing.com/dict/search?q=#keyword#] [新窗口]
[Vocabulary] [https://www.vocabulary.com/dictionary/#keyword#] [新窗口]
[格林斯高阶] [https://www.collinsdictionary.com/dictionary/english/#keyword#] [新窗口]
[剑桥词典] [https://dictionary.cambridge.org/zhs/%E8%AF%8D%E5%85%B8/%E8%8B%B1%E8%AF%AD-%E6%B1%89%E8%AF%AD-%E7%AE%80%E4%BD%93/#keyword#] [新窗口]
[韦氏词典] [https://www.learnersdictionary.com/definition/#keyword#] [新窗口]


[淘宝搜索] [https://s.taobao.com/search?q=#keyword#] [新窗口]
[天猫搜索] [https://list.tmall.com/search_product.htm?q=#keyword#] [新窗口]
[京东搜索] [http://search.jd.com/Search?keyword=#keyword#] [新窗口]


[亚马逊] [https://www.amazon.cn/s?k=#keyword#] [新窗口]
[当当网] [http://search.dangdang.com/?key=#keyword#] [新窗口]
[孔夫子] [http://search.kongfz.com/product_result/?key=#keyword#] [新窗口]


[YouTube] [https://www.youtube.com/results?search_query=#keyword#] [新窗口]
[Bilibili] [http://search.bilibili.com/all?keyword=#keyword#] [新窗口]
[优酷搜索] [https://so.youku.com/search_video/q_#keyword#] [新窗口]
[爱奇艺搜索] [https://so.iqiyi.com/so/q_#keyword#] [新窗口]
[腾讯视频] [https://v.qq.com/x/search/?q=#keyword#] [新窗口]


[云盘精灵搜] [https://www.yunpanjingling.com/search/#keyword#]
[大圣盘搜索] [https://www.dashengpan.com/search?keyword=#keyword#]
[大力盘搜索] [https://www.dalipan.com/search?keyword=#keyword#]
[小昭来啦] [https://www.xiaozhaolaila.com/s/search?q=#keyword#]
[小可搜搜] [https://www.xiaokesoso.com/s/search?q=#keyword#]
`;

    let linkList = '';
    let currQueryPramVal = '';
    let currSelector = '';

    var Utils = {
        get: function () {
            if (linkList == '' || linkList.length === 0) {
                linkList = this.trim(this.getDefault());
            }
            return linkList
        },
        getDefault: function () {
            //默认的搜索引擎格式：[名称][搜索网址][是否新窗口打开，可省略] 搜索关键词用 #keyword# 表示，每行一个网站
            return this.trim(Constant.getLinkStr())
        },
        trim: function (str) {
            if (typeof str === 'string') {
                //去除字符串两端空白符
                return str
                    .replace(/^\s\s*/, '')
                    .replace(/\s\s*$/, '')
                    .trim()
            } else {
                return str
            }
        },

        //提取链接中对应参数的值
        getQueryVariable: function (variable) {
            let query = window.location.search.substring(1);
            let vars = query.split('&');
            for (let i = 0; i < vars.length; i++) {
                let pair = vars[i].split('=');
                if (pair[0] == variable) {
                    return pair[1]
                }
            }
            return ''
        },

        //获取搜索关键词
        getQueryPramValue: function () {
            {
                return currQueryPramVal
            }
        },
        getUserSelector: function ($j) {
            {
                return currSelector
            }
        },
        //尝试用户自定义关键词
        getKeywordConfig: function ($j) {
            //尝试用户自定义选择符
            let val = '';
            let selector = this.getUserSelector($j);
            if (selector) {
                if (selector.indexOf('#') !== -1 ||
                    selector.indexOf('.') !== -1 ||
                    selector.indexOf('=') !== -1 ||
                    selector.indexOf('input') !== -1 ||
                    selector.indexOf(':') !== -1) {
                    val = $j(selector).val() || $j(selector).text();
                }
                if (val && val.length > 0) {
                    return val
                } else {
                    return $j('#' + selector).val() ||
                        $j('.' + selector).val() ||
                        $j('input[name=\'' + selector + '\']').val() ||
                        $j('#' + selector).text() ||
                        $j('.' + selector).text() ||
                        $j('input[name=\'' + selector + '\']').text()
                }
            } else {
                return ''
            }
        },

        //尝试获取常见选择符
        getKeywordCommon: function ($j) {
            //尝试常用标记
            let val = $j('input[name=q]').val() || $j('input[name=query]').val()
                || $j('input[name=search]').val() || $j('input[name=keyword]').val()
                || $j('input[name=Keywords]').val() || $j('input[name=\'w\']').val()
                || $j('input[name=searchInput]').val() || $j('input[name=word]').val()
                || $j('input[name=\'search-input\']').val() || $j('input[name=\'text\']').val()
                || $j('input[name=\'s\']').val() || $j('input[name=key]').val()
                || $j('input#q').val() || $j('input#query').val()
                || $j('input#search').val() || $j('input#keyword').val()
                || $j('input#Keywords').val() || $j('input#w').val()
                || $j('input#input').val() || $j('#input[name=searchWord]').val()
                || $j('input#searchInput').val() || $j('input#word').val()
                || $j('input#search-input').val() || $j('input#text').val()
                || $j('input#s').val() || $j('input#search_input').val()
                || $j('input#key').val() || $j('input.q').val()
                || $j('input.query').val() || $j('input.search').val()
                || $j('input.keyword').val() || $j('input.Keywords').val()
                || $j('input.w').val() || $j('input.input').val()
                || $j('input.key').val() || $j('input.searchInput').val()
                || $j('input.word').val() || $j('input.search-input').val()
                || $j('input.text').val() || $j('input.s').val()
                || $j('input.search_input').val()

                || $j('#kw').val() || $j('input[name=q]').val()
                || $j('#upquery').val() || $j('#baidu_translate_input').val()
                || $j('#sb_form_q').val() || $j('#query').val()
                || $j('#trans-input').val() || $j('#Popover2-toggle').val()
                || $j('input.word').val() || $j('input[name=q]').eq(1).val()
                || $j('#search').val() || $j('#searchword').val()
                || $j('input[name=keyword]').val() || $j('input[name=searchInput]').val()
                || $j('#mq').val() || $j('#keywords').val()
                || $j('input[name=p]').val() || $j('.right_contents input.selector_input').val()
                || $j('#searchIput').val() || $j('input[name=text]').val()
                || $j('input[name=Keywords]').val() || $j('#q').val()
                || $j('#toolbar-search-input').val() || $j('input.search-input').val()
                || $j('input[name=\'facet-search-input\']').val() || $j('.headword').text()
                || $j('input[name=ld_search_inp]').eq(1).val() || $j('#twotabsearchtextbox').val()
                || $j('#key_S').val() || $j('#stickSearchKey').val() || '';

            //获取地址栏参数
            if (val) {
                return val
            } else {
                return this.getQueryPramValue()
            }
        },
        //获取youtube选择符
        getKeywordYuToBe: function () {
            let ytbObj = document.getElementsByName('search_query');
            if (ytbObj && ytbObj[0] && ytbObj[0].value) {
                return ytbObj[0].value
            }
            return ''
        },
        //获取搜索关键词
        getKeyword: function ($j) {
            let keyword = this.getKeywordCommon($j) || this.getKeywordYuToBe() || this.getKeywordConfig($j);
            return encodeURIComponent(keyword.replace(/^\s+|\s+$/gm, ''))
        },
    };

    var Event = {

        initEvent: function ($j, runType) {

            //默认选中的模块
            setSelectMode($j);
            //插件功能是否开启
            setOnClickListenerSwitch($j);
            //搜索页面点击事件
            setOnClickListenerSearch($j);
            //书签页面点击事件
            setOnClickListenerBookMark($j);
            //更多页面点击事件
            setOnClickListenerMore($j);
            //设置页面点击事件
            setOnClickListenerSetting($j, runType);
            //设置控件的一些属性
            addattribute($j);

            //搜索引擎
            $j('#maga-better-list-search a').each(function () {
                $j(this).attr('data-href', $j(this).attr('href'));
            });

            //修改链接
            $j('#maga-better-list-search a').on('mouseover', function () {
                let href = $j(this).attr('data-href').replace(/#keyword#/i, Utils.getKeyword($j));
                $j(this).attr('href', href);
            });

            //链接跳转
            $j('#maga-better-list-search a').on('click', function () {
                if ($j(this).attr('href').indexOf('#keyword#') !== -1) {
                    let href = $j(this).attr('href').replace(/#keyword#/i, Utils.getKeyword($j));
                    $j(this).attr('href', href);
                }
                return true
            });
        },
    };

    function setOnClickListenerSwitch($j) {
        function fadeOutViews($j) {
            $j('#maga-better-icon-search').fadeOut();
            $j('#maga-better-icon-book-mark').fadeOut();
            $j('#maga-better-icon-more').fadeOut();
            $j('#maga-better-icon-setting').fadeOut();
        }

        function fadeInViews($j) {
            $j('#maga-better-icon-search').fadeIn();
            $j('#maga-better-icon-book-mark').fadeIn();
            $j('#maga-better-icon-more').fadeIn();
            $j('#maga-better-icon-setting').fadeIn();
        }

        $j(document).keyup(function (e) {
            // GM_log('e.key================' + e.key)
            if (e.key === 'Escape') {
                // ESC关闭页面
                $j('#maga-better-list-search').fadeOut();
                $j('#maga-better-list-book-mark').fadeOut();
                $j('#maga-better-list-more').fadeOut();
                $j('#maga-better-list-setting').fadeOut();
            } else if (e.altKey && e.key === 'z') {
                $j('#maga-better-icon-switch').click();
            } else if (e.altKey && e.key === 'x') {
                $j('#maga-better-icon-search').click();
            } else if (e.altKey && e.key === 'c') {
                $j('#maga-better-icon-book-mark').click();
            } else if (e.altKey && e.key === 'v') {
                $j('#maga-better-icon-more').click();
            } else if (e.altKey && e.key === 'b') {
                $j('#maga-better-icon-setting').click();
            }
        });

        $j('#maga-better-icon-switch').click(function () {
            GM_setValue(Constant.getKeySwitch(), !GM_getValue(Constant.getKeySwitch(), true));
            if (GM_getValue(Constant.getKeySwitch(), true)) {
                fadeInViews($j);
            } else {
                fadeOutViews($j);
                /*总开关关闭 ==> 关闭所有展示的模块*/
                GM_setValue(Constant.getKeySearch(), false);
                GM_setValue(Constant.getKeyBookMark(), false);
                $j('#maga-better-list-search').fadeOut();
                $j('#maga-better-list-book-mark').fadeOut();
                $j('#maga-better-list-more').fadeOut();
                $j('#maga-better-list-setting').fadeOut();
            }
        });
        if (GM_getValue(Constant.getKeySwitch(), true)) {
            $j('#maga-better-icon-search').show();
            $j('#maga-better-icon-book-mark').show();
            $j('#maga-better-icon-more').show();
            $j('#maga-better-icon-setting').show();
        } else {
            $j('#maga-better-icon-search').hide();
            $j('#maga-better-icon-book-mark').hide();
            $j('#maga-better-icon-more').hide();
            $j('#maga-better-icon-setting').hide();
        }
    }

    function setSelectMode($j) {
        let selectMode = GM_getValue(Constant.getSelectMode(), Constant.StrSearch());
        if (selectMode == Constant.StrSearch()) {
            if (GM_getValue(Constant.getKeySearch(), true)) {
                $j('#maga-better-list-search').show();
            } else {
                $j('#maga-better-list-search').hide();
            }
        } else if (selectMode == Constant.StrBookMark()) {
            if (GM_getValue(Constant.getKeyBookMark(), true)) {
                $j('#maga-better-list-book-mark').show();
            } else {
                $j('#maga-better-list-book-mark').hide();
            }
        }
    }

    function setOnClickListenerSearch($j) {
        $j('#maga-better-icon-search').click(function () {
            GM_setValue(Constant.getSelectMode(), Constant.StrSearch());
            if ($j('#maga-better-list-search').css('display') === 'none') {
                GM_setValue(Constant.getKeySearch(), true);
            } else {
                GM_setValue(Constant.getKeySearch(), false);
            }

            $j('#maga-better-list-book-mark').fadeOut();
            $j('#maga-better-list-setting').fadeOut();
            $j('#maga-better-list-more').fadeOut();

            setTimeout(function () {
                if (GM_getValue(Constant.getKeySearch(), true)) {
                    $j('#maga-better-list-search').fadeIn();
                } else {
                    $j('#maga-better-list-search').fadeOut();
                }
            }, 300);
        });
    }

    function setOnClickListenerBookMark($j) {
        $j('#maga-better-icon-book-mark').click(function () {
            GM_setValue(Constant.getSelectMode(), Constant.StrBookMark());
            if ($j('#maga-better-list-book-mark').css('display') === 'none') {
                GM_setValue(Constant.getKeyBookMark(), true);
            } else {
                GM_setValue(Constant.getKeyBookMark(), false);
            }

            $j('#maga-better-list-search').fadeOut();
            $j('#maga-better-list-setting').fadeOut();
            $j('#maga-better-list-more').fadeOut();

            setTimeout(function () {
                if (GM_getValue(Constant.getKeyBookMark(), true)) {
                    $j('#maga-better-list-book-mark').fadeIn();
                } else {
                    $j('#maga-better-list-book-mark').fadeOut();
                }
            }, 300);
        });
    }

    function setOnClickListenerMore($j) {
        $j('#maga-better-icon-more').click(function () {
            $j('#maga-better-list-search').hide();
            $j('#maga-better-list-setting').hide();
            $j('#maga-better-list-book-mark').hide();

            setTimeout(function () {
                if ($j('#maga-better-list-more').css('display') === 'none') {
                    $j('#maga-better-list-more').fadeIn();
                } else {
                    $j('#maga-better-list-more').fadeOut();
                }
            }, 300);
        });
    }

    function setOnClickListenerSetting($j, runType) {
        // 设置页面点击事件
        $j('#maga-better-icon-setting').click(function () {
            $j('#maga-better-list-search').hide();
            $j('#maga-better-list-more').hide();
            $j('#maga-better-list-book-mark').hide();

            setTimeout(function () {
                if ($j('#maga-better-list-setting').css('display') === 'none') {
                    $j('#maga-better-list-setting').fadeIn();
                } else {
                    $j('#maga-better-list-setting').fadeOut();
                }
            }, 300);
        });
        if (runType == 'complex') {
            $j('#maga-better-setting-qrcode').click(function () {
                let key = Constant.getKeyQrcodeSwitch();
                GM_setValue(key, !GM_getValue(key, true));
                if (GM_getValue(key, true)) {
                    toastr.success('二维码工具已开启！');
                } else {
                    toastr.error('二维码工具已关闭！');
                }
                setTimeout(() => {
                    location.reload();
                }, 200);
            });
            $j('#maga-better-setting-reset-button-tool').click(function () {
                // 导航按钮复位
                GM_deleteValue(Constant.getKeyButtonTop());
                GM_deleteValue(Constant.getKeyButtonLeft());
                toastr.success('设置成功，网页刷新！');
                setTimeout(() => {
                    location.reload();
                }, 200);
            });
        }
        $j('#maga-better-setting-reset').click(function () {
            // 清理缓存
            GM_deleteValue(Constant.getSelectMode());
            GM_deleteValue(Constant.getBookMarkIds());
            GM_deleteValue(Constant.getListBookMark());
            GM_deleteValue(Constant.getKeyButtonTop());
            GM_deleteValue(Constant.getKeyButtonLeft());
            GM_deleteValue(Constant.getKeyQrcodeSwitch());
            GM_deleteValue(Constant.getKeySwitch());
            GM_deleteValue(Constant.getKeySearch());
            GM_deleteValue(Constant.getKeyBookMark());
            toastr.success('清理成功，网页刷新！');
            setTimeout(() => {
                location.reload();
            }, 200);
        });
        $j('#maga-better-setting-book-type').click(function () {
            if ($j('#maga-better-setting-book-type-list').css('display') === 'none') {
                $j('#maga-better-setting-book-type-list').fadeIn();
            } else {
                $j('#maga-better-setting-book-type-list').fadeOut();
            }
        });

        $j('#maga-better-setting-book-type-refresh').click(function () {
            toastr.success('网页刷新！');
            setTimeout(() => {
                location.reload();
            }, 200);
        });

        // 链接跳转
        $j('.book-type-item').click(function () {
            let ids = GM_getValue(Constant.getBookMarkIds(), []);
            let dataId = $j(this).attr('data-id');

            for (let i = 0; i < ids.length; i++) {
                let id = ids[i].id;
                ids[i].typeName;
                if (id == dataId) {
                    if ($j(this).hasClass('book-type-item-select')) {
                        $j(this).attr('class', 'book-type-item book-type-item-unselect');
                    } else {
                        $j(this).attr('class', 'book-type-item book-type-item-select');
                    }
                    ids[i].enable = !ids[i].enable;
                    break
                }
            }
            // GM_log(ids)
            GM_setValue(Constant.getBookMarkIds(), ids);
            return true
        });

        $j('#maga-better-setting-coupon').click(function () {
            // 全网优惠券
            GM_openInTab('http://payback.bwaq.cn?channel=tbk');
        });
        $j('#maga-better-setting-video').click(function () {
            // 全网VIP影视
            GM_openInTab('http://video.bwaq.cn');
        });
        $j('#maga-better-setting-weixin-group').click(function () {
            // 关注公众号
            GM_openInTab('http://payback.bwaq.cn/wechat/platform');
        });
        $j('#maga-better-setting-qq-group').click(function () {
            // 加入捡漏群
            let requestField = 'couponUrl';
            let requestUrl = 'https://server.bwaq.cn/tbk/api/config/systemConfig/item?requestField=' + requestField;
            GM.xmlHttpRequest({
                method: 'GET',
                url: requestUrl,
                onload: function onload(response) {
                    let data = response.response;
                    if (typeof data === 'string') {
                        data = JSON.parse(data);
                    }
                    // GM_log('==============>' + JSON.stringify(data))

                    if (data.code == 10) {
                        // GM_log('================获取成功================')
                        let couponUrl = data[requestField];
                        if (couponUrl) {
                            GM_openInTab(couponUrl);
                        } else {
                            GM_openInTab('http://payback.bwaq.cn?channel=tbk');
                        }
                    } else {
                        GM_openInTab('http://payback.bwaq.cn?channel=tbk');
                    }
                },
            });
        });
    }

    function addattribute($j) {
        $j('#maga-better-icon-switch').attr('class', 'maga-better-icon');
        $j('#maga-better-icon-search').attr('class', 'maga-better-icon');
        $j('#maga-better-icon-book-mark').attr('class', 'maga-better-icon');
        $j('#maga-better-icon-setting').attr('class', 'maga-better-icon');
        $j('#maga-better-icon-more').attr('class', 'maga-better-icon');

        $j('#maga-better-list-setting').css('min-height', '176px');
        $j('#maga-better-list-more').css('min-height', '176px');

    }

    let runType$1 = 'alone';

    let regexStr$6 = [];

    const website$7 = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$6)
        },

        setRunType: function (val) {
            runType$1 = val || 'alone';
        },
        init: function ($j) {
            GM_addStyle(GM_getResourceText('toastr_css'));
            let html = `
                <div id="maga-better-wrapper">
                    <div id="maga-better-icon-wrapper">
                        <!--关闭插件-->
                        <img id="maga-better-icon-switch"/>
                        <!--搜索优化-->
                        <img id="maga-better-icon-search"/>
                        <!--书签模块-->
                        <img id="maga-better-icon-book-mark"/>
                        <!--更多功能-->
                        <img id="maga-better-icon-more"/>
                        <!--设置功能-->
                        <img id="maga-better-icon-setting"/>
                    </div>
                    <div id="maga-better-content-wrapper">
                        <!--搜索优化列表-->
                        <div id="maga-better-list-search"></div>
                        <!--书签模块列表-->
                        <div id="maga-better-list-book-mark"></div>
                        <!--更多模块列表-->
                        <div id="maga-better-list-more"></div>
                        <!--设置模块列表-->
                        <div id="maga-better-list-setting"></div>
                    </div>
             </div>
            `;

            setTimeout(function () {
                if ($j('#maga-better-wrapper').length !== 0) return

                $j('body').append(html);

                parseConfigSearch($j);
                parseConfigBookMark($j);
                parseConfigMore($j);
                parseConfigSetting($j, runType$1);

                Event.initEvent($j, runType$1);
            }, 200);

            function parseConfigSearch($j) {
                let template = `
                    <a class="search-item" href="{{siteurl}}" {{sitetarget}} data-selector="{{inputselector}}">
                        {{sitename}}
                    </a>
                    `;
                let linkArr = Utils.get().split(/\r*?\n|\r/);
                let linkHtmlStr = '';
                for (let i in linkArr) {
                    let link = Utils.trim(linkArr[i]);
                    if (typeof link !== 'string' || link === '') {
                        continue
                    }
                    link = link.replace(/【/g, '[').replace(/】/g, ']');
                    let matches = link.match(/\[(.*?)\][^\[]*?\[(.*?)\]/);
                    if (matches == null) {
                        continue
                    }
                    let title = Utils.trim(matches[1]);
                    let url = matches[2].indexOf('#keyword#') !== -1 ? Utils.trim(matches[2]) : Utils.trim(matches[2]) + '#keyword#';
                    let target = /\[\s*?新窗口(打开)?\s*?]/.test(link) ? 'target="_blank"' : '';
                    let inputSelector = link.match(/\(\s*?(.*?)\s*?\)/);
                    inputSelector = inputSelector && inputSelector[1] ? inputSelector[1] : '';

                    let linkHtmlItem = template
                        .replace(/{{sitename}}/g, title)
                        .replace('{{siteurl}}', url)
                        .replace('{{sitetarget}}', target)
                        .replace('{{inputselector}}', inputSelector);
                    linkHtmlStr += linkHtmlItem;
                }
                $j('#maga-better-list-search').append(linkHtmlStr);
            }

            function parseConfigBookMark($j) {

                function renderHtml(bookmark, $j) {
                    let templateTitle = `
                    <a class="book-mark-title">
                        {{sitename}}
                    </a>
                    `;
                    let templateItem = `
                    <a class="book-mark-item" href="{{siteurl}}" target="_blank">
                        {{sitename}}
                    </a>
                    `;
                    let linkHtmlStr = '';
                    if (bookmark.data && bookmark.data.length > 0) {
                        bookmark.data.forEach((item, index) => {
                            if (item.data.length === 0) { return }
                            let linkHtmlItem = templateTitle
                                .replace(/{{sitename}}/g, item.typeName);
                            linkHtmlStr += linkHtmlItem;
                            item.data.forEach((row) => {
                                let linkHtmlItem = templateItem
                                    .replace(/{{sitename}}/g, row.remarks)
                                    .replace('{{siteurl}}', row.clickUrl);
                                linkHtmlStr += linkHtmlItem;
                            });
                        });
                    }
                    $j('#maga-better-list-book-mark').empty();
                    $j('#maga-better-list-book-mark').append(linkHtmlStr);
                }

                return new Promise((resolve, reject) => {
                    function getBookmark(resolve, reject) {
                        let ids = GM_getValue(Constant.getBookMarkIds(), []);
                        if (ids.length === 0) {
                            reject('get book mark error!');
                        } else {
                            let idListStr = [];
                            for (let i = 0; i < ids.length; i++) {
                                if (ids[i].enable) {
                                    idListStr.unshift(ids[i].id);
                                }
                            }
                            let bookMarkUrl = 'https://server.bwaq.cn/tbk/api/bookMark/getListBySort?typeIds=' + idListStr.join(',');
                            // GM_log('idListStr===' + idListStr)
                            // GM_log('bookMarkUrl===' + bookMarkUrl)
                            GM.xmlHttpRequest({
                                method: 'GET',
                                url: bookMarkUrl,
                                onload: function onload(response) {
                                    let bookMark = response.response;
                                    if (typeof bookMark === 'string') {
                                        bookMark = JSON.parse(bookMark);
                                    }
                                    //GM_log('==============>' + JSON.stringify(bookMark))
                                    GM_setValue(Constant.getListBookMark(), bookMark);

                                    if (bookMark.code == 10) {
                                        //GM_log('================获取成功================')
                                        resolve(bookMark);
                                    } else {
                                        reject('get book mark error!');
                                    }
                                },
                            });
                        }
                    }

                    // 书签
                    function getBookType(resolve, reject) {
                        let bookTypeUrl = 'https://server.bwaq.cn/tbk/api/bookType/getListBySort?category=1';
                        GM.xmlHttpRequest({
                            method: 'GET',
                            url: bookTypeUrl,
                            onload: function onload(response) {
                                let data = response.response;
                                if (typeof data === 'string') {
                                    data = JSON.parse(data);
                                }
                                //GM_log('==============>' + JSON.stringify(data))

                                if (data.code == 10) {
                                    //GM_log('================获取成功================')
                                    let ids = GM_getValue(Constant.getBookMarkIds(), []);
                                    for (let i = 0; i < data.data.length; i++) {
                                        let id = data.data[i].id;
                                        let newElement = true;
                                        for (let j = 0; j < ids.length; j++) {
                                            if (ids[j].id == id) {
                                                newElement = false;
                                                break
                                            }
                                        }
                                        if (newElement) {
                                            let typeName = data.data[i].typeName;
                                            ids.unshift({ id: id, enable: true, typeName: typeName });
                                        }
                                    }
                                    GM_setValue(Constant.getBookMarkIds(), ids);
                                    getBookmark(resolve, reject);
                                } else {
                                    reject('get book type id error!');
                                }
                            },
                        });
                    }

                    let bookMark = GM_getValue(Constant.getListBookMark(), null);

                    if (bookMark) {
                        renderHtml(bookMark, $j);
                    }
                    if (GM_getValue(Constant.getBookMarkIds(), []).length == 0) {
                        getBookType(resolve, reject);
                    } else {
                        getBookmark(resolve, reject);
                    }

                }).then((bookMark) => {
                    renderHtml(bookMark, $j);
                })
            }

            function parseConfigMore($j) {
                let linkHtmlStr = `<a id="maga-better-setting-coupon">电商优惠券</a>`;
                linkHtmlStr += `<a id="maga-better-setting-video">VIP影视</a>`;
                linkHtmlStr += `<a id="maga-better-setting-weixin-group">关注公众号</a>`;
                linkHtmlStr += `<a id="maga-better-setting-qq-group">加入捡漏群</a>`;
                $j('#maga-better-list-more').append(linkHtmlStr);
            }

            function parseConfigSetting($j, runType) {

                let linkHtmlStr = '';
                if (runType == 'complex') {
                    linkHtmlStr = `<a id="maga-better-setting-qrcode">二维码开关</a>`;
                    linkHtmlStr += `<a id="maga-better-setting-reset-button-tool">复位工具按钮</a>`;
                }
                linkHtmlStr += `<a id="maga-better-setting-reset">清理缓存</a>`;
                linkHtmlStr += `<div>
                                <div style="display: flex;align-items: center;flex-direction: row">
                                    <a id="maga-better-setting-book-type">书签分类设置</a>
                                    <span id="maga-better-setting-book-type-refresh">刷新书签</span>
                                </div>
                                <div id="maga-better-setting-book-type-list"></div>
                            </div>`;
                $j('#maga-better-list-setting').append(linkHtmlStr);
                let ids = GM_getValue(Constant.getBookMarkIds(), []);
                if (ids.length == 0) {
                    return new Promise((resolve, reject) => {
                        let bookTypeUrl = 'https://server.bwaq.cn/tbk/api/bookType/getListBySort?category=1';
                        GM.xmlHttpRequest({
                            method: 'GET',
                            url: bookTypeUrl,
                            onload: function onload(response) {
                                let data = response.response;
                                if (typeof data === 'string') {
                                    data = JSON.parse(data);
                                }
                                //GM_log('==============>' + JSON.stringify(data))

                                if (data.code == 10) {
                                    //GM_log('================获取成功================')
                                    let ids = GM_getValue(Constant.getBookMarkIds(), []);
                                    for (let i = 0; i < data.data.length; i++) {
                                        let id = data.data[i].id;
                                        let newElement = true;
                                        for (let j = 0; j < ids.length; j++) {
                                            if (ids[j].id == id) {
                                                newElement = false;
                                                break
                                            }
                                        }
                                        if (newElement) {
                                            let typeName = data.data[i].typeName;
                                            ids.unshift({ id: id, enable: true, typeName: typeName });
                                        }
                                    }

                                    GM_setValue(Constant.getBookMarkIds(), ids);
                                    resolve(ids);
                                } else {
                                    reject('get book type id error!');
                                }
                            },
                        });
                    }).then((ids) => {
                        renderHtml($j, ids);
                    })
                } else {
                    renderHtml($j, ids);
                }

                function renderHtml($j, ids) {
                    let templateIdOpen = `
                    <span class="book-type-item book-type-item-select" data-id="{{data-id}}">
                        {{typeName}}
                    </span>
                    `;
                    let templateIdClose = `
                    <span class="book-type-item book-type-item-unselect" data-id="{{data-id}}">
                        {{typeName}}
                    </span>
                    `;
                    let bookMarkHtmlStr = '';
                    for (let index = 0; index < ids.length; index++) {
                        let item = ids[index];
                        let linkHtmlItem;
                        if (item.enable) {
                            linkHtmlItem = templateIdOpen
                                .replace('{{data-id}}', item.id)
                                .replace(/{{typeName}}/g, item.typeName);
                        } else {
                            linkHtmlItem = templateIdClose
                                .replace('{{data-id}}', item.id)
                                .replace(/{{typeName}}/g, item.typeName);
                        }
                        bookMarkHtmlStr += linkHtmlItem;
                    }
                    $j('#maga-better-setting-book-type-list').append(bookMarkHtmlStr);
                }
            }

        },
    };

    const modules$2 = [website$7];

    const prepare$2 = {
        init: function ($j, runType) {
            if (GUtils.inIframe()) {
                return
            }
            GM_addStyle(CSS_STR$1);
            for (let i = 0; i < modules$2.length; i++) {
                let module = modules$2[i];
                if (module.intercepter()) {
                    continue;
                }
                module.setRunType((typeof runType === 'undefined') ? 'alone' : runType);
                module.init($j);
            }
        }
    };

    let CSS_STR$1 = `
#maga-better-wrapper {
    background: transparent;
    position: fixed;
    top: 140px;
    /*右侧*/
    right: 0;
    flex-direction: row-reverse;
    max-width: 320px;
    padding: 10px;
    font-size: 14px;

    /*左侧*/
    /*left: 0;*/
    /*flex-direction: row;*/
    /*max-width: 160px;*/
    /*padding: 6px;*/
    /*font-size: 14px;*/

    z-index: 99999999;
    font-weight: 400;
    box-sizing: border-box;
    display: flex;
    align-items: flex-start;
}

#maga-better-icon-wrapper {
    width: 36px;
}

#maga-better-content-wrapper {
    margin: 0 2px;
    text-align: left;
    flex: 1;
}

#maga-better-list-book-mark {
    padding: 8px 4px;
    border-radius: 6px;
    background: rgba(28, 35, 35, 0.9);
    display: none;
    max-height: 500px;
    min-height: 176px;
    overflow-y: scroll;
}

/*定义滚动条高宽及背景 高宽分别对应横竖滚动条的尺寸*/
#maga-better-list-book-mark::-webkit-scrollbar {
    width: 0;
    height: 0;
}

#maga-better-list-search {
    padding: 8px 4px;
    border-radius: 6px;
    background: rgba(28, 35, 35, 0.9);
    display: none;
    max-height: 500px;
    min-height: 176px;
    overflow-y: scroll;
}

/*定义滚动条高宽及背景 高宽分别对应横竖滚动条的尺寸*/
#maga-better-list-search::-webkit-scrollbar {
    width: 0;
    height: 0;
}

#maga-better-list-setting {
    padding: 8px 4px;
    border-radius: 6px;
    background: rgba(28, 35, 35, 0.9);
    display: none;
}

/*搜索模块-列表的条目：搜索网址*/
.search-item {
    border-radius: 2px;
    border: 1px solid #EFEFEF;
}

/*书签模块-列表的标题：书签分类名称*/
.book-mark-title {
    font-weight: 600;
    color: #EFEFEF;
    border-radius: 2px;
    border: 1px solid #EFEFEF;
    display: block !important;
}

/*书签模块-列表的条目：书签*/
.book-mark-item {
    font-weight: 400;
    display: inline-block;
}

/*设置模块-书签分类*/
.book-type-item {
    font-weight: 400;
    cursor: pointer;
    padding: 4px 6px;
    display: inline-block;
    border-radius: 2px;
    border: 1px solid #EFEFEF;
}

/*设置模块-书签分类-选中状态*/
.book-type-item-select {
    color: #FFFFFF;
}

/*设置模块-书签分类-非选中状态*/
.book-type-item-unselect {
    color: #999999;
}

#maga-better-list-more {
    padding: 8px 4px;
    border-radius: 6px;
    background: rgba(28, 35, 35, 0.9);
    display: none;
}

#maga-better-setting-book-type {
    flex: 1;
    display: inline-block;
    font-weight: 600;
}

#maga-better-setting-book-type-refresh {
    cursor: pointer;
    display: inline-block;
    font-weight: 400;
    color: #3186fd;
}

#maga-better-content-wrapper a {
    cursor: pointer;
    color: #FFFFFF;
    margin: 2px 2px;
    padding: 3px 3px;
    list-style: none;
    text-decoration: none;
    display: inline-block;
}

#maga-better-content-wrapper a:hover {
    color: #EEEEEE !important;
}

.maga-better-icon {
    width: 36px;
    height: 36px;
    cursor: pointer;
    border-radius: 6px;
    background: rgba(28, 35, 35, 0.9);
}

#maga-better-icon-setting {
    background-repeat: no-repeat;
    background-position: center;
    background-image: url("data:image/svg+xml;charset=utf8,<svg width=%2230%22 height=%2230%22 class=%22icon%22 viewBox=%220 0 1024 1024%22 version=%221.1%22 xmlns=%22http://www.w3.org/2000/svg%22> <path d=%22M547.6 960h-71.3c-31.9 0-57.9-26-57.9-57.9v-37.2c-31.5-8.3-61.6-20.8-89.9-37.3L302.2 854c-22.5 22.6-59.3 22.6-81.8 0L170 803.6c-22.6-22.5-22.6-59.3 0-81.8l26.4-26.4c-0.9-1.5-1.7-2.9-2.5-4.4-15.3-27-26.9-55.7-34.8-85.5h-37.2c-31.9 0-57.8-26-57.8-57.9v-71.3c0-31.9 25.9-57.9 57.8-57.9h37.2c8.3-31.5 20.8-61.6 37.3-89.9L170 302.2c-22.6-22.5-22.6-59.3 0-81.8l50.4-50.4c22.5-22.5 59.3-22.6 81.8 0l26.4 26.4c13.9-8.1 28.4-15.3 43.2-21.5 15.2-6.3 30.8-11.6 46.7-15.8v-37.2c0-31.9 26-57.9 57.9-57.9h71.3c31.9 0 57.9 26 57.9 57.9v37.2c31.5 8.3 61.6 20.8 89.9 37.3l26.4-26.4c22.5-22.5 59.3-22.6 81.8 0l50.4 50.4c22.6 22.5 22.6 59.3 0 81.8l-26.4 26.4c16.5 28.3 29 58.4 37.3 89.9h37.2c31.9 0 57.9 26 57.9 57.9v71.3c0 31.9-26 57.9-57.9 57.9H865c-8.3 31.5-20.8 61.6-37.3 89.9l26.4 26.4c22.6 22.5 22.6 59.3 0 81.8L803.6 854c-22.5 22.6-59.3 22.6-81.8 0l-26.4-26.4c-28.3 16.5-58.4 29-89.9 37.3v37.2c0 31.9-26 57.9-57.9 57.9zM324.8 767.8c5.1 0 10.1 1.4 14.6 4.4 33.9 22.5 71.1 38 110.7 45.9 12.3 2.5 21.2 13.3 21.2 25.8V902c0 2.8 2.3 5.1 5.1 5.1h71.3c2.8 0 5.1-2.3 5.1-5.1v-58c0-12.6 8.9-23.4 21.2-25.8 39.6-8 76.8-23.4 110.7-45.9 10.4-7 24.3-5.6 33.2 3.3l41.2 41.2c2 2 5.3 2 7.3 0l50.4-50.4c2-2 2-5.3 0-7.3l-41.2-41.2c-8.9-8.9-10.3-22.8-3.3-33.2 22.5-33.9 38-71.1 45.9-110.7 2.5-12.3 13.3-21.2 25.8-21.2h58.1c2.8 0 5.1-2.3 5.1-5.1v-71.3c0-2.8-2.3-5.1-5.1-5.1H844c-12.6 0-23.4-8.9-25.8-21.2-8-39.6-23.4-76.8-45.9-110.7-6.9-10.4-5.6-24.3 3.3-33.2l41.2-41.2c2-2 2-5.3 0-7.3l-50.4-50.4c-2-2-5.3-2-7.3 0l-41.2 41.2c-8.9 8.9-22.8 10.2-33.2 3.3-33.9-22.5-71.1-38-110.7-45.9-12.3-2.5-21.2-13.3-21.2-25.8V122c0-2.8-2.3-5.1-5.1-5.1h-71.3c-2.8 0-5.1 2.3-5.1 5.1v58c0 12.6-8.9 23.4-21.2 25.8-19.7 4-39.2 9.9-57.9 17.7-18.4 7.7-36.1 17.2-52.8 28.2-10.5 7-24.4 5.6-33.2-3.3L265 207.3c-2-2-5.3-2-7.3 0l-50.4 50.4c-2 2-2 5.3 0 7.3l41.2 41.2c8.9 8.9 10.3 22.8 3.3 33.2-22.5 33.9-38 71.1-45.9 110.7-2.5 12.3-13.3 21.2-25.8 21.2H122c-2.8 0-5.1 2.3-5.1 5.1v71.3c0 2.8 2.3 5.1 5.1 5.1h58c12.6 0 23.4 8.9 25.8 21.2 6.4 32 17.8 62.6 33.9 91.1 3.8 6.7 7.8 13.2 12 19.6 6.9 10.4 5.6 24.3-3.3 33.2L207.3 759c-2 2-2 5.3 0 7.3l50.4 50.4c2 2 5.3 2 7.3 0l41.2-41.2c5-5 11.8-7.7 18.6-7.7z%22 fill=%22%23FAFAFA%22></path> <path d=%22M512 716.4c-112.7 0-204.4-91.7-204.4-204.4S399.3 307.6 512 307.6c71.5 0 136.6 36.4 174.1 97.3 7.6 12.4 3.8 28.6-8.6 36.3-12.4 7.6-28.6 3.8-36.3-8.6-27.8-45.2-76.1-72.2-129.2-72.2-83.6 0-151.7 68-151.7 151.6s68 151.6 151.7 151.6 151.6-68 151.6-151.6c0-14.5 11.8-26.4 26.4-26.4s26.4 11.8 26.4 26.4c0 112.7-91.7 204.4-204.4 204.4z%22 fill=%22%23FAFAFA%22></path> </svg>");
}

#maga-better-icon-search {
    background-repeat: no-repeat;
    background-position: center;
    background-image: url("data:image/svg+xml;charset=utf8,<svg width=%2230%22 height=%2230%22 viewBox=%220 0 1024 1024%22 version=%221.1%22 xmlns=%22http://www.w3.org/2000/svg%22> <path fill=%22%23FAFAFA%22 d=%22M512 64.7C265.3 64.7 64.7 265.3 64.7 512S265.3 959.3 512 959.3 959.3 758.7 959.3 512 758.7 64.7 512 64.7z m0 845.8c-219.8 0-398.5-178.8-398.5-398.5 0-91.3 31.2-175.2 83-242.5-2.2 8.1-6.6 22.9-5.4 27.4 1.6 5.5 0.7 8.4 2.6 13.2-1.2 0.9-3.7 2.6-2.7 4.6 3.3 6.5 7.2 15.9 12.2 16.4-2 9.8 3.2 6 6.3 14.2 0.3 1.6-0.4 4.3 1.5 5.1 8.4 2.6 20.2 6.9 24 14.1-0.1-0.1-0.4 0-0.5 0 0 0.4-0.1 1.3-0.1 1.7 1.6 5.8 3.6 7 5.7 11.2 1.3 3 1.1 9.7 3.9 11.6 4.2 2.7 8.3 7.7 12 13 2.1 3.1-4.1 2.4-5.2 2.4 2.6 3.7 8.3 2.9 11.7 6.2 2.7 2.5 4.6 5.1 7.4 7.9-0.1 1.7-0.1 4.4-0.2 6.6 0.5 1 0.9 1.3 2.6 2.2 3 1.9 5.1 7.6 10.1 7.7 0.1 0.8 3.9 5.4 4.3 5.4 0.6-0.1 1.8-2.9 1.9-3.9-0.1-1.6-3.1-6.4-5.3-4.3-4.9-3.1-6.3-9.5-8.2-15.7-2-5.4-6.7-7.8-8.6-13.7-1.2-4.3-1.7-6.7-5.1-10.2-2.6-2.5-5.8-2.3-7.6-6-1.8-4.1-4.1-7.2-4.1-12.5 0-0.6 0.1-2.4 0.7-3.3 3 3 7.1 2.6 11.6 4.4 1.7 0.9 1.3 6.3 3.6 8.6 2 2.2 1.3 6.4 3.6 8.7 2.8 2.7 5.2 5.2 8.7 8.5 0.6-0.6 0.5-0.5 2.9-0.1 0 6.2 7.8 6.4 10.4 11 1.1 2.8-0.8 5.2 1.5 7.4 2.4 2.3 6.8 3.4 9.7 6 5.8 5.7 11.9 13.9 15.2 23.5 0.3 1.4 2.6 2.5 2.7 6 0.2 3-2.7 4.4-2.8 7.3 0.1 1.7 1.8 5.2 4.1 5.2 1.4 3.5 9.4 5.3 12.8 8.3 0.8 0.5 2.3 1.3 3.1 1.8 3.6 1.6 5.5 1 9.3 2.6 3.6 1.9 4.8 5 8.7 6.1 3.4 0.9 5.2-0.7 8.3 0.5 3.2 1.4 12.4 7.5 16 7.7 1.7 0 4.5-0.5 6.6 0.5 0.9 0.4 3.5 2.3 5.8 2.4 5-0.1 5.8-5.2 11-5.3 1.7 0 3.8 0.8 6.4 2.1h1.7c7.9 3.7 10 14.5 19.2 18.7 5.9 2.7 9.8 1.4 15.5 3.7 3.7 1.7 6.7 4.3 12.3 4.5 1.5-0.1 3.5-1.2 5.6-1.3 0.4 0.1 1.3 0.1 1.7 0 1.9 6.5 6.6 8.6 11.4 13.1 1.1 1 2.9 2.1 3.8 4.5 1.5 4.2-1.5 7.6 2.9 10.4 0.7-0.2 2.2 0 2.9 0-0.4-0.3-0.4-1.7 0-2.3 0.2 0 10 5.4 11.1 7.1 0.8 1.6 1 4.6 5.2 5.6-0.1 0.4 1 1.6 1.4 1.6 1.5 0 6.5-1.6 8.7 0.3 2.3 2.2 5.1 7 9.8 7.1 1.7 0.1 3.8-1.3 4.4-4-0.4-0.2-2.2-1.6-2.3-2.4 0.2-1.1 8-6.8 10.2-6.9 3 0 1.1 5.9 4.4 7.5-0.4 0.8-1.7 1.9-1.8 2.6 0 0.6 2.8 1.7 3.2 2 0.2 0 0.5-0.3 0.7-0.3-0.1 0.4-0.4 1.2-0.5 1.7 0.1 4.8 4.9 3.7 5.1 9.4-0.1 2.6-1.4 3.7-1.5 6.8 0.1 1.6 1.6 3.6 1.7 5.7v1.3c-0.3 0.5-1 1.6-1.2 2.1 0 0.6 1.7 2.3 2.8 2.6-2 7-9.1 5.1-12.5 11-2.3 4.3-4.3 10.9-12.2 11.2 1 11.6-3 16.3-3.1 22.2-0.1 3.7 0.4 8.4 4.4 8.5 1.5-0.1 1.7-1.3 4.3 0.2-1.4 3.9-6.3 5-9 8.9-0.9 0.7-3.1 4.4-3.2 7.5 0 4.3 3.9 9.4 6.9 12 0.9 0.7 3.3 0.4 4.2 1.9 0.6 1.3 1.3 5 3.3 6.8 0.8 0.4 2.7 0.2 3.6 1.6 2.3 4.6 4 7.6 5.9 13.2 1.8 5.1 3.2 10.4 5.3 16 1.2 3.6 5.1 5.1 5 8.7 0 3-1.2 5.4 0.9 7.2 4.9 4.3 8.4 7 16 8.7 3.7 0.9 5.2 1.4 8.5 4.2 2.9 2.2 5.8 1.9 9.8 3 5 2.2 8.6 4.7 10.8 9.9 0.5 2.5 1.1 15 0.9 17.1-0.3 3.2-3 9-3.2 12.1-0.4 2.9-0.5 5.7-0.7 9-0.8 2-2.3 5.8-2.4 7.2 0 0.6-0.1 1.2-0.1 1.8-0.7 6.7-4.9 10.9-5.6 18.4-0.2 3.1-3.3 5.9-2.1 9.1-0.4 4.8-0.6 9.2-1.1 13.6-1.9 4.3-2.3 7.2-4.4 11.4-0.4 0.7-1.6 0.8-2.4 1.4-1.2 1.2-2.1 3.5-3.2 5-2.4 2.3-6.2 6.5-6.7 10.3-0.3 1.3-0.2 5.4 0.6 5.5 0 0 1.2 0.4 1.2 1.6-0.2 0.5-0.9 1-2.5 1.1-1.2 2.9-3 4.1-3.2 7-0.1 1.9-1.1 5.4 1 5.4 1.5-0.3 1.9-1.2 3.8-1.9 0.6-0.2 1.5 0 2.2-0.2 0 1-0.1 1.2-0.3 2.2-2.7 4.2-5.4 8.3-8.1 12.4-15.7 1.9-32 3.2-48.6 3.2z m-38.5-795.1c-0.5 1-1.3 2-3.3 3.3-5.8 3.8-10.8 0.5-10.9-1 0-0.3 0.5-0.3 0.7-0.5 4.6-0.6 9-1.4 13.5-1.8z m148.7 779.3c0.4-0.4 0.5-0.6 1-1-1.1 0-2.3-0.2-2-1.7 2.2-0.5 2.7 0.8 5.6 0.3 0.4-0.2 2.6-1 2.6-2.2 0.3-0.9-0.8-0.4-1.7-1.1-0.6 0.3-2.3 1.3-3.4 1.5-1.9 0.4-3.9-2.8-3.6-5 0.1-1 0.9-2 2.6-2.1 4.7-0.9 5 1.1 9.8 0.5 1.5-0.3 5.1-1.7 5.6-2.5 0-0.7 0.1-0.9 0.3-1.5 2-2.3-0.6-4 2.8-6.3 2.5-1.8 9.3-1.2 13.1-2.6 5.7-2.1 9.8-2.3 14.4-5.5 2.3-2 4.3-3.1 6.8-5.7 1.4-1.2 1.6-2.1 2-4.3 0.7-2-3-1-3.4-2.7-0.4-2.4-0.1-3.4-1.6-4.5-0.8-0.4-3.7-0.4-3.5-2.1 0.1-0.6 1.3-1.1 2-1.1 3.6-0.6 5.9 0.9 8.9 0.3 1.5-0.3 5.8 0.5 9.5-0.1 10-2.1 13.5-10.2 18.9-16.4 4.7-5 10.2-9.5 15.2-14.8 2.4-2.8 0.5 1.2 2.4-1.4v0.1c3-4 5.8-7.3 10.2-10.1 1-4.6 1.6-9.7 2.4-14.8 0.4-3.5-0.7 0.5 2.7-2.4 1.9-1.8 4.7-2.2 6.8-5.1 4.8-6.1 9.1-4.5 15.1-10 0.6-0.6 0.9-1.7 2.4-2.5 3-1.9 6-2.4 9.8-3.3 3.4-0.6 7.8-4.3 9.5-6.9 0.5-0.7 0.7-2.9 1.8-4.4 3.6-4.5 4.9-6.5 8.7-11.7 0.5-0.7 1.7-5 2.3-6.8 0.2-1.6 2.2-3.9 3.3-5.1 0.4-0.5 1.4-1.6 1.4-2.6 0.6-2.5 3.7-13.3 4.3-16.9 0.8-4.9-2.1-6.2 1.1-10.1 2.2-2.4 4.3-3.4 6.6-6.7 1.6-2.2 2.3-2.7 3.7-4.8 6.4-9.8 15-19.3 17.3-35.2 0.6-4.7 0.2-8.9-3.1-9.5-2.5-0.4-4.1 1-6.6 0.6-3-0.8-7.8-5.9-9.4-9.1-2.3-1-5-2-8.8-2.4-2.3 0.6-5 1.5-7.7 2-4 0.6-4.2-2.9-8.9-2.6-1.9 0.3-2.8 1.9-4.8 3-0.5 0.1-1 0.1-1.5 0.2 0.2-1.7 0.5-3.7 0.1-5.7-0.3-1.6-2.1-1.1-3.8-2.2-2.7-1.4-10.3-5.2-14.2-5-3.9 0.4-6.6 5.5-9.2 9.5-0.5 1-1.9 3-2.7 3-0.6 0.1-1-1.9-1-2.5-1.7-0.1-3.4 0.4-5.5 0.4-0.2-2.4-1.3-4-3.6-5.1-1.1-0.3-3.2 0-3.1-2.4 0.8-7.3 8.5-16.8 12.6-21.8-0.1-1.9-2.7-2.2-3.9-4.5-1-2.7-3.6-10.2-3.6-13.1-3.9-0.8-8.6-8.4-12.5-8.4-0.4 0.1-1 0.1-1.5 0.1 0.1 0 0-0.4 0-0.5-2.3 0.2-6.2-1.7-7.9-2.4-1.8 0.1-4.4 0.1-6.4 0.3-6.8-1-16.8 0.2-18.8-6.8-1.1 0-3.4-0.6-3.8-1.4-3.2-6.3-5.1-5.3-10.1-10.1-2.3 0.2-4.9 0.1-7.3 0.2-1.2-3.5 0.1-7-3.5-8.1-3.9-1.1-9.4-1.8-11.3-5.5-0.1-0.5 0.1-1.5 0-2 0.7 0.3 3.2 0.1 4-0.6 0 0-4.9-0.7-7.5-0.6-0.7 0.3-6.4 0.9-6.7 1.4-2.1 3.1-4.4 3.1-8.5 3.7-1.7 0.1-5.4-0.4-5.4-2.8-4.9 0.1-9.8 0.1-14.8 0.2-1.3-0.1-3.2-2-3.3-4.6-4-0.7-10.4-2.2-11.5-6.4-1.3 0-3.7-0.1-4.9 0-0.2 3.1 4.2 1.9 5.3 4.9-1.7 0.1-4.4 0.1-6.7 0.1-2.5 1.7-6.9 1.1-7.1 5.1-0.2 3.1 3.1 4.9 3.3 8.1-0.1 0.8-1.8 4.1-2.7 4.3-3.4-0.1-4.9-5.1-4.6-7.8-0.2-1.7 1.7-6.8 2.6-10.8 0.9 0 2.8-1.1 2.9-3.2 0 0-1.5-3-2.5-3.1-3.3 0.3-4.5 3.9-8.2 5.1-7.3 2.1-11.5 3.2-18.6 5.4-3.7 1.2-6.2 1.8-7.7 6.1-0.4 1.6-1.1 5.4-2.6 6.6-1.4 0.5-4.4 1.9-4.6 4.5-0.4 0.1-1.7 0.9-1.7 1.3 0.1 0.4 0.1 1.2 0 1.6-1.4 0.6-1.3 0.4-3.5 0.1-0.6 0.4-1.6 1.4-2.2 1.8 0.4-0.5 1.5-1.6 1.9-2.1-4.6-3.3-5-10.9-13.4-11.2-7 0.1-10.6 5.2-18.3 5.4-5.1-0.1-4.9-4.7-8.1-6.3-4.7-2.1-10.5-4.2-10.8-10.3 0-5.5 0.2-10.6 0-16.2 1.8-2.6 2-13 2-15.5 0.2-1 0-3 0-4-5.2-1.1-6.9-5.5-14-5.6-10.3 0.1-18 1.6-27.8 1.6-1.3 0.1-3.4-1-3.5-2.9 0-0.3-0.1-1 0-1.3 1.4-1.1 5.2-2.6 5.3-5.3-0.2-4.4-0.1-8.6 0-12.8 0.6-0.1 1.8 0 2.4 0-0.1 0.4 0.1 1.4 0 1.9 1.8-2.6 3.5-4.4 3.5-8.8 0.1-5.2 4.9-9.8 5-13.6v-2.4c-1.3 0-5.8-0.4-6.7-0.5-0.8-0.5-3.2-1-5.8-0.8-8 0-18.2-0.2-18.5 7.6-0.1 4-4.8 7.5-6.2 10.7-0.2 0.8-1.8 4.1-4.1 4.3-0.8 0-2.3-1.6-5.5-1.6-6 0-10.4 3.6-16 3.7-1.7-0.1-2.4-2.3-4.9-3.2-7.8-2.3-7.6-6.5-12.7-11.4-1.9-1.8-5.7-5.6-6.9-7.7-1.3-2.5 0.3-3.9-0.8-6.3-0.5-0.7-2.7-3.1-2.3-5.3 0.2-4.9 0.2-9.7 0.1-14.7 0.9-4 3-5.6 3-10.6 0.1-1.2-0.7-3-1.1-4.2-0.1-0.1-0.3-0.5-0.2-0.6 0.1-0.1 0.6 0.3 0.8 0.1 0.1-0.6-1.4-2-1.4-2.6 0.3-7.8 3.7-14.8 10.2-17.1 2.9-1.1 5.4 0.8 7.8-1.4 3.6-3.1 7.4-9.5 15.9-9.8 3.3 0.1 4.9 2.6 8.1 2.5 1.3-0.1 3-2.1 4.4-2.1 5.9 0 12.5 8.6 20.8 5.1-3.5-2.2-1-4.6-0.5-8.3-1.4 0.3-1.1 0.8-4.1 0 5-1.5 11-1 15.6-2.1 0 0.6 1.4 2.1 2 2.1 1.7 0.1 3.1-2.2 7.3-2.1 7-0.1 10 6.1 15.4 6 1.9 0 3.8-3.4 6.4-3.4 12.9 0.2 9.5 15.7 14 24.3 2.3 4.3 5.1 5.7 8.8 9.7 1.6 2.7 1.5 6.4 5.8 6.6 5 0 6.3-4.9 6.3-10.5 0-4.9-2.6-7.3-3.6-10.5 0.1-0.3 0-1 0-1.3-0.3-8.4-8-10.8-8.2-19.6 0.1-19 14-20 27.6-26.4-0.2-0.1-0.6-0.4-0.8-0.5 1.3-1.1 1.3-2.2 4.8-3.2 1.7-0.2 3.7-2.4 7.1-2.9 1.2-0.1 2.6-1.9 3.3-2.7-0.8-0.5-2.5-1.5-3.4-1.8 0.1-0.5-0.1-1.5 0-2 1.9 0 3.8 0.2 4.4-2.4-1.1-0.3-2.8-0.4-4-2.3 1.1 0 3.7-0.8 3.7-3 0-0.7 0-1.9-0.1-2.5-0.4-0.3-1.5 0-2-0.1-1.3-1.2 0-1.3-0.1-3.7-0.1-2.5-1.5-7.1-1.6-8.7 0 0-0.2-2.3 0.2-3.2 0.5 2.7 3.3 6.2 3.3 8.3 0.1 0.7 0.1 2 0.1 2.7 0.1 0.3 0.8 1.5 1.1 1.5 0.6-0.2 6.1-8.8 6.2-10-0.2-1.6-2-2.5-2.6-4.7 0.4-0.3 1.1-0.8 1.4-1.2 0.4 0.4 1.4 2 2 2 1.5-0.1 7-8.5 7.5-10.3 0 0-2.6-2-2.6-3-0.3-0.5 1-1.3 1.6-1.7 0.6 0.1 1.9 0.2 2.5 0.3 4.1-0.3 6.6 0.3 10.5-0.9-1.4-1.1-4.4 0-6.9-0.3-0.7-0.1-2.1-0.2-2.8-0.1 5.5-3 14.7-1.3 20.1-4.5 0.8 0.8 5.6 0.4 9-0.3-0.1-0.4-0.1-1.2-0.1-1.7 0 0-2.5 1.5-3 1.5-1.3 0-2.9-3.4-2.9-4.4-0.6-0.2-1.1-1.6-1.2-2.2-0.1-9.4 9.5-6 13.9-9.6 2.6-1 2.8-1.5 6.1-1.3 3.7 0.3 6.5-1.1 8.3-3.4-0.4-0.3-0.9-1.3-1.3-1.7 0 0 0-0.6-0.2-0.7v-0.7c0.4 0.1 2 0.1 2.6 0.2 1.3 0 8.2 1.3 10.5 0.2 2.3-1.4 2-4.1 5.9-4.1 0.3 3.1 0 3.3 4.2 3.7-6.1-0.1-15 3.1-14.8 8.1 0.2 1.8 4.1 5.9 5.6 6.1 1.7-0.1 6.5-5.6 11.6-6.8 1.1 0 17.9-4.7 18.2-6.5-0.4-2.3-6.6-3.2-8.4-3.4-7.4-0.7-19.3-7.8-20.2-13.3-1.4-0.3-3.7-0.9-5.6-1 1.4-1.7 10.4-1.9 10.3-6.5-0.5-3.9-8.1-4-13.7-4.4-11.6-0.7-16.1 5.5-24.1 6.1 3.2-5.8 8.6-3.7 14.2-7.9 3.6-3 0.5-5 6-6.1 9.6-1.8 15.1 0.1 25 1 12.8 1.1 22.6 6.4 29.4-0.9 3.1-3.4 21.2-0.9 20.8-6-0.5-3.8-2.4-5.6-5-8.1-1.7-0.3 0.7-1.3-2.2-2.6 0-0.6-0.3-1.3-0.3-1.9-5.2 1.3-16.1 2.4-22.1 1.9-0.6 0.1-2.3-0.6-2.5-0.9 4.6-1.1 17.4-0.6 18.8-3.5 0-0.8-1.9-1.3-2.3-2-5.9-0.3-17.9-3.4-18.8-8.7-0.1-0.1-0.1-0.3-0.1-0.3-5.4-0.8-8.8-3.3-12.1-5.1 1.1-0.4 3.4-0.5 3.3-2.4-0.1-1.5-2.4-3-2.2-4.4-2.4-0.8-10.6-4.5-8.8-7.2 2-3.3-8-5-9.6-9.1-0.6-0.1-3.6-1.7-4.4-2.3-1.6 0.6-6 1.6-5.2 3.5 1.5 3.3-2.8 3.5-7.2 4.9-3 1-5.2 3.2-7.9 3-4.5-0.4-8.2-5.4-11.2-5.9-4.2-0.5-2.7-7.2-3.7-10.6-1.7-4.1-14.4-2.5-15.3-7.7-7.2-1.1-6.4-3.7-13.7-4.2-1.5-0.2-3.7-0.3-5.6-0.4-7.5-0.5-12-3.1-19.5-3.5-3.9-0.2-7.7 0.6-7.6 3.2 0.2 1.5 9.5 3.8 1.1 6.6-3.4 1 4.9 4.9 5.6 6.9 1.1 4.8-6.1 5.4-9.6 5.9 3.7 3.3 10.6 4.4 13.9 7.3 2.6 2.6 1.1 6.7 1.3 11.6-0.2 2.9-15.5 9.3-21 10 9.7 3.3 6.2 11.7 10 14.9-0.9 0.9-3.8 4.4-4 6.1-3.4 0.2-6.2 1-8.9-0.4-6.9-3.6-16.9-9.9-17.2-14.4-0.2-4.8 0.1-8.7-7.7-11.5-5.7-1.2-11.4-2-17.2-2.9-10.2-3.8-21.2-6.5-33.2-8.7-1.7-0.4-8.2-2.7-12-2.7-4.1 0.2-6 2.4-10 2.4-0.2-3.4-3.9-11.1-9.8-11.2-2.7 0.2-4 1.3-6.7 1.7 1-1.6 0-2.4 0.3-6.4 0.3-5.8 4-11 10.3-14.4 2.2-1.6 6.9-6.5 8.9-7 4.5-0.9 8.6 2 8.8-1.3-0.1-2.2-9.9-1.9-13.5-2.8 1.9 0.3-5.9-2.4 15.6 0.6 5.6 0.4 2.2-2.8 5.4-2.9 1.6-0.1 3.7-0.2 5.7-0.1 6.5-0.1 9.7-3.4 13.9-4.9v-1.9c-8.9-1.1-17.4-0.2-21.4-3.9 1.3-0.1 3.4-0.2 4.6-0.1 3.3 0.7 6.5 2.7 11.6 2.8 4.2-0.2 13.4-0.9 13.7-2.4-0.1-2.4-0.6-3.4-1.1-3.8 5.1 0.3 7.2 2.4 10.6 2.6 2.9-0.2 5.6 0.2 8.6 0.2-1.2-0.6-0.3-2.9 3.1-0.6 1.8 1.3 14.4-3.8 14.7-5.5-0.2-1.2-5.8-2.3-6-3.2 0-0.6-1.3-1.6 0-2.7 2.9-0.1 5.7-0.5 8.6-0.5 10.2 0 20.2 0.8 30.2 1.5 0.3 0.1 1.3 1.1 2.1 1.3 3.3 0 4.7-0.9 7.8-0.7 5.1 0.6 21.2 6.5 21.7 9.2 0.2 1.6-4.8 3.1-7 4-1.7 0.2-6.1-0.7-6.1 1.1 0 0.9 3.7 2.1 4.7 2.5-3.1 0.4-9 0.8-11.2 0.7-3.8-0.3-7.2-0.6-10.9-0.7-3.5-0.4-9.9 1.1-10 2.3 0.2 1.6 8.2 3.4 11.1 3.6 3 0.3 4.4-1.2 7.5-1.1 1.9 0.2 1.7 0.8 4.4 1 1.9 0.2 3.7-0.6 4.9-1.2 7.5 2.3 11.6 4.6 20 7-3.7 3.2 10.9 4.5 17.2 6.5 6.5 2.2 10.8 2.2 18.3 4.4 0.6 0.3 1.6 1.5 2.6 1.6 0.8 0.1 2.3-0.3 2.3-1.1-0.8-3.1-14.3-6.7-18.8-9.6 1 0.4 2.6 0.3 3.7 0.4 2.8 1.8 18.6 6.3 23.2 6.9 0.9-1.2 3.1-2.7 3-3.8-0.3-1.2-4.5-2.2-4.6-3-0.2-0.7-0.3-1.4-0.3-2.1-1.2 0.1-2.9-0.4-4.1-0.5-0.7-1.9-2.2-1-6.9-2.1-1.6-0.7-5.1-3.2-5.8-4.6-0.9-0.1-2.3-0.2-3.2-0.4 0-0.6 0-1-0.2-1.6 0.8 0.4 2.2 0.5 3.6 0.4-0.1-0.4 0-0.8-0.2-1.2-1.9-0.2-2.6-0.1-4.9-0.8 0.2-0.1 3.1-0.8 4.7-0.6 11.9 1.5 12.9 8.3 24.9 10.1 2.7 0.3 2.8-1.2 2.6-2.5 4.5 0.5 5-0.2 5-0.5-0.1-0.5-0.3-0.8-0.3-1.3 2.5 0.4 5.2 0.5 6-0.4 9.2 3.4 18.3 7.1 27.2 11.1 0.4 0.3 1.1 0.7 2 0.9 4.8 2.3 9.6 4.5 14.4 7-1.5-0.6-3-1.2-4.7-1.5-1.8-0.5-1.7-0.5-3.7-0.8 1.3 2.2 11.6 5.3 18.8 7.6 1.1 0.6 2.1 1.3 3.2 2-1.3 1.3-3 1.8-3.6 4-3-1.4-2.9-1.2-5.6-1.1 0.1 0 0 0.1 0 0.1-3.9 0.7-4.5 2.2-7 3.4 0.1 0.9 0.3 1.4 0.5 2.2 1.4-0.1 2.6 0.3 4.2 0.9-0.4 1.2-1.8 0.9-1.5 2 0.5 2.6 6.5 4.7 8.1 6.9 0.9 1 2 3.2 2.8 3.7 3.9 1.8 4-0.6 7.7 1.9-1.6 0.3-3-0.1-2.6 1.2 0.6 3.1 8.9 10.9 13.6 13.4 0.5 0.4 0.7 1.6 1.9 2.3 3.7 1.7 5.1 1.6 7.2 4.3 2.3 0.5 5.2-0.1 7.9 0.6 4.9 1.4 5.6 5.5 10.3 6.9 1.2 0.1 1.4-0.3 3.6 0.2 0.3 0.7 1.2 1.1 2.5 1.6 5 1.1 1.4-4.4 5.4-4.4-0.7-1.1-1-3.8-1.5-5.4-0.7-2.6 4.8-1.8 6.3-3.2 56.9 47.4 100.2 110.4 123.8 182.2-0.2 0.2-0.5 0.3-0.6 0.5-6 11.1-10.6 23.8-14 38.1-1.4 5.3-9.3 9.4-9.1 17.1 2.4 14.6 10.7 26.5 10.8 43 0.3 9.3-6.6 26.8-15.2 31.3 2.1 5.2 8.5 12.2 9 17.4-0.2 3.1 1.1 6.1 1.1 11.8h-1c2.3 2.5 2.3 2.8 4.4 5 0.1 1.4 16.3 17.6 18.8 19.4 4.4 4.4 6.4 9.5 8.4 15.2-28.6 147.9-138.6 266.6-281.3 307.8zM632 132c-0.5-0.1-0.6 0-1.3-0.1-1.4-0.2-2.2-0.7-3.1-1.2 1.5 0.4 3 0.8 4.4 1.3z m0 0%22/> </svg>");
}

#maga-better-icon-switch {
    background-repeat: no-repeat;
    background-position: center;
    background-image: url("data:image/svg+xml;charset=utf8,<svg width=%2230%22 height=%2230%22 class=%22icon%22 viewBox=%220 0 1024 1024%22 version=%221.1%22 xmlns=%22http://www.w3.org/2000/svg%22> <path fill=%22%23FAFAFA%22 d=%22M208.5 284.93c-37.07 19.34-41.73 51.05-43.29 63.69-0.09 0.68 0 2.25-0.08 2.9a117.17 117.17 0 0 0 0.13 16.09l0.13 2.1v285.85l-0.13 1.06a116.39 116.39 0 0 0-0.2 15.77v2.12c1.16 14.2 6.55 45 42.81 64.23l0.88 0.47 0.47 0.25 256.7 148.22c0.05 0 9.64 6.14 17 8.62 0.24 0.08 0.76 0.39 1 0.47a89.08 89.08 0 0 0 27 5.66 80.57 80.57 0 0 0 8.49-0.11 100 100 0 0 0 35.84-9.46L811.41 745.8c6.92-5.16 41.85-33.35 47.92-65 0.85-3.25 1.32-11.21 1.32-14.61L860.28 512l0.51-154.31c0-3.43-0.47-11.46-1.33-14.75-6.07-31.55-40.75-59.58-47.74-64.78L556 131.14a99.8 99.8 0 0 0-35.49-9.45c-3-0.18-5.92-0.21-8.78-0.11-11.66 0.61-20.55 3.72-25.33 5.2-0.53 0.16-1.66 0.77-2.16 0.94-7.34 2.46-16.87 8.54-16.94 8.6l-1.34 0.87z m-19.15-35.79l251.83-144.48c0.92-0.62 11.44-6.74 13.64-7.78a121.67 121.67 0 0 1 55.37-15.95c2.2-0.08 4.43-0.11 6.7-0.07 19.05 0.32 38.28 5 57.14 13.92l1.46 0.76 258.57 148.75 1.26 0.9c8.35 6.12 63.23 48.18 65.77 103.58 0.18 1.42 0.25 10.93 0.25 12.41l-0.5 150.9 0.37 150.47c0 1.51-0.08 11.27-0.27 12.73-2.6 55.07-57 96.93-65.83 103.43-0.51 0.38-1.41 1-1.53 1.07l-1 0.64S573.75 929 573.32 929.22c-18.88 8.89-38.13 13.57-57.29 13.9-2.3 0-4.57 0-6.81-0.07a123.52 123.52 0 0 1-55.73-15.91c-2.27-1.06-13-7.31-13.88-7.91L189.34 774.79c-58.85-30.95-67.12-85.91-64.67-112.48 0-2 0.06-12 0.15-13V374.76c-0.09-1-0.19-11.07-0.15-13.08-2.45-26.6 5.83-81.57 64.68-112.54z%22/> <path fill=%22%23FAFAFA%22 d=%22M163.7 603.25a20.31 20.31 0 0 1-20.28 20.31 20.32 20.32 0 0 1-20.29-20.31V436a20.3 20.3 0 0 1 20.29-20.31A20.29 20.29 0 0 1 163.7 436zM888.74 603.25a20.31 20.31 0 0 1-20.28 20.31 20.31 20.31 0 0 1-20.29-20.31V436a20.29 20.29 0 0 1 20.29-20.31A20.29 20.29 0 0 1 888.74 436zM627.12 894a20.24 20.24 0 0 1-27.72-7.41 20.29 20.29 0 0 1 7.43-27.7l144.84-83.74a20.27 20.27 0 0 1 27.7 7.38 20.3 20.3 0 0 1-7.4 27.72zM506 873.48c-29 0-47.07-13.33-47.82-13.88L235 730.34c-56.67-29.61-46-86.53-45.92-87.1V390.41c-0.07-0.05-10.7-57 46.07-86.67l223.69-129.4c0.48-0.37 18.48-13.7 47.44-13.7 14.85 0 29.92 3.53 44.81 10.57L773 298.8c2.28 1.6 51.48 36.94 51.48 81.42l-0.42 136.84 0.38 136.81c0 44.47-49.25 79.84-51.34 81.3l-222 127.65c-15.1 7.12-30.22 10.66-45.1 10.66z m0.24-707.82c-27.28 0-44.47 12.76-44.64 12.9l-224 129.63c-53.42 27.93-43.92 79.52-43.48 81.71v253.8c-0.47 2.7-10 54.3 43.37 82.16L461 855.38c0.42 0.31 17.8 13.07 45 13.07 14.13 0 28.5-3.42 42.71-10.11l221.65-127.42c0.29-0.2 49-35.2 49-77L819 517.06l0.44-136.84c0-41.86-48.68-76.83-49.17-77.17L548.72 175.69c-14.02-6.61-28.4-10.03-42.47-10.03z%22/> <path fill=%22%23FAFAFA%22 d=%22M612.26 330.11H411.75A71.84 71.84 0 0 0 340 401.87v7.39A71.84 71.84 0 0 0 411.75 481h200.51A71.84 71.84 0 0 0 684 409.26v-7.39a71.84 71.84 0 0 0-71.74-71.76z m-3.17 126.64c-28.49 0-50.65-22.17-50.65-50.66s22.16-50.66 50.65-50.66 50.65 22.17 50.65 50.66-22.16 50.66-50.65 50.66zM612.25 543h-200.5A71.85 71.85 0 0 0 340 614.74v7.39a71.84 71.84 0 0 0 71.77 71.76h200.5A71.84 71.84 0 0 0 684 622.13v-7.39A71.84 71.84 0 0 0 612.25 543zM414.91 669.62c-28.49 0-50.65-22.16-50.65-50.66s22.16-50.65 50.65-50.65 50.66 22.16 50.66 50.65-22.16 50.66-50.66 50.66z%22/> </svg>");
}

#maga-better-icon-more {
    background-repeat: no-repeat;
    background-position: center;
    background-image: url("data:image/svg+xml;charset=utf8,<svg width=%2230%22 height=%2230%22 class=%22icon%22 viewBox=%220 0 1024 1024%22 version=%221.1%22 xmlns=%22http://www.w3.org/2000/svg%22> <path d=%22M411.733333 232.533333v206.933334H200.533333c-44.8-2.133333-81.066667-40.533333-81.066666-85.333334s36.266667-83.2 81.066666-85.333333h4.266667c21.333333 0 42.666667 8.533333 57.6 21.333333-12.8-14.933333-21.333333-34.133333-21.333333-57.6v-4.266666c2.133333-44.8 40.533333-81.066667 85.333333-81.066667s83.2 36.266667 85.333333 81.066667v4.266666z%22 fill=%22%23FAFAFA%22></path> <path d=%22M433.066667 460.8h-234.666667c-55.466667-4.266667-100.266667-49.066667-100.266667-106.666667s44.8-102.4 100.266667-106.666666h21.333333v-14.933334-6.4c4.266667-55.466667 49.066667-100.266667 106.666667-100.266666s104.533333 44.8 106.666667 100.266666v234.666667z m-228.266667-170.666667h-4.266667c-34.133333 2.133333-59.733333 29.866667-59.733333 64s25.6 61.866667 59.733333 64H390.4v-185.6-4.266666c-2.133333-34.133333-29.866667-59.733333-64-59.733334s-61.866667 25.6-64 59.733334v4.266666c0 14.933333 6.4 32 17.066667 42.666667l-29.866667 29.866667c-12.8-10.666667-29.866667-14.933333-44.8-14.933334z%22 fill=%22%23FAFAFA%22></path> <path d=%22M612.266667 791.466667v-206.933334H823.466667c44.8 2.133333 81.066667 40.533333 81.066666 85.333334s-36.266667 83.2-81.066666 85.333333h-4.266667c-21.333333 0-42.666667-8.533333-57.6-21.333333 12.8 14.933333 21.333333 34.133333 21.333333 57.6v4.266666c-2.133333 44.8-40.533333 81.066667-85.333333 81.066667s-83.2-36.266667-85.333333-81.066667v-4.266666z%22 fill=%22%23FAFAFA%22></path> <path d=%22M697.6 898.133333c-57.6 0-104.533333-44.8-106.666667-100.266666v-234.666667h234.666667c55.466667 4.266667 100.266667 49.066667 100.266667 106.666667s-44.8 102.4-100.266667 106.666666h-21.333333v21.333334c-2.133333 55.466667-49.066667 100.266667-106.666667 100.266666z m-64-292.266666V795.733333c2.133333 34.133333 29.866667 59.733333 64 59.733334s61.866667-25.6 64-59.733334v-4.266666c0-14.933333-6.4-32-17.066667-42.666667l29.866667-29.866667c12.8 10.666667 29.866667 17.066667 46.933333 17.066667 34.133333-2.133333 59.733333-29.866667 59.733334-64s-25.6-61.866667-59.733334-64H633.6z%22 fill=%22%23FAFAFA%22></path> <path d=%22M411.733333 791.466667v-206.933334H200.533333c-44.8 2.133333-81.066667 40.533333-81.066666 85.333334s36.266667 83.2 81.066666 85.333333h4.266667c21.333333 0 42.666667-8.533333 57.6-21.333333-12.8 14.933333-21.333333 34.133333-21.333333 57.6v4.266666c2.133333 44.8 40.533333 81.066667 85.333333 81.066667s83.2-36.266667 85.333333-81.066667v-4.266666z%22 fill=%22%23FAFAFA%22></path> <path d=%22M326.4 898.133333c-57.6 0-102.4-44.8-106.666667-100.266666v-6.4-14.933334c-6.4 0-14.933333 2.133333-21.333333 0-55.466667-4.266667-100.266667-49.066667-100.266667-106.666666s44.8-104.533333 100.266667-106.666667h234.666667v234.666667c-4.266667 55.466667-51.2 100.266667-106.666667 100.266666z m-78.933333-179.2l29.866666 29.866667c-10.666667 12.8-17.066667 27.733333-17.066666 42.666667v4.266666c2.133333 34.133333 29.866667 59.733333 64 59.733334s61.866667-25.6 64-59.733334V605.866667H200.533333c-34.133333 2.133333-59.733333 29.866667-59.733333 64s25.6 61.866667 59.733333 64h4.266667c14.933333 0 32-4.266667 42.666667-14.933334z%22 fill=%22%23FAFAFA%22></path> <path d=%22M612.266667 232.533333v206.933334H823.466667c44.8-2.133333 81.066667-40.533333 81.066666-85.333334s-36.266667-83.2-81.066666-85.333333h-4.266667c-21.333333 0-42.666667 8.533333-57.6 21.333333 12.8-14.933333 21.333333-34.133333 21.333333-57.6v-4.266666c-2.133333-44.8-40.533333-81.066667-85.333333-81.066667s-83.2 36.266667-85.333333 81.066667v4.266666z%22 fill=%22%23FAFAFA%22></path> <path d=%22M819.2 460.8H590.933333V232.533333v-6.4c4.266667-55.466667 49.066667-100.266667 106.666667-100.266666s102.4 44.8 106.666667 100.266666v21.333334c6.4 0 14.933333-2.133333 21.333333 0 55.466667 4.266667 100.266667 49.066667 100.266667 106.666666s-44.8 102.4-100.266667 106.666667h-6.4z m-185.6-42.666667H823.466667c34.133333-2.133333 59.733333-29.866667 59.733333-64s-25.6-61.866667-59.733333-64h-4.266667c-14.933333 0-32 6.4-42.666667 17.066667L746.666667 275.2c10.666667-12.8 17.066667-27.733333 17.066666-42.666667v-4.266666c-2.133333-34.133333-29.866667-59.733333-64-59.733334s-61.866667 25.6-64 59.733334V418.133333z%22 fill=%22%23FAFAFA%22></path> </svg>");
}

#maga-better-icon-book-mark {
    background-repeat: no-repeat;
    background-position: center;
    background-image: url("data:image/svg+xml;charset=utf8,<svg width=%2230%22 height=%2230%22 class=%22icon%22 viewBox=%220 0 1024 1024%22 version=%221.1%22 xmlns=%22http://www.w3.org/2000/svg%22> <path d=%22M604.8 771.2c-6.4 0-12.8-1.6-17.6-3.2L512 734.4 436.8 768c-14.4 6.4-32 4.8-43.2-4.8-12.8-9.6-19.2-24-17.6-40l8-81.6-54.4-60.8c-11.2-11.2-14.4-28.8-9.6-43.2 4.8-14.4 17.6-25.6 33.6-30.4l80-17.6 41.6-70.4c8-12.8 22.4-22.4 38.4-22.4s30.4 8 38.4 22.4l41.6 70.4 80 17.6c16 3.2 27.2 14.4 32 30.4 4.8 14.4 1.6 32-9.6 43.2l-56 60.8 8 81.6c1.6 16-4.8 30.4-17.6 40-8 4.8-16 8-25.6 8zM400 563.2l38.4 41.6c8 9.6 12.8 22.4 11.2 33.6l-6.4 56 51.2-22.4c11.2-4.8 24-4.8 35.2 0l51.2 22.4L576 640c-1.6-12.8 3.2-24 11.2-33.6l38.4-41.6-54.4-11.2c-12.8-3.2-22.4-9.6-28.8-20.8L512 481.6l-28.8 48c-6.4 11.2-16 17.6-28.8 20.8L400 563.2zM864 288H240c-62.4 0-112-49.6-112-112S177.6 64 240 64h624c17.6 0 32 14.4 32 32s-14.4 32-32 32H240c-27.2 0-48 20.8-48 48s20.8 48 48 48h624c17.6 0 32 14.4 32 32s-14.4 32-32 32z m-64 672H224c-52.8 0-96-43.2-96-96V176c0-17.6 14.4-32 32-32s32 14.4 32 32v688c0 17.6 14.4 32 32 32h576c17.6 0 32-14.4 32-32V256c0-17.6 14.4-32 32-32s32 14.4 32 32v608c0 52.8-43.2 96-96 96z m64-678.4c-4.8 0-8-1.6-12.8-3.2C809.6 260.8 784 220.8 784 176s25.6-84.8 67.2-102.4c16-6.4 35.2 0 41.6 16 6.4 16 0 35.2-16 41.6-17.6 8-28.8 25.6-28.8 44.8s11.2 36.8 28.8 43.2c16 6.4 24 25.6 16 41.6-4.8 12.8-16 20.8-28.8 20.8z%22 fill=%22%23FAFAFA%22/> </svg>");
}

`;

    let KEY_QRCODE_URL = 'https://qun.qq.com/qrcode/index?data=';
    /*这里的ID若改变记得同步到optimize-search中，否则会导致设置模块失效*/
    let KEY_QRCODE_SWITCH = 'maga-qrcode-url-key-switch';
    let runType = 'alone';

    const website$6 = {
        setRunType: function (val) {
            runType = val || 'alone';
        },
        init: function ($j) {

            GM_addStyle(GM_getResourceText('toastr_css'));

            function getQrLayout() {
                if ($j('#maga-qrcode-dialog').length !== 0) {
                    return
                }
                $j(`<div id='maga-qrcode-dialog'>
                                <a id="maga-qrcode-dialog-close" href="javascript:;">&nbsp;✕&nbsp;</a>
                                <a id="maga-qrcode-dialog-qrcode" target="_blank"></a>
                                <span id="maga-qrcode-dialog-hint">请用手机扫描二维码</span>
                            </div>`,
                ).appendTo($j('body'));
                $j('#maga-qrcode-dialog').css('display', 'flex');
                $j('#maga-qrcode-dialog').click(function () {
                    $j('#maga-qrcode-dialog').css('display', 'none');
                });
            }

            function generateQRCode(qrcodeText) {
                // GM_log('qrcodeText==================>' + qrcodeText)
                getQrLayout();
                $j('#maga-qrcode-dialog-qrcode').attr('style', `background-image:url('${KEY_QRCODE_URL}${encodeURIComponent(qrcodeText)}');`);
            }

            function getSelect() {
                if (window.getSelection) {
                    return window.getSelection().toString()
                } else {
                    return document.selection.createRange().text
                }
            }

            function checkUrlFormat(string) {
                return /^(https?:)?\/\/(\S+\.)+\S{2,}$/i.test(string)
            }

            // 按住CTRL键，右键点击图片或超级链接，即可查看该图片或链接的地址的二维码;
            $j(document).contextmenu(function (e) {
                if (e.ctrlKey) {
                    var target = e.target;
                    //找出选中的内容是否存在超链接
                    if (!/^(a|img)$/i.test(target.tagName)) {
                        while (!/^(body|html)$/i.test(target.tagName)) {
                            target = target.parentNode;
                            if (/^(a|img)$/i.test(target.tagName)) {
                                break
                            }
                        }
                    }

                    if (checkUrlFormat(target.href)) {
                        if (target.tagName === 'A') {
                            generateQRCode(target.href);
                        } else if (target.tagName === 'IMG') {
                            generateQRCode(target.src);
                        }
                    }
                }
            });

            $j(document).keyup(function (e) {
                // GM_log('e.key================' + e.key)
                if (e.key === 'Escape') {
                    if ($j('#maga-qrcode-dialog').length === 0) {
                        return
                    }
                    // ESC关闭二维码弹窗
                    $j('#maga-qrcode-dialog').css('display', 'none');
                }
                if (e.ctrlKey && e.key === 'q') {
                    // 划词按Ctrl + Q 转化为二维码
                    if ($j('#maga-qrcode-dialog').length === 0) {
                        let selectText = getSelect();
                        if (selectText && selectText.length > 0) {
                            generateQRCode(selectText);
                        } else {
                            generateQRCode(location.href);
                        }
                    } else if ($j('#maga-qrcode-dialog').css('display') === 'flex') {
                        $j('#maga-qrcode-dialog').css('display', 'none');
                    } else {
                        $j('#maga-qrcode-dialog').css('display', 'flex');
                    }
                }
            });
            // 点击菜单栏里的“查看二维码”就可以查看当前页面的二维码(快捷键:Ctrl + Q );
            GM_registerMenuCommand('查看二维码', () => {
                if ($j('#maga-qrcode-dialog').length === 0) {
                    let selectText = getSelect();
                    if (selectText && selectText.length > 0) {
                        generateQRCode(selectText);
                    } else {
                        generateQRCode(location.href);
                    }
                } else if ($j('#maga-qrcode-dialog').css('display') === 'flex') {
                    $j('#maga-qrcode-dialog').css('display', 'none');
                } else {
                    $j('#maga-qrcode-dialog').css('display', 'flex');
                }
            });

            function createQrCode() {

                if ($j('#maga-qrcode-static').length == 0) {
                    let qrCode = document.createElement('div');
                    qrCode.id = 'maga-qrcode-static';
                    document.getElementsByTagName('body')[0].appendChild(qrCode);
                }
                let display = `display: ${GM_getValue(KEY_QRCODE_SWITCH, true) ? 'block' : 'none'};`;
                $j('#maga-qrcode-static').hover(function () {
                    this.className = 'maga-qrcode-static maga-qrcode-static-image';
                    this.style = display + `background-image:url('${KEY_QRCODE_URL}${encodeURIComponent(location.href)}');`;
                }, function () {
                    this.className = 'maga-qrcode-static';
                    this.style = display;
                });
                $j('#maga-qrcode-static').attr('class', 'maga-qrcode-static');
                $j('#maga-qrcode-static').attr('style', display);
            }

            setTimeout(function () {
                createQrCode();
            }, 200);
            if (runType === 'alone') {
                GM_registerMenuCommand('二维码工具开关', function () {
                    GM_setValue(KEY_QRCODE_SWITCH, !GM_getValue(KEY_QRCODE_SWITCH, true));
                    if (GM_getValue(KEY_QRCODE_SWITCH, true)) {
                        toastr.success('二维码工具已开启！');
                    } else {
                        toastr.error('二维码工具已关闭！');
                    }
                    createQrCode();
                });
            }
        },
    };

    const modules$1 = [website$6];

    const prepare$1 = {
        init: function ($j, runType) {
            if (GUtils.inIframe()) {
                return
            }
            GM_addStyle(CSS_STR);
            for (let i = 0; i < modules$1.length; i++) {
                let module = modules$1[i];
                module.setRunType((typeof runType === 'undefined') ? 'alone' : runType);
                module.init($j);
            }
        }
    };

    var CSS_STR = `
.maga-qrcode-static {
    display: block;
    position: fixed;

    width: 40px;
    height: 40px;

    bottom: 140px;
    right: 10px;
    cursor: pointer;
    transition: 0.4s all;
    background-color: #FFFFFF;
    background-position: center;
    background-repeat: no-repeat;
    background-size: 70%;
    box-shadow: 0 0 2px #999999;
    border-radius: 1px;
    z-index: 9999999;
    background-image: url("data:image/svg+xml;charset=utf8,<svg class=%22icon%22 viewBox=%220 0 1024 1024%22 version=%221.1%22 xmlns=%22http://www.w3.org/2000/svg%22 width=%22200%22 height=%22200%22><path d=%22M126.160164 820.041068h77.798768v77.798768H126.160164z m126.160165-48.361397V946.201232H77.798768v-174.521561z m7.359342-77.798768h-189.240246A70.439425 70.439425 0 0 0 0 764.320329v189.240246a70.439425 70.439425 0 0 0 70.439425 70.439425h189.240246a70.439425 70.439425 0 0 0 70.439426-70.439425v-189.240246a70.439425 70.439425 0 0 0-70.439426-70.439426z m560.361397 126.160165h77.798768v77.798768H820.041068z m126.160164-48.361397V946.201232h-174.521561v-174.521561z m7.359343-77.798768h-189.240246a70.439425 70.439425 0 0 0-70.439426 70.439426v189.240246a70.439425 70.439425 0 0 0 70.439426 70.439425h189.240246a70.439425 70.439425 0 0 0 70.439425-70.439425v-189.240246a70.439425 70.439425 0 0 0-70.439425-70.439426zM820.041068 126.160164h77.798768v77.798768H820.041068z m126.160164-48.361396V252.320329h-174.521561V77.798768zM953.560575 0h-189.240246a70.439425 70.439425 0 0 0-70.439426 70.439425v189.240246a70.439425 70.439425 0 0 0 70.439426 70.439426h189.240246a70.439425 70.439425 0 0 0 70.439425-70.439426v-189.240246A70.439425 70.439425 0 0 0 953.560575 0zM126.160164 126.160164h77.798768v77.798768H126.160164z m-48.361396 126.160165V77.798768H252.320329V252.320329z m-7.359343 77.798768h189.240246a70.439425 70.439425 0 0 0 70.439426-70.439426v-189.240246A70.439425 70.439425 0 0 0 259.679671 0h-189.240246A70.439425 70.439425 0 0 0 0 70.439425v189.240246a70.439425 70.439425 0 0 0 70.439425 70.439426zM0 567.720739h77.798768v77.798768H0zM456.279261 630.800821H378.480493v203.958933h63.080082v48.361396H378.480493v77.798768h126.160164v63.080082h77.798768v-63.080082h63.080082V883.12115H567.720739V946.201232h-48.361396v-111.441478h126.160164V756.960986h-189.240246z m504.640657-252.320328H883.12115v126.160164h-111.441479V378.480493h-189.240246V252.320329h-63.080082v-48.361397h63.080082v-63.080082h63.080082V63.080082h-63.080082V0H378.480493v77.798768h126.160164v48.361396H441.560575v140.87885h63.080082V378.480493H441.560575v63.080082H330.119097V378.480493H252.320329v63.080082h-48.361397V378.480493H63.080082v63.080082H0v77.798768h77.798768v-63.080082H189.240246v63.080082h63.080083v126.160164h77.798768v-126.160164h126.160164v-63.080082h237.601642v48.361396H504.640657v77.798768h63.080082v126.160164h140.87885V630.800821h-63.080082v-48.361396h252.320329v-63.080082H946.201232v63.080082h77.798768V504.640657h-63.080082z%22 fill=%22%232C2C2C%22></path></svg>");
}

.maga-qrcode-static-image {
    width: 160px;
    height: 160px;
    background-size: 100%;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.15);
    border-radius: 4px;
}

#maga-qrcode-dialog {
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);

    box-shadow: 0 2px 10px 0 rgba(0, 0, 0, 0.15);
    z-index: 999999;
    position: fixed;
    padding: 10px 14px;
    font-family: Arial, serif;
    background: #FFFFFF;

    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

#maga-qrcode-dialog-qrcode {
    padding: 20px;
    text-decoration: none !important;
    background-position: center;
    background-repeat: no-repeat;
    width: 140px;
    height: 140px;
}

#maga-qrcode-dialog-close {
    font-size: 14px;
    color: gray;
    line-height: 22px;
    text-align: center;
    align-self: flex-end;
    text-decoration: none !important;
}

#maga-qrcode-dialog-hint {
    font-size: 14px;
    color: gray;
}
`;

    const common = {
        generic: function (param) {
            let url;
            if (typeof param == 'undefined') {
                param = 'target';
            }
            let encodeUrl = GUtils.getUrlParam(param);
            if (encodeUrl && encodeUrl.length > 0) {
                url = decodeURIComponent(encodeUrl);
                // GM_log("通过参数获取===========" + url)
            } else {
                let regex = location.href.match(/target=(.+?)(&|$)/);
                if (regex && regex.length == 3) {
                    url = decodeURIComponent(regex[1]);
                    // GM_log("通过正则获取===========" + url)
                }
            }
            if (url && url.length > 0) {
                if (url.startsWith("http")) {
                    location.href = url;
                } else if (url.startsWith("//")) {
                    location.href = "http:" + url;
                } else {
                    location.href = "http://" + url;
                }
            }
        }
    };

    let regexStr$5 = ['jianshu.com/go-wild?ac=2&url='];

    const website$5 = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$5)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            common.generic('url');
        },
    };

    let regexStr$4 = ['link.zhihu.com/?target='];

    const website$4 = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$4)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            common.generic('target');
        }
    };

    let regexStr$3 = ['link.csdn.net/?target='];

    const website$3 = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$3)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            common.generic('target');
        }
    };

    let regexStr$2 = ['gitee.com/link?target='];

    const website$2 = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$2)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            common.generic('target');
        }
    };

    let qqForbid = "https://c.pc.qq.com/middlem.html";
    let wechatForbid = "https://weixin110.qq.com/cgi-bin/mmspamsupport-bin/newredirectconfirmcgi";

    let regexStr$1 = ['https://c.pc.qq.com', 'https://weixin110.qq.com'];

    const website$1 = {
        intercepter: function () {
            return GUtils.intercepter(regexStr$1)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            if (location.href.indexOf(qqForbid) !== -1) {
                common.generic('pfurl');
            } else if (location.href.indexOf(wechatForbid) !== -1) {
                common.generic('url');
            }
        }
    };

    let regexStr = ['google'];

    const website = {
        intercepter: function () {
            return GUtils.intercepter(regexStr)
        },
        setRunType: function (val) {
        },
        init: function ($j) {
            document.addEventListener("DOMContentLoaded",
                () => $j("#res a").attr("target", "_blank"));
        },
    };

    const modules = [website$5, website$4, website$3, website$2, website$1, website];

    const prepare = {
        init: function ($j, runType) {
            for (let i = 0; i < modules.length; i++) {
                let module = modules[i];
                if (module.intercepter()) {
                    continue;
                }
                module.setRunType((typeof runType === 'undefined') ? 'alone' : runType);
                module.init($j);
            }
        },
    };

    const prepares = [
        prepare,
        prepare$2,
        prepare$1,
        prepare$7,
        prepare$6,
        prepare$5,
        prepare$3,
        prepare$4,
    ];

    (function () {
        var jq = jQuery.noConflict();
        for (let i = 0; i < prepares.length; i++) {
            let prepare = prepares[i];
            prepare.init(jq, 'complex');
        }
    })();

})();
