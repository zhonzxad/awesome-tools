// ==UserScript==
// @id           ctfile@405647825@qq.com
// @name         城通网盘、皮皮盘、牛盘显示正确下载地址
// @namespace    http://weibo.com/pendave
// @version      0.8
// @description  城通网盘、皮皮盘、牛盘显示正确下载地址!去掉遮挡的popjump透明层！自动跳到第二页！
// @author       405647825@qq.com
// @include      *ctfile.com*
// @include      *pipipan.com*
// @include      *6pan.cc/file-*html
// @include      *666pan.cc/file-*html
// @include      *777pan.cc/file-*html
// @include      *888pan.cc/file-*html
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// ==/UserScript==
//牛盘
if(location.href.match(/666pan\.cc|6pan\.cc|777pan\.cc|888pan\.cc/g) ){
	var fileCode = location.href.match(/(\d+)\./g)[0].replace('.','');
	//document.querySelector('div.file_item').childNodes[1].innerHTML += '&nbsp;<a id="free_down_link" class="color_btn btn_deep_blue txtwhite" href="http://www.777pan.cc/cd.php?file_id=' + fileCode + '" target="_blank">⇩ 直接下载</a><span>8分钟一次</span>';
	//document.querySelector('#free_down_link').click();
	location.href = 'http://www.777pan.cc/down-' + fileCode + '.html';
}
//城通网盘、皮皮盘
//第一页自动点击按钮
if(location.href.match(/ctfile\.com|pipipan\.com/g) && document.querySelector('#free_down_link')){
	document.querySelector('#free_down_link').click();
}
//有pop广告的移除
if(document.querySelector('a[href*="popjump.php"]') !== null){
	var popNode = document.querySelector('a[href*="popjump.php"]');
	popNode.remove();
}
if(document.querySelector('#infoModal') !== null){
	var popNode = document.querySelector('#infoModal');
	popNode.remove();
}
if(document.querySelector('div.modal-backdrop.fade.in') !== null){
	var popNode = document.querySelector('div.modal-backdrop.fade.in');
	popNode.remove();
}
//获取第二页里的真实下载地址 建立copy按钮
//var uid = location.href.match(/\d+/g)[0];
//var fid = location.href.match(/\d+/g)[1];
var uidNfid = document.querySelector('div.pull-right').querySelector('a').href.match(/.+(uid=\d+&fid=\d+)&.+/)[1];
var chk = document.querySelector('#free_down_link').onclick.toString().match(/',\s'(.+)',\s/)[1];
var jsonUrl = location.href.match(/^.*\/\/[^\/]+/g)[0]+"/get_file_url.php?"+uidNfid+"&file_chk="+chk+"&verifycode=";
console.warn(jsonUrl);
GM_xmlhttpRequest({
			method: 'GET',
			url:  jsonUrl,
			headers: {
				'User-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36',
				'Accept': 'text/javascript,application/json',
			},
			onload: function(responseDetails) {
				//console.warn(responseDetails.responseText);
				var jsonData = eval('(' + responseDetails.responseText + ')');
				//console.warn(jsonData);
				var downUrl = jsonData.downurl;
				unsafeWindow.copyJsonMenu = function() {
					GM_setClipboard(downUrl);
				};
				setTimeout(document.querySelector('#free_down_link').nextSibling.innerHTML = '<button style="padding:2px; background: rgba(23,160,94,0.8);" onclick="copyJsonMenu();this.style.background=\'rgba(247,206,37,0.8)\';">Copy真实下载地址</button>',200);
				}
		});