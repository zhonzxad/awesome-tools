// ==UserScript==
// @name         搜索引擎，搜索结果智能去重 + 广告过滤[用于百度、360、搜狗、必应] + 黑名单广告过滤
// @namespace    Intelligent_weight _removal
// @version      2.0.6.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       Intelligent_weight _removal_broom
// @match        *://www.baidu.com
// @match        *://www.baidu.com/
// @match        *://www.baidu.com/s?*
// @match		 *://www.baidu.com/baidu?wd=*
// @match        *://m.baidu.com/s?*
// @match        *://www.so.com/s*
// @match        *://www.sogou.com/web*
// @match        *://cn.bing.com/search*
// @match        *://pan.baidu.com/s/*
// @match        *://pan.baidu.com/share/init*
// @match        *://wenku.baidu.com/search?*
// @match        *://zhidao.baidu.com/search?*
// @match        *://wenda.so.com/search/*
// @match        *://www.sohu.com
// @match        *://*.sohu.com/*
// @exclude      *://www.baidu.com/s?rtt=*
// @exclude      *://www.baidu.com/s?tn=news&rtt=*
// @grant        GM_xmlhttpRequest
// @grant        GM_getResourceText
// @grant        GM_getValue
// @grant        GM_setValue
// @connect 	 www.quzhuanpan.com
// @run-at       document-end
// @compatible	 Chrome
// @compatible	 Firefox
// @compatible	 Safari
// @compatible	 Opera
// ==/UserScript==
