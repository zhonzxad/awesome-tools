// ==UserScript==
// @name         1024去60秒,附帶神秘效果
// @namespace    http://tampermonkey.net/
// @version      1.2.8
// @description  去除1024的60秒屏蔽
// @match        *://*/*
// @grant        none
// ==/UserScript==

        var table = document.querySelectorAll('.sptable_do_not_remove');
        if (document.querySelectorAll('.sptable_do_not_remove span').length > 0) {
          var str = document.querySelectorAll('.sptable_do_not_remove span') [0].className;
          for (var j = 0; j < table.length; j++) {
            var td = table[j].querySelectorAll('td');
            for (var i = 0; i < td.length; i++) {
              td[i].innerHTML = '<span class=' + str + '>&nbsp;</span>';
            }
          }
        } else {
          for (var k = 0; k < table.length; k++) {
            table[k].style.display = 'none';
          }
        }


