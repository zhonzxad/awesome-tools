// ==UserScript==
// @grant          unsafeWindow
// @grant          GM_xmlhttpRequest
// @grant          GM_openInTab
// @grant          GM_registerMenuCommand
// @grant          GM_getValue
// @grant          GM_setValue
// @grant          GM_getResourceText
// @grant          GM_info

// @version        0.1.0.1

// @run-at         document-start
// @name:en        Bypass Wait, Code & Login on Websites (fixed)
// @name           跳过网站等待、验证码及登录(修复版)
// @name:zh-CN     跳过网站等待、验证码及登录(修复版)
// @name:zh-TW     繞過站點等待、識別碼及登錄(修复版)

// @description       This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @description:zh-CN 移除各类网站验证码、登录、倒计时及更多!(修复版)
// @description:zh-TW 移除各類站點識別碼、登錄、倒計時及更多!(修复版)
// @description:en    Remove verify code, login requirement, counting down... and more!


// @copyright      2014+, Yulei, Mod by Jixun.
////               Based on [Crack Url Wait Code Login] By Yulei

// 避免 Source Map 文件找不到的错误

/// CryptoJS 相关库

/// 非同步枚举

/// 兼容 GM 1.x, 2.x

/// Aria2 RPC

// VueJs, not always used.

// @author         Jixun.Moe<Yellow Yoshi>
// @namespace      http://jixun.org/

// 尝试使用脚本生成匹配规则
// ////               [Include Rules]

// @include http://localhost.cuwcl4c/*
// @include http://jixunmoe.github.io/*
// @include http://123564.com/*
// @include http://m.123564.com/*
// @include http://5xfile.com/*
// @include http://www.5xfile.com/*
// @include http://yun.baidu.com/*
// @include http://pan.baidu.com/*
// @include http://howfile.com/*
// @include http://*.howfile.com/*
// @include http://jkpan.cc/*
// @include http://*.jkpan.cc/*
// @include http://namipan.cc/*
// @include http://*.namipan.cc/*
// @include http://10pan.cc/*
// @include http://*.10pan.cc/*
// @include http://66yp.cc/*
// @include http://*.66yp.cc/*
// @include http://123wzwp.com/*
// @include http://*.123wzwp.com/*
// @include http://hiyp.cc/*
// @include http://*.hiyp.cc/*
// @include http://jkpan.cc/*
// @include http://*.jkpan.cc/*
// @include http://webhd.xuite.net/*
// @include http://sync.hamicloud.net/*
// @include http://www.yimuhe.com/*
// @include http://douban.fm/*
// @include https://douban.fm/*
// @include http://moe.fm/*
// @include http://music.163.com/*
// @include https://music.163.com/*
// @include http://www.1ting.com/*
// @include http://www.23356.com/*
// @include http://www.app-echo.com/*
// @include http://web.kugou.com/*
// @include https://jixunmoe.github.io/cuwcl4c/config/

// GM_xmlHttpRequest 远端服务器列表
// @connect down.lepan.cc
// @connect music.baidu.com
// @connect yinyueyun.baidu.com
// @connect media.store.kugou.com
// @connect trackercdn.kugou.com
// @connect yinyuetai.com
// @connect itwusun.com
// @connect self

// 告诉 TamperMonkey 这个脚本不需要转换
// @nocompat Chrome

// ==/UserScript==
