// ==UserScript==
// @name         HTML5播放器增强插件
// @namespace    https://greasyfork.org/users/49622
// @homepage     http://nopast.51vip.biz:10001/
// @version      1.1.2.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       过去终究是个回忆
// @match        http://*/*
// @match        https://*/*
// @run-at       document-end
// @grant        none
// ==/UserScript==
